# Security and RBAC
This document covers the security model, encryption approach, and role-based access control.
