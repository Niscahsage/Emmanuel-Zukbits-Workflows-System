# Database Schema
This document describes the relational database schema used by the system.
