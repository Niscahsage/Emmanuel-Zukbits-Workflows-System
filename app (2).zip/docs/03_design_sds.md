# Design (SDS)
This document describes the software design specification for the system, including major components and interactions.
