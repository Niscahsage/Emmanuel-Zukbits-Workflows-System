# Architecture and Modules
This document explains the system architecture and details each core module in the platform.
