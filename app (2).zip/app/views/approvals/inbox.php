<?php
// app/views/approvals/inbox.php
// inbox.php shows pending approval requests that require action from the current approver.

/** @var array $approvals */

use App\core\View;
use App\core\Auth;

$user = Auth::user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pending Approvals - ZukBits</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="/styles/approvals.css">
</head>
<body>
    <div class="container-fluid py-4">
        <div class="row justify-content-center">
            <div class="col-xxl-10 col-xl-12">
                <!-- Header -->
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4 p-4 rounded-3" style="background: var(--gradient-bg-card); border: 1px solid var(--color-border-light);">
                    <div class="mb-3 mb-md-0">
                        <h1 class="h3 mb-2 fw-bold text-gradient" style="background: var(--gradient-primary); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                            <i class="bi bi-inbox me-2"></i>Pending Approvals
                        </h1>
                        <p class="text-muted mb-0">Requests awaiting your review and decision</p>
                    </div>
                    <div class="d-flex gap-2">
                        <a href="/approvals" class="btn btn-outline-secondary d-flex align-items-center">
                            <i class="bi bi-list-check me-2"></i>All Approvals
                        </a>
                        <div class="vr d-none d-md-block"></div>
                        <div class="d-flex align-items-center ms-md-2">
                            <div class="badge bg-warning px-3 py-2">
                                <i class="bi bi-clock-history me-1"></i>
                                <?= count($approvals) ?> Pending
                            </div>
                        </div>
                    </div>
                </div>

                <?php if (empty($approvals)): ?>
                    <!-- Empty State -->
                    <div class="card border-success mb-4">
                        <div class="card-body text-center py-5">
                            <div class="mb-4">
                                <i class="bi bi-check2-circle text-success" style="font-size: 4rem;"></i>
                            </div>
                            <h3 class="h5 mb-3">All caught up!</h3>
                            <p class="text-muted mb-4">You have no pending approvals at the moment.</p>
                            <a href="/approvals" class="btn btn-outline-primary">
                                <i class="bi bi-arrow-left me-2"></i>View All Approvals
                            </a>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Approvals Table -->
                    <div class="card shadow-lg">
                        <div class="card-header border-0 pb-0">
                            <div class="d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">
                                    <i class="bi bi-hourglass-split me-2 text-warning"></i>
                                    Pending Requests
                                </h5>
                                <small class="text-muted">Showing <?= count($approvals) ?> requests</small>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                    <tr>
                                        <th class="ps-4">ID</th>
                                        <th>Type</th>
                                        <th>Target</th>
                                        <th>Requested By</th>
                                        <th>Requested At</th>
                                        <th class="text-end pe-4">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php foreach ($approvals as $approval): ?>
                                        <?php
                                        $id        = (int) ($approval['id'] ?? 0);
                                        $type      = $approval['approval_type'] ?? '';
                                        $targetId  = $approval['target_id'] ?? null;
                                        $requester = $approval['requester_name'] ?? 'Unknown';
                                        $createdAt = $approval['created_at'] ?? '';
                                        $typeLabel = $type === 'project_completion' ? 'Project completion' : ($type !== '' ? $type : 'Unknown');
                                        ?>
                                        <tr>
                                            <td class="ps-4 fw-semibold">#<?= View::e((string) $id) ?></td>
                                            <td>
                                                <span class="badge bg-primary bg-opacity-10 text-primary">
                                                    <?= View::e($typeLabel) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if (!empty($targetId)): ?>
                                                    <div class="d-flex align-items-center">
                                                        <i class="bi bi-hash me-2 text-muted"></i>
                                                        <?= View::e((string) $targetId) ?>
                                                    </div>
                                                <?php else: ?>
                                                    <span class="text-muted">–</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="me-2">
                                                        <i class="bi bi-person-circle"></i>
                                                    </div>
                                                    <span><?= View::e($requester) ?></span>
                                                </div>
                                            </td>
                                            <td>
                                                <?php if ($createdAt): ?>
                                                    <div class="d-flex align-items-center">
                                                        <i class="bi bi-calendar3 me-2 text-muted"></i>
                                                        <small><?= View::e($createdAt) ?></small>
                                                    </div>
                                                <?php else: ?>
                                                    <span class="text-muted">–</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-end pe-4">
                                                <a href="/approvals/show?id=<?= View::e((string) $id) ?>" class="btn btn-sm btn-primary d-inline-flex align-items-center">
                                                    <i class="bi bi-eye me-1"></i>Review
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/scripts/approvals.js"></script>
</body>
</html>