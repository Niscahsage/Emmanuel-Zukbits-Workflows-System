<?php
// approvals/show.php
// show.php displays details of a specific approval request and its decision history.

/** @var array $approval */
/** @var array $decisions */

use App\core\View;
use App\core\Auth;

$user    = Auth::user();
$roleKey = $user['role_key'] ?? 'developer';

$id          = (int) ($approval['id'] ?? 0);
$type        = $approval['approval_type'] ?? '';
$status      = $approval['status'] ?? '';
$targetId    = $approval['target_id'] ?? null;
$requester   = $approval['requester_name'] ?? 'Unknown';
$requestedBy = $approval['requested_by'] ?? null;
$createdAt   = $approval['created_at'] ?? '';
$updatedAt   = $approval['updated_at'] ?? '';

$typeLabel = $type === 'project_completion' ? 'Project completion' : ($type !== '' ? $type : 'Unknown');
$statusLabel = ucfirst($status ?: 'pending');

$canDecide = (
    in_array($roleKey, ['super_admin', 'director', 'system_admin'], true)
    && $status === 'pending'
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approval #<?= $id ?> - ZukBits</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="/styles/approvals.css">
</head>
<body>
    <div class="container-fluid py-4">
        <div class="row justify-content-center">
            <div class="col-xxl-10 col-xl-12">
                <!-- Header -->
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4 p-4 rounded-3" style="background: var(--gradient-bg-card); border: 1px solid var(--color-border-light);">
                    <div class="mb-3 mb-md-0">
                        <h1 class="h3 mb-1 fw-bold">
                            <span class="text-gradient" style="background: var(--gradient-primary); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                                Approval #<?= View::e((string) $id) ?>
                            </span>
                        </h1>
                        <div class="d-flex align-items-center flex-wrap gap-2">
                            <span class="badge bg-primary bg-opacity-10 text-primary">
                                <?= View::e($typeLabel) ?>
                            </span>
                            <?php if ($status === 'approved'): ?>
                                <span class="badge bg-success">
                                    <i class="bi bi-check-circle me-1"></i>Approved
                                </span>
                            <?php elseif ($status === 'rejected'): ?>
                                <span class="badge bg-danger">
                                    <i class="bi bi-x-circle me-1"></i>Rejected
                                </span>
                            <?php else: ?>
                                <span class="badge bg-warning">
                                    <i class="bi bi-clock me-1"></i>Pending
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="d-flex flex-wrap gap-2">
                        <a href="/approvals" class="btn btn-outline-secondary d-inline-flex align-items-center">
                            <i class="bi bi-arrow-left me-2"></i>Back to list
                        </a>
                        <a href="/approvals/inbox" class="btn btn-outline-primary d-inline-flex align-items-center">
                            <i class="bi bi-inbox me-2"></i>Pending inbox
                        </a>
                    </div>
                </div>

                <!-- Approval Details -->
                <div class="card shadow-lg mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="bi bi-info-circle me-2"></i>Approval Details
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-person-circle me-3 text-muted" style="font-size: 1.25rem;"></i>
                                    <div>
                                        <small class="text-muted d-block">Requested By</small>
                                        <strong class="d-block"><?= View::e($requester) ?></strong>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-calendar3 me-3 text-muted" style="font-size: 1.25rem;"></i>
                                    <div>
                                        <small class="text-muted d-block">Requested On</small>
                                        <strong class="d-block">
                                            <?= $createdAt ? View::e($createdAt) : '<span class="text-muted">–</span>' ?>
                                        </strong>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-clock-history me-3 text-muted" style="font-size: 1.25rem;"></i>
                                    <div>
                                        <small class="text-muted d-block">Last Updated</small>
                                        <strong class="d-block">
                                            <?= $updatedAt ? View::e($updatedAt) : '<span class="text-muted">–</span>' ?>
                                        </strong>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="d-flex align-items-center mb-2">
                                    <i class="bi bi-link-45deg me-3 text-muted" style="font-size: 1.25rem;"></i>
                                    <div>
                                        <small class="text-muted d-block">Target</small>
                                        <strong class="d-block">
                                            <?php if ($targetId): ?>
                                                <?php if ($type === 'project_completion'): ?>
                                                    <a href="/projects/show?id=<?= View::e((string) $targetId) ?>" class="text-decoration-none">
                                                        Project #<?= View::e((string) $targetId) ?>
                                                        <i class="bi bi-box-arrow-up-right ms-1"></i>
                                                    </a>
                                                <?php else: ?>
                                                    <?= View::e((string) $targetId) ?>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="text-muted">–</span>
                                            <?php endif; ?>
                                        </strong>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Decision History -->
                <?php if (!empty($decisions)): ?>
                    <div class="card shadow-lg mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="bi bi-clock-history me-2"></i>Decision History
                            </h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                    <tr>
                                        <th class="ps-4">Decision</th>
                                        <th>Approver</th>
                                        <th>Comment</th>
                                        <th class="pe-4">Decision Date</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php foreach ($decisions as $d): ?>
                                        <?php
                                        $decision  = $d['decision'] ?? '';
                                        $comment   = $d['comment'] ?? '';
                                        $decider   = $d['approver_name'] ?? 'Unknown';
                                        $decidedAt = $d['decided_at'] ?? '';
                                        ?>
                                        <tr>
                                            <td class="ps-4">
                                                <?php if ($decision === 'approved'): ?>
                                                    <span class="badge bg-success">
                                                        <i class="bi bi-check-circle me-1"></i>Approved
                                                    </span>
                                                <?php elseif ($decision === 'rejected'): ?>
                                                    <span class="badge bg-danger">
                                                        <i class="bi bi-x-circle me-1"></i>Rejected
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary"><?= View::e(ucfirst($decision)) ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="me-2">
                                                        <i class="bi bi-person-check"></i>
                                                    </div>
                                                    <span><?= View::e($decider) ?></span>
                                                </div>
                                            </td>
                                            <td>
                                                <?php if ($comment !== ''): ?>
                                                    <div class="bg-dark bg-opacity-25 p-3 rounded">
                                                        <?= nl2br(View::e($comment)) ?>
                                                    </div>
                                                <?php else: ?>
                                                    <span class="text-muted fst-italic">No comment provided</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="pe-4">
                                                <?php if ($decidedAt): ?>
                                                    <div class="d-flex align-items-center">
                                                        <i class="bi bi-calendar-check me-2 text-muted"></i>
                                                        <small><?= View::e($decidedAt) ?></small>
                                                    </div>
                                                <?php else: ?>
                                                    <span class="text-muted">–</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="card mb-4">
                        <div class="card-body text-center py-4">
                            <i class="bi bi-journal-text text-muted mb-3" style="font-size: 3rem;"></i>
                            <h5 class="mb-2">No decisions recorded yet</h5>
                            <p class="text-muted mb-0">This approval is awaiting its first decision.</p>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Decision Form -->
                <?php if ($canDecide): ?>
                    <div class="card shadow-lg">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="bi bi-pencil-square me-2"></i>Record Your Decision
                            </h5>
                        </div>
                        <div class="card-body">
                            <form method="post" action="/approvals/decide" class="needs-validation" novalidate>
                                <input type="hidden" name="approval_id" value="<?= View::e((string) $id) ?>">

                                <div class="row">
                                    <div class="col-lg-4 mb-4">
                                        <label for="decision" class="form-label">
                                            <i class="bi bi-check2-circle me-1"></i>Decision
                                        </label>
                                        <select name="decision" id="decision" class="form-select form-select-lg" required>
                                            <option value="" disabled selected>Choose a decision...</option>
                                            <option value="approved">✅ Approve Request</option>
                                            <option value="rejected">❌ Reject Request</option>
                                        </select>
                                        <div class="invalid-feedback">
                                            Please select a decision.
                                        </div>
                                    </div>

                                    <div class="col-lg-8 mb-4">
                                        <label for="comment" class="form-label">
                                            <i class="bi bi-chat-text me-1"></i>Comment (Optional)
                                        </label>
                                        <textarea
                                            name="comment"
                                            id="comment"
                                            rows="4"
                                            class="form-control"
                                            placeholder="Add any notes or justification for your decision..."
                                            maxlength="500"
                                        ></textarea>
                                        <div class="form-text">
                                            Maximum 500 characters
                                        </div>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-end">
                                    <button type="submit" class="btn btn-primary btn-lg px-4 d-inline-flex align-items-center">
                                        <i class="bi bi-send-check me-2"></i>Submit Decision
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php elseif ($status === 'pending'): ?>
                    <div class="alert alert-info d-flex align-items-center">
                        <i class="bi bi-info-circle-fill me-3" style="font-size: 1.5rem;"></i>
                        <div>
                            <h6 class="alert-heading mb-1">Approval Pending</h6>
                            <p class="mb-0">This approval is awaiting decision. Only directors, system admins, or super admins can record a decision.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/scripts/approvals.js"></script>
</body>
</html>