<?php
// approvals/index.php
// index.php lists all approval requests visible to the current user.
// show.php displays details of a specific approval request and its decision history.

/** @var array $approvals */

use App\core\View;
use App\core\Auth;

$user = Auth::user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Approvals - ZukBits</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="/styles/approvals.css">
</head>
<body>
    <div class="container-fluid py-4">
        <div class="row justify-content-center">
            <div class="col-xxl-10 col-xl-12">
                <!-- Header -->
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4 p-4 rounded-3" style="background: var(--gradient-bg-card); border: 1px solid var(--color-border-light);">
                    <div class="mb-3 mb-md-0">
                        <h1 class="h3 mb-2 fw-bold text-gradient" style="background: var(--gradient-primary); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                            <i class="bi bi-check2-all me-2"></i>Approval Requests
                        </h1>
                        <p class="text-muted mb-0">Track and manage all approval requests</p>
                    </div>
                    <div class="d-flex gap-2">
                        <a href="/approvals/inbox" class="btn btn-primary d-inline-flex align-items-center">
                            <i class="bi bi-inbox-fill me-2"></i>Pending Inbox
                            <?php if (!empty($approvals)): ?>
                                <?php
                                $pendingCount = array_filter($approvals, function($a) {
                                    return ($a['status'] ?? '') === 'pending';
                                });
                                if (count($pendingCount) > 0): ?>
                                    <span class="badge bg-warning text-dark ms-2"><?= count($pendingCount) ?></span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </a>
                    </div>
                </div>

                <!-- Stats Cards -->
                <?php if (!empty($approvals)): ?>
                    <?php
                    $statuses = ['pending' => 0, 'approved' => 0, 'rejected' => 0];
                    foreach ($approvals as $approval) {
                        $status = $approval['status'] ?? 'pending';
                        $statuses[$status] = ($statuses[$status] ?? 0) + 1;
                    }
                    ?>
                    <div class="row mb-4">
                        <div class="col-md-4 mb-3">
                            <div class="card h-100 border-warning">
                                <div class="card-body">
                                    <div class="d-flex align-items-center">
                                        <div class="me-3">
                                            <div class="p-3 rounded-circle" style="background: rgba(251, 191, 36, 0.2);">
                                                <i class="bi bi-clock-history text-warning" style="font-size: 1.5rem;"></i>
                                            </div>
                                        </div>
                                        <div>
                                            <h3 class="h2 mb-0"><?= $statuses['pending'] ?></h3>
                                            <p class="text-muted mb-0">Pending</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="card h-100 border-success">
                                <div class="card-body">
                                    <div class="d-flex align-items-center">
                                        <div class="me-3">
                                            <div class="p-3 rounded-circle" style="background: rgba(52, 199, 89, 0.2);">
                                                <i class="bi bi-check-circle text-success" style="font-size: 1.5rem;"></i>
                                            </div>
                                        </div>
                                        <div>
                                            <h3 class="h2 mb-0"><?= $statuses['approved'] ?></h3>
                                            <p class="text-muted mb-0">Approved</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="card h-100 border-danger">
                                <div class="card-body">
                                    <div class="d-flex align-items-center">
                                        <div class="me-3">
                                            <div class="p-3 rounded-circle" style="background: rgba(239, 68, 68, 0.2);">
                                                <i class="bi bi-x-circle text-danger" style="font-size: 1.5rem;"></i>
                                            </div>
                                        </div>
                                        <div>
                                            <h3 class="h2 mb-0"><?= $statuses['rejected'] ?></h3>
                                            <p class="text-muted mb-0">Rejected</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (empty($approvals)): ?>
                    <!-- Empty State -->
                    <div class="card">
                        <div class="card-body text-center py-5">
                            <div class="mb-4">
                                <i class="bi bi-clipboard-check text-muted" style="font-size: 4rem;"></i>
                            </div>
                            <h3 class="h5 mb-3">No approval requests found</h3>
                            <p class="text-muted mb-4">There are no approval requests in the system yet.</p>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Approvals Table -->
                    <div class="card shadow-lg">
                        <div class="card-header border-0 pb-0">
                            <div class="d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">
                                    <i class="bi bi-list-task me-2"></i>
                                    All Requests
                                </h5>
                                <small class="text-muted">Total: <?= count($approvals) ?> requests</small>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                    <tr>
                                        <th class="ps-4">ID</th>
                                        <th>Type</th>
                                        <th>Status</th>
                                        <th>Target</th>
                                        <th>Requested By</th>
                                        <th>Requested At</th>
                                        <th class="text-end pe-4">Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php foreach ($approvals as $approval): ?>
                                        <?php
                                        $id          = (int) ($approval['id'] ?? 0);
                                        $type        = $approval['approval_type'] ?? '';
                                        $status      = $approval['status'] ?? '';
                                        $targetId    = $approval['target_id'] ?? null;
                                        $requester   = $approval['requester_name'] ?? 'Unknown';
                                        $createdAt   = $approval['created_at'] ?? '';
                                        $typeLabel   = $type === 'project_completion' ? 'Project completion' : ($type !== '' ? $type : 'Unknown');
                                        $statusLabel = ucfirst($status ?: 'pending');
                                        ?>
                                        <tr>
                                            <td class="ps-4 fw-semibold">#<?= View::e((string) $id) ?></td>
                                            <td>
                                                <span class="badge bg-primary bg-opacity-10 text-primary">
                                                    <?= View::e($typeLabel) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($status === 'approved'): ?>
                                                    <span class="badge bg-success">
                                                        <i class="bi bi-check-circle me-1"></i>Approved
                                                    </span>
                                                <?php elseif ($status === 'rejected'): ?>
                                                    <span class="badge bg-danger">
                                                        <i class="bi bi-x-circle me-1"></i>Rejected
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge bg-warning">
                                                        <i class="bi bi-clock me-1"></i>Pending
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if (!empty($targetId)): ?>
                                                    <div class="d-flex align-items-center">
                                                        <i class="bi bi-hash me-2 text-muted"></i>
                                                        <?= View::e((string) $targetId) ?>
                                                    </div>
                                                <?php else: ?>
                                                    <span class="text-muted">–</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="me-2">
                                                        <i class="bi bi-person-circle"></i>
                                                    </div>
                                                    <span><?= View::e($requester) ?></span>
                                                </div>
                                            </td>
                                            <td>
                                                <?php if ($createdAt): ?>
                                                    <div class="d-flex align-items-center">
                                                        <i class="bi bi-calendar3 me-2 text-muted"></i>
                                                        <small><?= View::e($createdAt) ?></small>
                                                    </div>
                                                <?php else: ?>
                                                    <span class="text-muted">–</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-end pe-4">
                                                <a href="/approvals/show?id=<?= View::e((string) $id) ?>" class="btn btn-sm btn-outline-secondary d-inline-flex align-items-center">
                                                    <i class="bi bi-eye me-1"></i>View
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/scripts/approvals.js"></script>
</body>
</html>