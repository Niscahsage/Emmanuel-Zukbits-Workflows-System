<?php
// app/views/partials/footer.php
// Shared footer section for authenticated pages.

$app = app_config();
$appName = $app['name'] ?? 'ZukBits Workflows System';

$currentYear = date('Y');
?>
<footer class="zb-footer">
    <div class="footer-container">
        <!-- Main Footer Content -->
        <div class="footer-main">
            <div class="footer-brand">
                <div class="footer-logo">
                    <span class="logo-text">ZB</span>
                </div>
                <div class="footer-brand-text">
                    <h3 class="footer-title"><?= htmlspecialchars($appName, ENT_QUOTES, 'UTF-8') ?></h3>
                    <p class="footer-subtitle">Professional Workflow Management System</p>
                </div>
            </div>

            <div class="footer-links">
                <div class="link-column">
                    <h4 class="column-title">Product</h4>
                    <ul class="link-list">
                        <li><a href="/features">Features</a></li>
                        <li><a href="/pricing">Pricing</a></li>
                        <li><a href="/updates">Updates</a></li>
                        <li><a href="/roadmap">Roadmap</a></li>
                    </ul>
                </div>
                
                <div class="link-column">
                    <h4 class="column-title">Company</h4>
                    <ul class="link-list">
                        <li><a href="/about">About Us</a></li>
                        <li><a href="/careers">Careers</a></li>
                        <li><a href="/press">Press</a></li>
                        <li><a href="/contact">Contact</a></li>
                    </ul>
                </div>
                
                <div class="link-column">
                    <h4 class="column-title">Resources</h4>
                    <ul class="link-list">
                        <li><a href="/documentation">Documentation</a></li>
                        <li><a href="/help">Help Center</a></li>
                        <li><a href="/community">Community</a></li>
                        <li><a href="/developers">Developer API</a></li>
                    </ul>
                </div>
                
                <div class="link-column">
                    <h4 class="column-title">Legal</h4>
                    <ul class="link-list">
                        <li><a href="/privacy">Privacy Policy</a></li>
                        <li><a href="/terms">Terms of Service</a></li>
                        <li><a href="/security">Security</a></li>
                        <li><a href="/compliance">Compliance</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="footer-bottom">
            <div class="copyright-section">
                <div class="copyright-text">
                    &copy; <?= $currentYear ?> <?= htmlspecialchars($appName, ENT_QUOTES, 'UTF-8') ?>. All rights reserved.
                </div>
                <div class="legal-links">
                    <a href="/privacy">Privacy</a>
                    <span class="separator">•</span>
                    <a href="/terms">Terms</a>
                    <span class="separator">•</span>
                    <a href="/cookies">Cookies</a>
                </div>
            </div>

            <div class="footer-info">
                <div class="system-info">
                    <div class="info-item">
                        <i class="bi bi-server"></i>
                        <span>System v2.5.1</span>
                    </div>
                    <div class="info-item">
                        <i class="bi bi-shield-check"></i>
                        <span>Security Status: <span class="status-good">Active</span></span>
                    </div>
                    <div class="info-item">
                        <i class="bi bi-clock"></i>
                        <span>Last updated: <?= date('M j, Y') ?></span>
                    </div>
                </div>

                <div class="social-links">
                    <a href="https://twitter.com" class="social-link" target="_blank" rel="noopener">
                        <i class="bi bi-twitter"></i>
                    </a>
                    <a href="https://github.com" class="social-link" target="_blank" rel="noopener">
                        <i class="bi bi-github"></i>
                    </a>
                    <a href="https://linkedin.com" class="social-link" target="_blank" rel="noopener">
                        <i class="bi bi-linkedin"></i>
                    </a>
                    <a href="https://discord.com" class="social-link" target="_blank" rel="noopener">
                        <i class="bi bi-discord"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</footer>

<style>
    /* Color Variables */
    :root {
        --footer-bg: linear-gradient(180deg, #020617 0%, #050816 100%);
        --footer-border: #22263b;
        --footer-text: #c3c5d4;
        --footer-text-hover: #ffffff;
        --footer-accent: #38bdf8;
        --footer-gradient: linear-gradient(135deg, #38bdf8, #a855f7);
    }

    /* Footer Container */
    .zb-footer {
        background: var(--footer-bg);
        border-top: 1px solid var(--footer-border);
        padding: 3rem 0 0;
        margin-top: auto;
        width: 100%;
        position: relative;
        overflow: hidden;
    }

    .zb-footer::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 1px;
        background: linear-gradient(90deg, transparent, var(--footer-accent), transparent);
    }

    .footer-container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 1.5rem;
    }

    /* Main Footer Content */
    .footer-main {
        display: grid;
        grid-template-columns: 1fr 2fr;
        gap: 3rem;
        padding-bottom: 3rem;
        border-bottom: 1px solid var(--footer-border);
    }

    .footer-brand {
        display: flex;
        flex-direction: column;
        gap: 1rem;
    }

    .footer-logo {
        width: 56px;
        height: 56px;
        border-radius: 12px;
        background: var(--footer-gradient);
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 8px 25px rgba(56, 189, 248, 0.3);
    }

    .logo-text {
        color: white;
        font-weight: 700;
        font-size: 1.25rem;
    }

    .footer-brand-text {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .footer-title {
        font-size: 1.25rem;
        font-weight: 700;
        color: #ffffff;
        margin: 0;
    }

    .footer-subtitle {
        font-size: 0.9rem;
        color: var(--footer-text);
        margin: 0;
        line-height: 1.5;
    }

    .footer-links {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 2rem;
    }

    .link-column {
        display: flex;
        flex-direction: column;
        gap: 1rem;
    }

    .column-title {
        font-size: 0.9rem;
        font-weight: 600;
        color: #ffffff;
        margin: 0;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .link-list {
        list-style: none;
        padding: 0;
        margin: 0;
        display: flex;
        flex-direction: column;
        gap: 0.75rem;
    }

    .link-list li a {
        color: var(--footer-text);
        text-decoration: none;
        font-size: 0.9rem;
        transition: all 0.3s ease;
        display: inline-block;
    }

    .link-list li a:hover {
        color: var(--footer-text-hover);
        transform: translateX(5px);
    }

    /* Footer Bottom */
    .footer-bottom {
        padding: 2rem 0;
    }

    .copyright-section {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1.5rem;
    }

    .copyright-text {
        font-size: 0.9rem;
        color: var(--footer-text);
    }

    .legal-links {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .legal-links a {
        color: var(--footer-text);
        text-decoration: none;
        font-size: 0.85rem;
        transition: all 0.3s ease;
    }

    .legal-links a:hover {
        color: var(--footer-accent);
    }

    .separator {
        color: var(--footer-text);
        opacity: 0.5;
        font-size: 0.85rem;
    }

    .footer-info {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 1.5rem;
    }

    .system-info {
        display: flex;
        gap: 2rem;
        flex-wrap: wrap;
    }

    .info-item {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        color: var(--footer-text);
        font-size: 0.85rem;
    }

    .info-item i {
        color: var(--footer-accent);
        font-size: 0.9rem;
    }

    .status-good {
        color: #34c759;
        font-weight: 600;
    }

    .social-links {
        display: flex;
        gap: 1rem;
    }

    .social-link {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        background: rgba(148, 163, 253, 0.1);
        border: 1px solid rgba(148, 163, 253, 0.2);
        color: var(--footer-text);
        display: flex;
        align-items: center;
        justify-content: center;
        text-decoration: none;
        transition: all 0.3s ease;
        font-size: 1.1rem;
    }

    .social-link:hover {
        background: rgba(56, 189, 248, 0.2);
        border-color: var(--footer-accent);
        color: var(--footer-accent);
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(56, 189, 248, 0.2);
    }

    /* Responsive Design */
    @media (max-width: 992px) {
        .footer-main {
            grid-template-columns: 1fr;
            gap: 2rem;
        }
        
        .footer-links {
            grid-template-columns: repeat(2, 1fr);
            gap: 2rem 3rem;
        }
        
        .footer-info {
            flex-direction: column;
            align-items: flex-start;
            gap: 1.5rem;
        }
    }

    @media (max-width: 768px) {
        .footer-container {
            padding: 0 1rem;
        }
        
        .footer-main {
            padding-bottom: 2rem;
        }
        
        .copyright-section {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
        }
        
        .legal-links {
            align-self: flex-start;
        }
        
        .system-info {
            flex-direction: column;
            gap: 1rem;
        }
    }

    @media (max-width: 576px) {
        .footer-links {
            grid-template-columns: 1fr;
            gap: 2rem;
        }
        
        .footer-brand {
            align-items: center;
            text-align: center;
        }
        
        .social-links {
            width: 100%;
            justify-content: center;
        }
    }

    /* Back to Top Button */
    .back-to-top {
        position: fixed;
        bottom: 2rem;
        right: 2rem;
        width: 48px;
        height: 48px;
        border-radius: 12px;
        background: var(--footer-gradient);
        border: none;
        color: white;
        font-size: 1.25rem;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s ease;
        opacity: 0;
        visibility: hidden;
        z-index: 100;
        box-shadow: 0 8px 25px rgba(56, 189, 248, 0.3);
    }

    .back-to-top.visible {
        opacity: 1;
        visibility: visible;
    }

    .back-to-top:hover {
        transform: translateY(-5px);
        box-shadow: 0 12px 35px rgba(56, 189, 248, 0.4);
    }

    @media (max-width: 768px) {
        .back-to-top {
            bottom: 1rem;
            right: 1rem;
            width: 44px;
            height: 44px;
        }
    }
</style>

<script>
    // Back to top functionality
    document.addEventListener('DOMContentLoaded', function() {
        const backToTop = document.createElement('button');
        backToTop.className = 'back-to-top';
        backToTop.innerHTML = '<i class="bi bi-chevron-up"></i>';
        backToTop.title = 'Back to top';
        document.body.appendChild(backToTop);

        // Show/hide button based on scroll position
        function toggleBackToTop() {
            if (window.pageYOffset > 300) {
                backToTop.classList.add('visible');
            } else {
                backToTop.classList.remove('visible');
            }
        }

        // Scroll to top
        backToTop.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });

        // Listen for scroll events
        window.addEventListener('scroll', toggleBackToTop);
        toggleBackToTop(); // Initial check

        // Current year update
        const yearElements = document.querySelectorAll('[data-current-year]');
        yearElements.forEach(el => {
            el.textContent = new Date().getFullYear();
        });
    });
</script>