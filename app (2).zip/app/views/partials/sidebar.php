<?php
// app/views/partials/sidebar.php
// Left sidebar navigation with links based on the user's role.

use App\core\Auth;

$user    = Auth::user();
$roleKey = $user['role_key'] ?? null;

$currentPath = $_SERVER['REQUEST_URI'] ?? '/';
?>
<aside class="sidebar" id="mainSidebar">
    <div class="sidebar-header">
        <div class="sidebar-brand">
            <div class="brand-logo">
                <span class="logo-text">ZB</span>
            </div>
            <div class="brand-text">
                <div class="brand-title">ZukBits</div>
                <div class="brand-subtitle">Dashboard</div>
            </div>
        </div>
        <button class="sidebar-close d-md-none" id="sidebarClose">
            <i class="bi bi-x"></i>
        </button>
    </div>

    <div class="sidebar-content">
        <!-- User Profile Summary -->
        <div class="user-summary">
            <div class="user-avatar">
                <div class="avatar-initials">
                    <?= strtoupper(substr($user['name'] ?? 'U', 0, 1)) ?>
                </div>
            </div>
            <div class="user-details">
                <div class="user-name"><?= htmlspecialchars($user['name'] ?? 'Unknown', ENT_QUOTES, 'UTF-8') ?></div>
                <div class="user-role"><?= htmlspecialchars($user['role_name'] ?? 'User', ENT_QUOTES, 'UTF-8') ?></div>
                <div class="user-status">
                    <span class="status-indicator online"></span>
                    <span class="status-text">Online</span>
                </div>
            </div>
        </div>

        <!-- Main Navigation -->
        <nav class="sidebar-nav">
            <div class="nav-section">
                <div class="section-title">Main Navigation</div>
                <ul class="nav-menu">
                    <li class="nav-item <?= strpos($currentPath, '/dashboard') === 0 || $currentPath === '/' ? 'active' : '' ?>">
                        <a href="/" class="nav-link">
                            <i class="bi bi-speedometer2"></i>
                            <span class="link-text">Dashboard</span>
                            <span class="link-badge">Home</span>
                        </a>
                    </li>
                    
                    <li class="nav-item <?= strpos($currentPath, '/projects') === 0 ? 'active' : '' ?>">
                        <a href="/projects" class="nav-link">
                            <i class="bi bi-kanban"></i>
                            <span class="link-text">Projects</span>
                            <span class="link-badge">12</span>
                        </a>
                    </li>
                    
                    <li class="nav-item <?= strpos($currentPath, '/schedules') === 0 ? 'active' : '' ?>">
                        <a href="/schedules" class="nav-link">
                            <i class="bi bi-calendar-week"></i>
                            <span class="link-text">Weekly Schedules</span>
                            <span class="link-badge new">New</span>
                        </a>
                    </li>
                    
                    <li class="nav-item <?= strpos($currentPath, '/reports') === 0 ? 'active' : '' ?>">
                        <a href="/reports" class="nav-link">
                            <i class="bi bi-file-earmark-bar-graph"></i>
                            <span class="link-text">Weekly Reports</span>
                            <span class="link-badge">5</span>
                        </a>
                    </li>
                    
                    <li class="nav-item <?= strpos($currentPath, '/documentation') === 0 ? 'active' : '' ?>">
                        <a href="/documentation" class="nav-link">
                            <i class="bi bi-journal-text"></i>
                            <span class="link-text">Documentation</span>
                        </a>
                    </li>
                    
                    <li class="nav-item <?= strpos($currentPath, '/credentials') === 0 ? 'active' : '' ?>">
                        <a href="/credentials" class="nav-link">
                            <i class="bi bi-shield-lock"></i>
                            <span class="link-text">Credentials</span>
                            <span class="link-badge warning">Secured</span>
                        </a>
                    </li>
                    
                    <li class="nav-item <?= strpos($currentPath, '/notifications') === 0 ? 'active' : '' ?>">
                        <a href="/notifications" class="nav-link">
                            <i class="bi bi-bell"></i>
                            <span class="link-text">Notifications</span>
                            <span class="link-badge alert">3</span>
                        </a>
                    </li>
                </ul>
            </div>

            <?php if (in_array($roleKey, ['super_admin', 'system_admin'], true)): ?>
            <div class="nav-section">
                <div class="section-title">Administration</div>
                <ul class="nav-menu">
                    <li class="nav-item <?= strpos($currentPath, '/users') === 0 ? 'active' : '' ?>">
                        <a href="/users" class="nav-link">
                            <i class="bi bi-people"></i>
                            <span class="link-text">User Management</span>
                            <span class="link-badge">48</span>
                        </a>
                    </li>
                    
                    <li class="nav-item <?= strpos($currentPath, '/approvals') === 0 ? 'active' : '' ?>">
                        <a href="/approvals" class="nav-link">
                            <i class="bi bi-check-circle"></i>
                            <span class="link-text">Approvals</span>
                            <span class="link-badge warning">3</span>
                        </a>
                    </li>
                    
                    <li class="nav-item <?= strpos($currentPath, '/settings') === 0 ? 'active' : '' ?>">
                        <a href="/settings/system" class="nav-link">
                            <i class="bi bi-gear"></i>
                            <span class="link-text">System Settings</span>
                        </a>
                    </li>
                    
                    <li class="nav-item <?= strpos($currentPath, '/analytics') === 0 ? 'active' : '' ?>">
                        <a href="/analytics" class="nav-link">
                            <i class="bi bi-graph-up"></i>
                            <span class="link-text">Analytics</span>
                            <span class="link-badge new">Beta</span>
                        </a>
                    </li>
                    
                    <li class="nav-item <?= strpos($currentPath, '/logs') === 0 ? 'active' : '' ?>">
                        <a href="/logs" class="nav-link">
                            <i class="bi bi-clipboard-data"></i>
                            <span class="link-text">System Logs</span>
                        </a>
                    </li>
                </ul>
            </div>
            <?php endif; ?>

            <!-- Tools Section -->
            <div class="nav-section">
                <div class="section-title">Quick Tools</div>
                <ul class="nav-menu">
                    <li class="nav-item">
                        <a href="/quick-add" class="nav-link">
                            <i class="bi bi-plus-circle"></i>
                            <span class="link-text">New Project</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="/reports/generate" class="nav-link">
                            <i class="bi bi-file-earmark-plus"></i>
                            <span class="link-text">Generate Report</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="/search" class="nav-link">
                            <i class="bi bi-search"></i>
                            <span class="link-text">Advanced Search</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="/help" class="nav-link">
                            <i class="bi bi-question-circle"></i>
                            <span class="link-text">Help Center</span>
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Sidebar Footer -->
        <div class="sidebar-footer">
            <div class="system-status">
                <div class="status-label">System Status</div>
                <div class="status-value online">All Systems Operational</div>
            </div>
            
            <div class="sidebar-actions">
                <a href="/profile" class="action-link">
                    <i class="bi bi-person"></i>
                    Profile
                </a>
                <a href="/settings" class="action-link">
                    <i class="bi bi-gear"></i>
                    Settings
                </a>
                <a href="/logout" class="action-link logout">
                    <i class="bi bi-box-arrow-right"></i>
                    Logout
                </a>
            </div>
            
            <div class="copyright">
                &copy; <?= date('Y') ?> ZukBits Online
                <div class="version">v2.5.1</div>
            </div>
        </div>
    </div>
</aside>

<style>
    /* Sidebar Variables */
    :root {
        --sidebar-width: 260px;
        --sidebar-collapsed-width: 70px;
        --sidebar-bg: linear-gradient(180deg, #050816 0%, #0b1020 100%);
        --sidebar-border: #22263b;
        --sidebar-text: #c3c5d4;
        --sidebar-text-hover: #ffffff;
        --sidebar-accent: #38bdf8;
        --sidebar-accent-gradient: linear-gradient(135deg, #38bdf8, #a855f7);
    }

    /* Sidebar Container */
    .sidebar {
        width: var(--sidebar-width);
        background: var(--sidebar-bg);
        border-right: 1px solid var(--sidebar-border);
        height: 100vh;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 1000;
        display: flex;
        flex-direction: column;
        transition: all 0.3s ease;
        overflow: hidden;
    }

    /* Sidebar Header */
    .sidebar-header {
        padding: 1.25rem 1.25rem 1rem;
        border-bottom: 1px solid var(--sidebar-border);
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .sidebar-brand {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .brand-logo {
        width: 36px;
        height: 36px;
        border-radius: 10px;
        background: var(--sidebar-accent-gradient);
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 15px rgba(56, 189, 248, 0.3);
    }

    .logo-text {
        color: white;
        font-weight: 700;
        font-size: 0.9rem;
    }

    .brand-text {
        line-height: 1.2;
    }

    .brand-title {
        font-size: 1rem;
        font-weight: 700;
        color: #ffffff;
        margin: 0;
    }

    .brand-subtitle {
        font-size: 0.75rem;
        color: var(--sidebar-text);
        margin: 0;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .sidebar-close {
        background: none;
        border: none;
        color: var(--sidebar-text);
        font-size: 1.5rem;
        padding: 0.5rem;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s ease;
        display: none;
    }

    .sidebar-close:hover {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
    }

    /* Sidebar Content */
    .sidebar-content {
        flex: 1;
        display: flex;
        flex-direction: column;
        overflow-y: auto;
        padding: 1rem 0;
    }

    /* User Summary */
    .user-summary {
        padding: 1rem 1.25rem 1.5rem;
        border-bottom: 1px solid rgba(148, 163, 253, 0.1);
        margin-bottom: 1rem;
    }

    .user-summary {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .user-avatar {
        flex-shrink: 0;
    }

    .avatar-initials {
        width: 48px;
        height: 48px;
        border-radius: 12px;
        background: var(--sidebar-accent-gradient);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 1rem;
        box-shadow: 0 4px 15px rgba(56, 189, 248, 0.3);
    }

    .user-details {
        flex: 1;
        min-width: 0;
    }

    .user-name {
        font-size: 0.9rem;
        font-weight: 600;
        color: #ffffff;
        margin: 0 0 0.125rem;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .user-role {
        font-size: 0.8rem;
        color: var(--sidebar-text);
        margin: 0 0 0.375rem;
        text-transform: capitalize;
    }

    .user-status {
        display: flex;
        align-items: center;
        gap: 0.375rem;
    }

    .status-indicator {
        width: 8px;
        height: 8px;
        border-radius: 50%;
    }

    .status-indicator.online {
        background: #34c759;
        box-shadow: 0 0 0 2px rgba(52, 199, 89, 0.3);
    }

    .status-text {
        font-size: 0.75rem;
        color: var(--sidebar-text);
    }

    /* Navigation Sections */
    .nav-section {
        margin-bottom: 1.5rem;
    }

    .section-title {
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: var(--sidebar-text);
        padding: 0 1.25rem 0.5rem;
        margin-bottom: 0.5rem;
        border-bottom: 1px solid rgba(148, 163, 253, 0.1);
    }

    .nav-menu {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .nav-item {
        margin: 0.125rem 0;
    }

    .nav-link {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        padding: 0.75rem 1.25rem;
        color: var(--sidebar-text);
        text-decoration: none;
        transition: all 0.3s ease;
        position: relative;
        border-left: 3px solid transparent;
    }

    .nav-link:hover {
        background: rgba(56, 189, 248, 0.1);
        color: #ffffff;
        border-left-color: var(--sidebar-accent);
    }

    .nav-item.active .nav-link {
        background: rgba(56, 189, 248, 0.15);
        color: #ffffff;
        border-left-color: var(--sidebar-accent);
    }

    .nav-link i {
        font-size: 1.1rem;
        width: 24px;
        text-align: center;
    }

    .link-text {
        flex: 1;
        font-size: 0.9rem;
        font-weight: 500;
    }

    .link-badge {
        font-size: 0.7rem;
        padding: 0.15rem 0.5rem;
        border-radius: 10px;
        font-weight: 600;
        background: rgba(56, 189, 248, 0.1);
        color: var(--sidebar-accent);
        border: 1px solid rgba(56, 189, 248, 0.3);
    }

    .link-badge.new {
        background: rgba(168, 85, 247, 0.1);
        color: #a855f7;
        border-color: rgba(168, 85, 247, 0.3);
    }

    .link-badge.warning {
        background: rgba(251, 191, 36, 0.1);
        color: #fbbf24;
        border-color: rgba(251, 191, 36, 0.3);
    }

    .link-badge.alert {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
        border-color: rgba(239, 68, 68, 0.3);
    }

    /* Sidebar Footer */
    .sidebar-footer {
        margin-top: auto;
        padding: 1.25rem;
        border-top: 1px solid var(--sidebar-border);
        background: rgba(5, 8, 22, 0.8);
    }

    .system-status {
        margin-bottom: 1rem;
    }

    .status-label {
        font-size: 0.75rem;
        color: var(--sidebar-text);
        margin-bottom: 0.25rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .status-value {
        font-size: 0.85rem;
        font-weight: 600;
        color: #34c759;
    }

    .status-value.online {
        color: #34c759;
    }

    .sidebar-actions {
        display: flex;
        justify-content: space-between;
        margin-bottom: 1rem;
    }

    .action-link {
        font-size: 0.8rem;
        color: var(--sidebar-text);
        text-decoration: none;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        gap: 0.25rem;
    }

    .action-link:hover {
        color: #ffffff;
    }

    .action-link.logout {
        color: #ef4444;
    }

    .action-link.logout:hover {
        color: #dc2626;
    }

    .copyright {
        font-size: 0.75rem;
        color: var(--sidebar-text);
        text-align: center;
        margin-top: 0.5rem;
    }

    .version {
        font-size: 0.7rem;
        color: var(--sidebar-text);
        opacity: 0.7;
        margin-top: 0.25rem;
    }

    /* Collapsed State */
    .sidebar.collapsed {
        width: var(--sidebar-collapsed-width);
    }

    .sidebar.collapsed .brand-text,
    .sidebar.collapsed .user-details,
    .sidebar.collapsed .link-text,
    .sidebar.collapsed .link-badge,
    .sidebar.collapsed .section-title,
    .sidebar.collapsed .status-label,
    .sidebar.collapsed .status-value,
    .sidebar.collapsed .action-link span,
    .sidebar.collapsed .copyright,
    .sidebar.collapsed .version {
        display: none;
    }

    .sidebar.collapsed .sidebar-footer {
        padding: 1rem 0.5rem;
    }

    .sidebar.collapsed .sidebar-actions {
        flex-direction: column;
        gap: 0.5rem;
    }

    .sidebar.collapsed .nav-link {
        justify-content: center;
        padding: 0.75rem;
    }

    .sidebar.collapsed .nav-link i {
        font-size: 1.25rem;
    }

    /* Mobile Responsive */
    @media (max-width: 768px) {
        .sidebar {
            transform: translateX(-100%);
            box-shadow: 0 0 40px rgba(0, 0, 0, 0.5);
        }
        
        .sidebar.mobile-open {
            transform: translateX(0);
        }
        
        .sidebar-close {
            display: block;
        }
        
        body.sidebar-open::after {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
            pointer-events: auto;
        }
    }

    /* Scrollbar Styling */
    .sidebar-content::-webkit-scrollbar {
        width: 6px;
    }

    .sidebar-content::-webkit-scrollbar-track {
        background: rgba(148, 163, 253, 0.05);
        border-radius: 3px;
    }

    .sidebar-content::-webkit-scrollbar-thumb {
        background: rgba(148, 163, 253, 0.2);
        border-radius: 3px;
    }

    .sidebar-content::-webkit-scrollbar-thumb:hover {
        background: rgba(148, 163, 253, 0.3);
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const sidebar = document.getElementById('mainSidebar');
        const sidebarClose = document.getElementById('sidebarClose');
        const body = document.body;

        // Close sidebar on mobile
        if (sidebarClose) {
            sidebarClose.addEventListener('click', function() {
                sidebar.classList.remove('mobile-open');
                body.classList.remove('sidebar-open');
            });
        }

        // Toggle collapsed state on desktop
        const toggleSidebar = document.createElement('button');
        toggleSidebar.className = 'sidebar-toggle-collapse d-none d-md-block';
        toggleSidebar.innerHTML = '<i class="bi bi-chevron-left"></i>';
        toggleSidebar.title = 'Toggle Sidebar';
        
        // Add toggle button to sidebar
        if (sidebar) {
            sidebar.appendChild(toggleSidebar);
            
            toggleSidebar.addEventListener('click', function() {
                sidebar.classList.toggle('collapsed');
                const icon = this.querySelector('i');
                if (sidebar.classList.contains('collapsed')) {
                    icon.className = 'bi bi-chevron-right';
                    localStorage.setItem('sidebar-collapsed', 'true');
                } else {
                    icon.className = 'bi bi-chevron-left';
                    localStorage.setItem('sidebar-collapsed', 'false');
                }
            });

            // Load saved state
            const savedState = localStorage.getItem('sidebar-collapsed');
            if (savedState === 'true') {
                sidebar.classList.add('collapsed');
                toggleSidebar.querySelector('i').className = 'bi bi-chevron-right';
            }
        }

        // Mobile sidebar backdrop click
        document.addEventListener('click', function(e) {
            if (window.innerWidth <= 768) {
                if (!sidebar.contains(e.target) && 
                    !e.target.closest('.sidebar-toggle') &&
                    sidebar.classList.contains('mobile-open')) {
                    sidebar.classList.remove('mobile-open');
                    body.classList.remove('sidebar-open');
                }
            }
        });

        // Auto-collapse on mobile
        function handleResize() {
            if (window.innerWidth <= 768) {
                sidebar.classList.remove('collapsed');
            }
        }

        window.addEventListener('resize', handleResize);
        handleResize(); // Initial check

        // Active link highlighting
        const currentPath = window.location.pathname;
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href === currentPath || 
                (href !== '/' && currentPath.startsWith(href))) {
                link.parentElement.classList.add('active');
            }
        });
    });

    // Add sidebar toggle button styles
    const style = document.createElement('style');
    style.textContent = `
        .sidebar-toggle-collapse {
            position: absolute;
            top: 50%;
            right: -12px;
            transform: translateY(-50%);
            width: 24px;
            height: 24px;
            border-radius: 50%;
            background: var(--sidebar-accent-gradient);
            border: 2px solid var(--sidebar-border);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 0.8rem;
            z-index: 1001;
            transition: all 0.3s ease;
            opacity: 0;
        }
        
        .sidebar:hover .sidebar-toggle-collapse {
            opacity: 1;
        }
        
        .sidebar-toggle-collapse:hover {
            transform: translateY(-50%) scale(1.1);
            box-shadow: 0 4px 12px rgba(56, 189, 248, 0.4);
        }
    `;
    document.head.appendChild(style);
</script>