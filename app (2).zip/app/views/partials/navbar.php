<?php
// app/views/partials/navbar.php
// Renders the top navigation bar for logged-in users.

use App\core\Auth;

$app  = app_config();
$user = Auth::user();

$appName = $app['name'] ?? 'ZukBits Workflows System';
?>
<nav class="zb-navbar">
    <!-- Left Section -->
    <div class="navbar-left">
        <button class="sidebar-toggle d-md-none" id="mobileSidebarToggle">
            <i class="bi bi-list"></i>
        </button>
        
        <div class="navbar-brand">
            <div class="brand-logo">
                <span class="logo-icon">ZB</span>
            </div>
            <div class="brand-text">
                <h1 class="brand-title"><?= htmlspecialchars($appName, ENT_QUOTES, 'UTF-8') ?></h1>
                <p class="brand-subtitle">Professional Dashboard</p>
            </div>
        </div>
    </div>

    <!-- Center Section - Search -->
    <div class="navbar-center d-none d-md-flex">
        <div class="navbar-search">
            <i class="bi bi-search search-icon"></i>
            <input type="text" 
                   class="search-input" 
                   placeholder="Search projects, reports, users..."
                   id="globalSearch">
            <div class="search-shortcut">
                <kbd>⌘</kbd>
                <kbd>K</kbd>
            </div>
        </div>
    </div>

    <!-- Right Section - User & Actions -->
    <div class="navbar-right">
        <!-- Quick Actions -->
        <div class="quick-actions d-none d-md-flex">
            <button class="nav-action-btn" id="themeToggle" title="Toggle theme">
                <i class="bi bi-moon"></i>
            </button>
            
            <button class="nav-action-btn" id="fullscreenToggle" title="Fullscreen">
                <i class="bi bi-arrows-fullscreen"></i>
            </button>
            
            <div class="dropdown">
                <button class="nav-action-btn dropdown-toggle" 
                        type="button" 
                        id="notificationsDropdown"
                        data-bs-toggle="dropdown">
                    <i class="bi bi-bell"></i>
                    <span class="notification-count">3</span>
                </button>
                <div class="dropdown-menu dropdown-menu-end notifications-dropdown">
                    <div class="dropdown-header">
                        <h6>Notifications</h6>
                        <a href="/notifications" class="small">View All</a>
                    </div>
                    <div class="dropdown-body">
                        <!-- Notification items would go here -->
                        <div class="notification-item unread">
                            <div class="notification-icon">
                                <i class="bi bi-info-circle"></i>
                            </div>
                            <div class="notification-content">
                                <div class="notification-title">Project Update</div>
                                <div class="notification-text">Quarterly report is ready for review</div>
                                <div class="notification-time">2 min ago</div>
                            </div>
                        </div>
                        <!-- More notifications... -->
                    </div>
                    <div class="dropdown-footer">
                        <a href="/notifications/mark-all-read" class="btn btn-sm btn-outline">Mark all as read</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- User Menu -->
        <div class="user-menu">
            <div class="user-info d-none d-md-block">
                <div class="user-name"><?= htmlspecialchars($user['name'] ?? 'User', ENT_QUOTES, 'UTF-8') ?></div>
                <div class="user-role"><?= htmlspecialchars($user['role_name'] ?? '', ENT_QUOTES, 'UTF-8') ?></div>
            </div>
            
            <div class="dropdown">
                <button class="user-avatar dropdown-toggle" 
                        type="button" 
                        id="userMenuDropdown"
                        data-bs-toggle="dropdown">
                    <div class="avatar-initials">
                        <?= strtoupper(substr($user['name'] ?? 'U', 0, 1)) ?>
                    </div>
                </button>
                <div class="dropdown-menu dropdown-menu-end user-dropdown">
                    <div class="dropdown-header">
                        <div class="d-flex align-items-center gap-2">
                            <div class="dropdown-avatar">
                                <?= strtoupper(substr($user['name'] ?? 'U', 0, 1)) ?>
                            </div>
                            <div>
                                <div class="dropdown-name"><?= htmlspecialchars($user['name'] ?? 'User', ENT_QUOTES, 'UTF-8') ?></div>
                                <div class="dropdown-email text-muted"><?= htmlspecialchars($user['email'] ?? '', ENT_QUOTES, 'UTF-8') ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="dropdown-body">
                        <a href="/profile" class="dropdown-item">
                            <i class="bi bi-person me-2"></i>
                            My Profile
                        </a>
                        <a href="/settings" class="dropdown-item">
                            <i class="bi bi-gear me-2"></i>
                            Settings
                        </a>
                        <a href="/help" class="dropdown-item">
                            <i class="bi bi-question-circle me-2"></i>
                            Help & Support
                        </a>
                        <hr class="dropdown-divider">
                        <a href="/logout" class="dropdown-item text-danger">
                            <i class="bi bi-box-arrow-right me-2"></i>
                            Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</nav>

<style>
    /* Color Variables */
    :root {
        --color-bg: #050816;
        --color-surface: #0b1020;
        --color-surface-alt: #111827;
        --color-text: #f7f7ff;
        --color-text-muted: #c3c5d4;
        --color-border: #22263b;
        --color-accent-blue: #38bdf8;
        --color-accent-purple: #a855f7;
        --color-accent: #ffc857;
        --color-accent-green: #34c759;
        --color-accent-red: #ef4444;
        --gradient-primary: linear-gradient(135deg, var(--color-accent-blue), var(--color-accent-purple));
    }

    /* Navbar Styles */
    .zb-navbar {
        background: var(--color-surface);
        border-bottom: 1px solid var(--color-border);
        padding: 0.75rem 1.5rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
        position: sticky;
        top: 0;
        z-index: 1000;
        backdrop-filter: blur(10px);
        box-shadow: 0 4px 30px rgba(0, 0, 0, 0.3);
    }

    .navbar-left {
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .sidebar-toggle {
        background: none;
        border: none;
        color: var(--color-text);
        font-size: 1.5rem;
        padding: 0.5rem;
        border-radius: 8px;
        transition: all 0.3s ease;
        cursor: pointer;
    }

    .sidebar-toggle:hover {
        background: rgba(56, 189, 248, 0.1);
        color: var(--color-accent-blue);
    }

    .navbar-brand {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        text-decoration: none;
    }

    .brand-logo {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        background: var(--gradient-primary);
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 15px rgba(56, 189, 248, 0.3);
    }

    .logo-icon {
        color: white;
        font-weight: 700;
        font-size: 0.9rem;
    }

    .brand-text {
        line-height: 1.2;
    }

    .brand-title {
        font-size: 1.1rem;
        font-weight: 700;
        margin: 0;
        color: var(--color-text);
        background: var(--gradient-primary);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }

    .brand-subtitle {
        font-size: 0.75rem;
        color: var(--color-text-muted);
        margin: 0;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    /* Search Bar */
    .navbar-center {
        flex: 1;
        max-width: 500px;
        margin: 0 2rem;
    }

    .navbar-search {
        position: relative;
    }

    .search-input {
        width: 100%;
        background: rgba(11, 16, 32, 0.8);
        border: 1px solid var(--color-border);
        border-radius: 10px;
        padding: 0.75rem 1rem 0.75rem 2.75rem;
        color: var(--color-text);
        font-size: 0.9rem;
        transition: all 0.3s ease;
    }

    .search-input:focus {
        outline: none;
        border-color: var(--color-accent-blue);
        box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.15);
        background: rgba(11, 16, 32, 0.95);
    }

    .search-icon {
        position: absolute;
        left: 1rem;
        top: 50%;
        transform: translateY(-50%);
        color: var(--color-text-muted);
        font-size: 1rem;
    }

    .search-shortcut {
        position: absolute;
        right: 1rem;
        top: 50%;
        transform: translateY(-50%);
        display: flex;
        gap: 0.25rem;
    }

    .search-shortcut kbd {
        background: rgba(56, 189, 248, 0.1);
        border: 1px solid rgba(56, 189, 248, 0.3);
        color: var(--color-accent-blue);
        padding: 0.1rem 0.35rem;
        border-radius: 6px;
        font-size: 0.75rem;
        font-family: monospace;
    }

    /* Right Section */
    .navbar-right {
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .quick-actions {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        margin-right: 1rem;
    }

    .nav-action-btn {
        background: none;
        border: none;
        color: var(--color-text-muted);
        font-size: 1.25rem;
        padding: 0.5rem;
        border-radius: 8px;
        transition: all 0.3s ease;
        cursor: pointer;
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
    }

    .nav-action-btn:hover {
        background: rgba(56, 189, 248, 0.1);
        color: var(--color-accent-blue);
    }

    .notification-count {
        position: absolute;
        top: -2px;
        right: -2px;
        background: var(--color-accent-red);
        color: white;
        font-size: 0.7rem;
        font-weight: 700;
        width: 18px;
        height: 18px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    /* Notifications Dropdown */
    .notifications-dropdown {
        min-width: 350px;
        padding: 0;
        border: 1px solid var(--color-border);
        background: var(--color-surface);
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
        border-radius: 12px;
        overflow: hidden;
    }

    .dropdown-header {
        padding: 1rem 1.25rem;
        border-bottom: 1px solid var(--color-border);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .dropdown-header h6 {
        margin: 0;
        font-weight: 600;
        color: var(--color-text);
    }

    .dropdown-header a {
        font-size: 0.8rem;
        color: var(--color-accent-blue);
        text-decoration: none;
    }

    .dropdown-body {
        max-height: 400px;
        overflow-y: auto;
        padding: 0.5rem 0;
    }

    .notification-item {
        display: flex;
        gap: 0.75rem;
        padding: 0.75rem 1.25rem;
        transition: all 0.3s ease;
        border-left: 3px solid transparent;
    }

    .notification-item:hover {
        background: rgba(56, 189, 248, 0.1);
    }

    .notification-item.unread {
        border-left-color: var(--color-accent-blue);
        background: rgba(56, 189, 248, 0.05);
    }

    .notification-icon {
        width: 32px;
        height: 32px;
        border-radius: 8px;
        background: rgba(56, 189, 248, 0.15);
        color: var(--color-accent-blue);
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }

    .notification-content {
        flex: 1;
    }

    .notification-title {
        font-size: 0.9rem;
        font-weight: 600;
        color: var(--color-text);
        margin: 0 0 0.25rem;
    }

    .notification-text {
        font-size: 0.85rem;
        color: var(--color-text-muted);
        margin: 0 0 0.25rem;
    }

    .notification-time {
        font-size: 0.75rem;
        color: var(--color-text-muted);
    }

    .dropdown-footer {
        padding: 1rem 1.25rem;
        border-top: 1px solid var(--color-border);
        text-align: center;
    }

    /* User Menu */
    .user-menu {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .user-info {
        text-align: right;
    }

    .user-name {
        font-size: 0.9rem;
        font-weight: 600;
        color: var(--color-text);
        margin: 0;
    }

    .user-role {
        font-size: 0.75rem;
        color: var(--color-text-muted);
        margin: 0;
        text-transform: capitalize;
    }

    .user-avatar {
        background: none;
        border: none;
        padding: 0;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .avatar-initials {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        background: var(--gradient-primary);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 0.9rem;
        box-shadow: 0 4px 15px rgba(56, 189, 248, 0.3);
        transition: all 0.3s ease;
    }

    .user-avatar:hover .avatar-initials {
        transform: scale(1.05);
        box-shadow: 0 8px 25px rgba(56, 189, 248, 0.4);
    }

    /* User Dropdown */
    .user-dropdown {
        min-width: 280px;
        padding: 0;
        border: 1px solid var(--color-border);
        background: var(--color-surface);
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
        border-radius: 12px;
        overflow: hidden;
    }

    .dropdown-avatar {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        background: var(--gradient-primary);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 1rem;
    }

    .dropdown-name {
        font-weight: 600;
        color: var(--color-text);
        margin: 0 0 0.25rem;
    }

    .dropdown-email {
        font-size: 0.85rem;
    }

    .dropdown-item {
        display: flex;
        align-items: center;
        padding: 0.75rem 1.25rem;
        color: var(--color-text);
        text-decoration: none;
        transition: all 0.3s ease;
    }

    .dropdown-item:hover {
        background: rgba(56, 189, 248, 0.1);
        color: var(--color-accent-blue);
    }

    .dropdown-item i {
        width: 20px;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .zb-navbar {
            padding: 0.75rem 1rem;
        }
        
        .navbar-center {
            display: none;
        }
        
        .quick-actions {
            margin-right: 0.5rem;
        }
        
        .notifications-dropdown {
            min-width: 300px;
            left: -100px !important;
        }
        
        .user-info {
            display: none;
        }
    }

    @media (max-width: 576px) {
        .brand-subtitle {
            display: none;
        }
        
        .notifications-dropdown {
            min-width: 280px;
            left: -120px !important;
        }
        
        .nav-action-btn {
            width: 36px;
            height: 36px;
            font-size: 1.1rem;
        }
        
        .avatar-initials {
            width: 36px;
            height: 36px;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Mobile sidebar toggle
        const mobileSidebarToggle = document.getElementById('mobileSidebarToggle');
        if (mobileSidebarToggle) {
            mobileSidebarToggle.addEventListener('click', function() {
                const sidebar = document.querySelector('.sidebar');
                if (sidebar) {
                    sidebar.classList.toggle('mobile-open');
                    document.body.classList.toggle('sidebar-open');
                }
            });
        }

        // Theme toggle
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', function() {
                const currentTheme = document.body.getAttribute('data-theme') || 'dark';
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
                document.body.setAttribute('data-theme', newTheme);
                localStorage.setItem('zb-theme', newTheme);
                
                // Update icon
                const icon = this.querySelector('i');
                icon.className = newTheme === 'dark' ? 'bi bi-moon' : 'bi bi-sun';
            });
        }

        // Fullscreen toggle
        const fullscreenToggle = document.getElementById('fullscreenToggle');
        if (fullscreenToggle) {
            fullscreenToggle.addEventListener('click', function() {
                if (!document.fullscreenElement) {
                    document.documentElement.requestFullscreen().catch(err => {
                        console.error(`Error attempting to enable fullscreen: ${err.message}`);
                    });
                } else {
                    if (document.exitFullscreen) {
                        document.exitFullscreen();
                    }
                }
            });
        }

        // Global search shortcut
        const globalSearch = document.getElementById('globalSearch');
        if (globalSearch) {
            document.addEventListener('keydown', function(e) {
                // Cmd/Ctrl + K for search
                if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
                    e.preventDefault();
                    globalSearch.focus();
                }
            });
        }

        // Update notification count
        function updateNotificationCount() {
            const unreadCount = document.querySelectorAll('.notification-item.unread').length;
            const countElement = document.querySelector('.notification-count');
            if (countElement) {
                countElement.textContent = unreadCount;
                if (unreadCount === 0) {
                    countElement.style.display = 'none';
                } else {
                    countElement.style.display = 'flex';
                }
            }
        }

        // Mark notifications as read
        document.querySelectorAll('.notification-item').forEach(item => {
            item.addEventListener('click', function() {
                if (this.classList.contains('unread')) {
                    this.classList.remove('unread');
                    updateNotificationCount();
                }
            });
        });

        // Initialize
        updateNotificationCount();
    });
</script>