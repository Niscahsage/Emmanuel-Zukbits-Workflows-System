<?php
// app/views/partials/flash.php
// Displays flash messages stored in session.

use App\core\Helpers;

$flash = Helpers::getFlash();
if (!$flash) {
    return;
}
?>
<div class="zb-flash-container">
    <div class="zb-flash-message">
        <div class="flash-content">
            <i class="bi bi-info-circle-fill flash-icon"></i>
            <div class="flash-text"><?= htmlspecialchars($flash, ENT_QUOTES, 'UTF-8') ?></div>
        </div>
        <button type="button" class="flash-close" onclick="this.parentElement.remove()">
            <i class="bi bi-x"></i>
        </button>
    </div>
</div>

<style>
    .zb-flash-container {
        position: fixed;
        top: 80px;
        right: 20px;
        z-index: 1050;
        max-width: 400px;
        animation: slideIn 0.3s ease-out;
    }

    .zb-flash-message {
        background: linear-gradient(135deg, rgba(56, 189, 248, 0.15), rgba(15, 23, 42, 0.95));
        backdrop-filter: blur(10px);
        border: 1px solid rgba(56, 189, 248, 0.3);
        border-radius: 12px;
        padding: 1rem 1.25rem;
        color: var(--color-accent-blue);
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 1rem;
        position: relative;
        overflow: hidden;
    }

    .zb-flash-message::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 3px;
        background: linear-gradient(90deg, var(--color-accent-blue), var(--color-accent-purple));
        border-radius: 12px 12px 0 0;
    }

    .flash-content {
        display: flex;
        align-items: flex-start;
        gap: 0.75rem;
        flex: 1;
    }

    .flash-icon {
        font-size: 1.25rem;
        margin-top: 0.125rem;
        color: var(--color-accent-blue);
    }

    .flash-text {
        font-size: 0.9rem;
        line-height: 1.4;
        flex: 1;
    }

    .flash-close {
        background: transparent;
        border: none;
        color: var(--color-text-muted);
        font-size: 1.25rem;
        padding: 0;
        cursor: pointer;
        transition: all 0.3s ease;
        flex-shrink: 0;
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 6px;
    }

    .flash-close:hover {
        color: var(--color-text);
        background: rgba(255, 255, 255, 0.1);
    }

    /* Success variant */
    .zb-flash-message.success {
        background: linear-gradient(135deg, rgba(52, 199, 89, 0.15), rgba(15, 23, 42, 0.95));
        border-color: rgba(52, 199, 89, 0.3);
        color: var(--color-accent-green);
    }

    .zb-flash-message.success::before {
        background: linear-gradient(90deg, var(--color-accent-green), #10b981);
    }

    .zb-flash-message.success .flash-icon {
        color: var(--color-accent-green);
    }

    /* Warning variant */
    .zb-flash-message.warning {
        background: linear-gradient(135deg, rgba(251, 191, 36, 0.15), rgba(15, 23, 42, 0.95));
        border-color: rgba(251, 191, 36, 0.3);
        color: var(--color-accent);
    }

    .zb-flash-message.warning::before {
        background: linear-gradient(90deg, var(--color-accent), #f97316);
    }

    .zb-flash-message.warning .flash-icon {
        color: var(--color-accent);
    }

    /* Error variant */
    .zb-flash-message.error {
        background: linear-gradient(135deg, rgba(239, 68, 68, 0.15), rgba(15, 23, 42, 0.95));
        border-color: rgba(239, 68, 68, 0.3);
        color: var(--color-accent-red);
    }

    .zb-flash-message.error::before {
        background: linear-gradient(90deg, var(--color-accent-red), #dc2626);
    }

    .zb-flash-message.error .flash-icon {
        color: var(--color-accent-red);
    }

    /* Animation */
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateX(100%);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }

    @keyframes fadeOut {
        from {
            opacity: 1;
        }
        to {
            opacity: 0;
        }
    }

    /* Auto-remove after 5 seconds */
    .zb-flash-message {
        animation: slideIn 0.3s ease-out, fadeOut 0.3s ease-in 4.7s forwards;
    }

    @media (max-width: 768px) {
        .zb-flash-container {
            top: 70px;
            right: 10px;
            left: 10px;
            max-width: none;
        }
        
        .zb-flash-message {
            padding: 0.875rem 1rem;
        }
        
        .flash-content {
            gap: 0.5rem;
        }
        
        .flash-icon {
            font-size: 1.1rem;
        }
        
        .flash-text {
            font-size: 0.85rem;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const flashMessages = document.querySelectorAll('.zb-flash-message');
        
        flashMessages.forEach(message => {
            // Auto-remove after 5 seconds
            setTimeout(() => {
                message.style.animation = 'fadeOut 0.3s ease-in forwards';
                setTimeout(() => {
                    if (message.parentElement) {
                        message.parentElement.remove();
                    }
                }, 300);
            }, 5000);
            
            // Add click to dismiss
            message.addEventListener('click', function(e) {
                if (!e.target.closest('.flash-close')) {
                    this.style.animation = 'fadeOut 0.3s ease-in forwards';
                    setTimeout(() => {
                        if (this.parentElement) {
                            this.parentElement.remove();
                        }
                    }, 300);
                }
            });
        });
    });
</script>