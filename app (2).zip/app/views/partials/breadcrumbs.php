<?php
// app/views/partials/breadcrumbs.php
// Renders navigational breadcrumbs for deeper pages.

use App\core\View;

/** @var array $breadcrumbs */
if (empty($breadcrumbs) || !is_array($breadcrumbs)) {
    return;
}
?>
<nav aria-label="breadcrumb" class="zb-breadcrumb">
    <ol class="breadcrumb">
        <?php foreach ($breadcrumbs as $i => $b): ?>
            <?php
            $label = View::e($b['label'] ?? '');
            $url   = $b['url'] ?? null;
            $icon  = $b['icon'] ?? null;
            $isLast = ($i === array_key_last($breadcrumbs));
            ?>
            
            <?php if ($isLast || empty($url)): ?>
                <li class="breadcrumb-item active" aria-current="page">
                    <?php if ($icon): ?>
                        <i class="bi <?= View::e($icon) ?> me-2"></i>
                    <?php endif; ?>
                    <?= $label ?>
                </li>
            <?php else: ?>
                <li class="breadcrumb-item">
                    <a href="<?= View::e($url) ?>" class="breadcrumb-link">
                        <?php if ($icon): ?>
                            <i class="bi <?= View::e($icon) ?> me-2"></i>
                        <?php endif; ?>
                        <?= $label ?>
                    </a>
                    <i class="bi bi-chevron-right mx-2 separator"></i>
                </li>
            <?php endif; ?>
        <?php endforeach; ?>
    </ol>
</nav>

<style>
    .zb-breadcrumb {
        margin-bottom: 1.5rem;
    }

    .zb-breadcrumb .breadcrumb {
        background: transparent;
        padding: 0;
        margin: 0;
        list-style: none;
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 0.5rem;
    }

    .zb-breadcrumb .breadcrumb-item {
        display: flex;
        align-items: center;
        color: var(--color-text-muted);
        font-size: 0.9rem;
    }

    .zb-breadcrumb .breadcrumb-item.active {
        color: var(--color-accent);
        font-weight: 600;
    }

    .zb-breadcrumb .breadcrumb-link {
        color: var(--color-text-muted);
        text-decoration: none;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
    }

    .zb-breadcrumb .breadcrumb-link:hover {
        color: var(--color-accent-blue);
    }

    .zb-breadcrumb .separator {
        color: var(--color-border);
        font-size: 0.8rem;
    }

    @media (max-width: 768px) {
        .zb-breadcrumb .breadcrumb {
            gap: 0.25rem;
        }
        
        .zb-breadcrumb .breadcrumb-item {
            font-size: 0.8rem;
        }
        
        .zb-breadcrumb .separator {
            margin: 0 0.25rem;
        }
    }
</style>