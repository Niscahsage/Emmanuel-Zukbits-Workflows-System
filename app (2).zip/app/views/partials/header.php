<?php
// app/views/partials/header.php
// Contains page title, breadcrumbs, and high-level context for a screen.

use App\core\View;

/** @var ?string $pageTitle */
/** @var ?array  $breadcrumbs */
/** @var ?array  $actions */
?>
<div class="zb-page-header">
    <div class="header-content">
        <?php if (!empty($breadcrumbs)): ?>
            <?php require __DIR__ . '/breadcrumbs.php'; ?>
        <?php endif; ?>

        <?php if (!empty($pageTitle)): ?>
            <div class="title-section">
                <h1 class="page-title">
                    <?= View::e($pageTitle) ?>
                </h1>
                <?php if (!empty($subtitle)): ?>
                    <p class="page-subtitle"><?= View::e($subtitle) ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <?php if (!empty($actions) && is_array($actions)): ?>
        <div class="header-actions">
            <?php foreach ($actions as $a): ?>
                <?php
                $label = $a['label'] ?? '';
                $url = $a['url'] ?? '#';
                $type = $a['type'] ?? 'secondary';
                $icon = $a['icon'] ?? null;
                $badge = $a['badge'] ?? null;
                $id = $a['id'] ?? null;
                ?>
                
                <?php if ($type === 'primary'): ?>
                    <a href="<?= View::e($url) ?>" 
                       class="btn-action btn-primary" 
                       <?= $id ? 'id="' . View::e($id) . '"' : '' ?>>
                        <?php if ($icon): ?>
                            <i class="bi <?= View::e($icon) ?>"></i>
                        <?php endif; ?>
                        <?= View::e($label) ?>
                        <?php if ($badge): ?>
                            <span class="action-badge"><?= View::e($badge) ?></span>
                        <?php endif; ?>
                    </a>
                <?php elseif ($type === 'danger'): ?>
                    <a href="<?= View::e($url) ?>" 
                       class="btn-action btn-danger" 
                       <?= $id ? 'id="' . View::e($id) . '"' : '' ?>>
                        <?php if ($icon): ?>
                            <i class="bi <?= View::e($icon) ?>"></i>
                        <?php endif; ?>
                        <?= View::e($label) ?>
                    </a>
                <?php else: ?>
                    <a href="<?= View::e($url) ?>" 
                       class="btn-action btn-secondary" 
                       <?= $id ? 'id="' . View::e($id) . '"' : '' ?>>
                        <?php if ($icon): ?>
                            <i class="bi <?= View::e($icon) ?>"></i>
                        <?php endif; ?>
                        <?= View::e($label) ?>
                        <?php if ($badge): ?>
                            <span class="action-badge"><?= View::e($badge) ?></span>
                        <?php endif; ?>
                    </a>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<style>
    .zb-page-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 2rem;
        padding: 1.5rem;
        background: linear-gradient(135deg, rgba(11, 16, 32, 0.8), rgba(5, 8, 22, 0.9));
        border: 1px solid var(--color-border-light);
        border-radius: 16px;
        backdrop-filter: blur(10px);
        position: relative;
        overflow: hidden;
    }

    .zb-page-header::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(90deg, var(--color-accent-blue), var(--color-accent-purple));
        border-radius: 16px 16px 0 0;
    }

    .header-content {
        flex: 1;
    }

    .title-section {
        margin-top: 0.5rem;
    }

    .page-title {
        font-size: 1.75rem;
        font-weight: 700;
        color: var(--color-text);
        margin: 0 0 0.5rem;
        background: linear-gradient(135deg, var(--color-text), var(--color-accent-blue));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }

    .page-subtitle {
        color: var(--color-text-muted);
        font-size: 0.95rem;
        margin: 0;
        max-width: 600px;
        line-height: 1.5;
    }

    .header-actions {
        display: flex;
        gap: 0.75rem;
        flex-wrap: wrap;
        margin-left: 1.5rem;
    }

    .btn-action {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.625rem 1.25rem;
        border-radius: 10px;
        font-weight: 600;
        font-size: 0.9rem;
        text-decoration: none;
        transition: all 0.3s ease;
        border: 1px solid transparent;
        position: relative;
        white-space: nowrap;
    }

    .btn-primary {
        background: linear-gradient(135deg, var(--color-accent-blue), var(--color-accent-purple));
        color: white;
        box-shadow: 0 4px 15px rgba(56, 189, 248, 0.3);
    }

    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(56, 189, 248, 0.4);
        color: white;
    }

    .btn-secondary {
        background: rgba(11, 16, 32, 0.6);
        border: 1px solid var(--color-border);
        color: var(--color-text);
    }

    .btn-secondary:hover {
        background: rgba(56, 189, 248, 0.1);
        border-color: var(--color-accent-blue);
        color: var(--color-accent-blue);
        transform: translateY(-1px);
    }

    .btn-danger {
        background: linear-gradient(135deg, #ef4444, #dc2626);
        color: white;
        box-shadow: 0 4px 15px rgba(239, 68, 68, 0.3);
    }

    .btn-danger:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(239, 68, 68, 0.4);
        color: white;
    }

    .btn-action i {
        font-size: 1rem;
    }

    .action-badge {
        background: rgba(255, 255, 255, 0.15);
        color: white;
        font-size: 0.7rem;
        padding: 0.15rem 0.5rem;
        border-radius: 10px;
        margin-left: 0.5rem;
        font-weight: 600;
    }

    @media (max-width: 992px) {
        .zb-page-header {
            flex-direction: column;
            gap: 1.5rem;
            padding: 1.25rem;
        }
        
        .header-actions {
            margin-left: 0;
            width: 100%;
            justify-content: flex-start;
        }
    }

    @media (max-width: 768px) {
        .zb-page-header {
            padding: 1rem;
            border-radius: 12px;
        }
        
        .page-title {
            font-size: 1.5rem;
        }
        
        .header-actions {
            flex-wrap: wrap;
        }
        
        .btn-action {
            padding: 0.5rem 1rem;
            font-size: 0.85rem;
        }
    }

    @media (max-width: 576px) {
        .zb-page-header {
            flex-direction: column;
            align-items: stretch;
        }
        
        .header-actions {
            flex-direction: column;
            gap: 0.5rem;
        }
        
        .btn-action {
            justify-content: center;
            width: 100%;
        }
    }
</style>