<?php
// app/views/projects/create.php
// create.php displays the form to create a new project or campaign.

use App\core\View;
?>
<div class="zb-project-create">
    <!-- Page Header -->
    <div class="page-header">
        <div class="header-content">
            <?php require __DIR__ . '/../partials/breadcrumbs.php'; ?>
            <div class="title-section">
                <h1 class="page-title">Create New Project</h1>
                <p class="page-subtitle">
                    Set up a new project or campaign with all necessary details
                </p>
            </div>
        </div>
        <div class="header-actions">
            <a href="/projects" class="btn-action btn-secondary">
                <i class="bi bi-arrow-left"></i>
                Back to Projects
            </a>
        </div>
    </div>

    <!-- Form Wizard Progress -->
    <div class="form-wizard">
        <div class="wizard-steps">
            <div class="wizard-step active">
                <div class="step-number">1</div>
                <div class="step-label">Basic Info</div>
            </div>
            <div class="wizard-step">
                <div class="step-number">2</div>
                <div class="step-label">Details</div>
            </div>
            <div class="wizard-step">
                <div class="step-number">3</div>
                <div class="step-label">Objectives</div>
            </div>
            <div class="wizard-step">
                <div class="step-number">4</div>
                <div class="step-label">Review</div>
            </div>
        </div>
    </div>

    <!-- Main Form -->
    <div class="form-container">
        <form action="/projects/store" method="post" id="projectForm" class="form-card">
            <div class="form-section active" id="section1">
                <h3 class="form-section-title">
                    <i class="bi bi-info-circle"></i>
                    Basic Information
                </h3>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">
                            Project Name *
                            <span class="required-indicator">*</span>
                        </label>
                        <input type="text" 
                               name="name" 
                               class="form-control" 
                               required
                               placeholder="Enter project name"
                               data-validation="required">
                        <div class="form-hint">A clear, descriptive name for your project</div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Project Code (Optional)</label>
                        <input type="text" 
                               name="code" 
                               class="form-control" 
                               placeholder="e.g. ZKB-2025-01"
                               data-validation="alphanumeric">
                        <div class="form-hint">Internal reference code for tracking</div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Category</label>
                        <select name="category" class="form-select" data-validation="required">
                            <option value="">Select Category</option>
                            <option value="web">Web Development</option>
                            <option value="mobile">Mobile App</option>
                            <option value="marketing">Marketing Campaign</option>
                            <option value="research">Research Project</option>
                            <option value="internal">Internal Project</option>
                            <option value="other">Other</option>
                        </select>
                        <div class="form-hint">Primary category for organization</div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Client / Stakeholder</label>
                        <input type="text" 
                               name="client_name" 
                               class="form-control" 
                               placeholder="Client or internal department">
                        <div class="form-hint">Who is this project for?</div>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn-action btn-primary" onclick="nextSection()">
                        Next: Details
                        <i class="bi bi-arrow-right"></i>
                    </button>
                </div>
            </div>
            
            <div class="form-section" id="section2">
                <h3 class="form-section-title">
                    <i class="bi bi-calendar"></i>
                    Project Details
                </h3>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select" data-validation="required">
                            <option value="draft" selected>Draft</option>
                            <option value="planning">Planning</option>
                            <option value="ongoing">Ongoing</option>
                            <option value="on_hold">On Hold</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                        <div class="form-hint">Current project status</div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Priority</label>
                        <select name="priority" class="form-select" data-validation="required">
                            <option value="medium" selected>Medium</option>
                            <option value="low">Low</option>
                            <option value="high">High</option>
                            <option value="critical">Critical</option>
                        </select>
                        <div class="form-hint">Project priority level</div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Start Date</label>
                        <input type="date" 
                               name="start_date" 
                               class="form-control"
                               data-validation="date">
                        <div class="form-hint">When will work begin?</div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Target End Date</label>
                        <input type="date" 
                               name="target_end_date" 
                               class="form-control"
                               data-validation="date">
                        <div class="form-hint">When do you aim to complete?</div>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn-action btn-secondary" onclick="prevSection()">
                        <i class="bi bi-arrow-left"></i>
                        Back
                    </button>
                    <button type="button" class="btn-action btn-primary" onclick="nextSection()">
                        Next: Objectives
                        <i class="bi bi-arrow-right"></i>
                    </button>
                </div>
            </div>
            
            <div class="form-section" id="section3">
                <h3 class="form-section-title">
                    <i class="bi bi-bullseye"></i>
                    Project Objectives
                </h3>
                
                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea name="description" 
                              rows="5" 
                              class="form-control"
                              placeholder="Provide a detailed description of the project..."
                              data-validation="required"></textarea>
                    <div class="form-hint">Describe the project scope and purpose</div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Objectives & Success Metrics</label>
                    <textarea name="objectives" 
                              rows="5" 
                              class="form-control"
                              placeholder="List key goals and how success will be measured..."
                              data-validation="required"></textarea>
                    <div class="form-hint">What are the key deliverables and success criteria?</div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Key Requirements</label>
                    <div class="requirements-list" id="requirementsList">
                        <div class="requirement-item">
                            <input type="text" 
                                   class="form-control requirement-input"
                                   placeholder="Add a key requirement">
                            <button type="button" class="btn-action-sm btn-secondary" onclick="removeRequirement(this)">
                                <i class="bi bi-x"></i>
                            </button>
                        </div>
                    </div>
                    <button type="button" class="btn-action btn-secondary btn-sm" onclick="addRequirement()">
                        <i class="bi bi-plus"></i>
                        Add Requirement
                    </button>
                    <input type="hidden" name="requirements" id="requirementsInput">
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn-action btn-secondary" onclick="prevSection()">
                        <i class="bi bi-arrow-left"></i>
                        Back
                    </button>
                    <button type="button" class="btn-action btn-primary" onclick="nextSection()">
                        Next: Review
                        <i class="bi bi-arrow-right"></i>
                    </button>
                </div>
            </div>
            
            <div class="form-section" id="section4">
                <h3 class="form-section-title">
                    <i class="bi bi-check-circle"></i>
                    Review & Submit
                </h3>
                
                <div class="review-summary">
                    <h4>Project Summary</h4>
                    <div class="review-grid">
                        <div class="review-item">
                            <span class="review-label">Project Name:</span>
                            <span class="review-value" id="reviewName"></span>
                        </div>
                        <div class="review-item">
                            <span class="review-label">Project Code:</span>
                            <span class="review-value" id="reviewCode"></span>
                        </div>
                        <div class="review-item">
                            <span class="review-label">Category:</span>
                            <span class="review-value" id="reviewCategory"></span>
                        </div>
                        <div class="review-item">
                            <span class="review-label">Client:</span>
                            <span class="review-value" id="reviewClient"></span>
                        </div>
                        <div class="review-item">
                            <span class="review-label">Status:</span>
                            <span class="review-value" id="reviewStatus"></span>
                        </div>
                        <div class="review-item">
                            <span class="review-label">Priority:</span>
                            <span class="review-value" id="reviewPriority"></span>
                        </div>
                        <div class="review-item">
                            <span class="review-label">Start Date:</span>
                            <span class="review-value" id="reviewStart"></span>
                        </div>
                        <div class="review-item">
                            <span class="review-label">Target End:</span>
                            <span class="review-value" id="reviewEnd"></span>
                        </div>
                    </div>
                    
                    <div class="review-description">
                        <h5>Description</h5>
                        <p id="reviewDescription"></p>
                    </div>
                    
                    <div class="review-objectives">
                        <h5>Objectives</h5>
                        <p id="reviewObjectives"></p>
                    </div>
                    
                    <div class="review-requirements">
                        <h5>Key Requirements</h5>
                        <ul id="reviewRequirements"></ul>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn-action btn-secondary" onclick="prevSection()">
                        <i class="bi bi-arrow-left"></i>
                        Back
                    </button>
                    <button type="submit" class="btn-action btn-primary">
                        <i class="bi bi-check-circle"></i>
                        Create Project
                    </button>
                </div>
            </div>
        </form>
        
        <!-- Form Sidebar -->
        <div class="form-sidebar">
            <div class="sidebar-card">
                <h4><i class="bi bi-lightbulb"></i> Tips</h4>
                <ul class="tips-list">
                    <li>Be specific with project names for easy identification</li>
                    <li>Set realistic timelines and priorities</li>
                    <li>Define clear objectives and success metrics</li>
                    <li>Include all stakeholders in the planning phase</li>
                    <li>Regularly update progress and communicate changes</li>
                </ul>
            </div>
            
            <div class="sidebar-card">
                <h4><i class="bi bi-clock"></i> Quick Actions</h4>
                <div class="quick-actions">
                    <a href="/projects/templates" class="btn-action btn-secondary btn-block">
                        <i class="bi bi-file-earmark"></i>
                        Use Template
                    </a>
                    <a href="/projects/import" class="btn-action btn-secondary btn-block">
                        <i class="bi bi-upload"></i>
                        Import Project
                    </a>
                </div>
            </div>
            
            <div class="sidebar-card">
                <h4><i class="bi bi-shield-check"></i> Privacy</h4>
                <p class="privacy-note">
                    All project information is securely stored and accessible only to authorized team members.
                </p>
            </div>
        </div>
    </div>
</div>

<style>
    /* Create Project Styles */
    .zb-project-create {
        padding: 1.5rem;
    }

    /* Form Wizard */
    .form-wizard {
        margin: 2rem 0;
    }

    .wizard-steps {
        display: flex;
        justify-content: space-between;
        position: relative;
    }

    .wizard-steps::before {
        content: '';
        position: absolute;
        top: 20px;
        left: 0;
        right: 0;
        height: 2px;
        background: var(--color-border);
        z-index: 1;
    }

    .wizard-step {
        position: relative;
        z-index: 2;
        text-align: center;
        flex: 1;
    }

    .step-number {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: var(--color-border);
        color: var(--color-text-muted);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        margin: 0 auto 0.5rem;
        transition: all 0.3s ease;
        border: 2px solid transparent;
    }

    .wizard-step.active .step-number {
        background: linear-gradient(135deg, var(--color-accent-blue), var(--color-accent-purple));
        color: white;
        border-color: var(--color-accent-blue);
        box-shadow: 0 4px 15px rgba(56, 189, 248, 0.3);
    }

    .step-label {
        font-size: 0.85rem;
        color: var(--color-text-muted);
        font-weight: 500;
    }

    .wizard-step.active .step-label {
        color: var(--color-text);
        font-weight: 600;
    }

    /* Form Container */
    .form-container {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 2rem;
    }

    .form-card {
        background: linear-gradient(135deg, rgba(11, 16, 32, 0.8), rgba(5, 8, 22, 0.9));
        border: 1px solid var(--color-border-light);
        border-radius: 12px;
        padding: 2rem;
    }

    .form-section {
        display: none;
    }

    .form-section.active {
        display: block;
    }

    .form-section-title {
        font-size: 1.25rem;
        font-weight: 600;
        color: var(--color-text);
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .form-section-title i {
        color: var(--color-accent-blue);
    }

    .form-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 1.5rem;
        margin-bottom: 2rem;
    }

    .form-group {
        margin-bottom: 1.5rem;
    }

    .form-label {
        display: block;
        font-weight: 500;
        color: var(--color-text);
        margin-bottom: 0.5rem;
        font-size: 0.9rem;
    }

    .required-indicator {
        color: #ef4444;
        margin-left: 0.25rem;
    }

    .form-control,
    .form-select {
        width: 100%;
        background: rgba(11, 16, 32, 0.8);
        border: 1px solid var(--color-border);
        border-radius: 8px;
        padding: 0.75rem 1rem;
        color: var(--color-text);
        font-size: 0.9rem;
        transition: all 0.3s ease;
    }

    .form-control:focus,
    .form-select:focus {
        outline: none;
        border-color: var(--color-accent-blue);
        box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.15);
        background: rgba(11, 16, 32, 0.95);
    }

    .form-hint {
        font-size: 0.8rem;
        color: var(--color-text-muted);
        margin-top: 0.5rem;
    }

    textarea.form-control {
        min-height: 120px;
        resize: vertical;
    }

    /* Requirements List */
    .requirements-list {
        margin-bottom: 1rem;
    }

    .requirement-item {
        display: flex;
        gap: 0.5rem;
        margin-bottom: 0.5rem;
    }

    .requirement-input {
        flex: 1;
    }

    .btn-action-sm {
        padding: 0.5rem;
        min-width: 40px;
    }

    /* Form Actions */
    .form-actions {
        display: flex;
        justify-content: space-between;
        margin-top: 2rem;
        padding-top: 1.5rem;
        border-top: 1px solid var(--color-border);
    }

    .btn-block {
        width: 100%;
        justify-content: center;
    }

    /* Review Section */
    .review-summary {
        background: rgba(11, 16, 32, 0.5);
        border-radius: 8px;
        padding: 1.5rem;
        margin-bottom: 2rem;
    }

    .review-summary h4 {
        font-size: 1.1rem;
        font-weight: 600;
        color: var(--color-text);
        margin-bottom: 1rem;
        padding-bottom: 0.75rem;
        border-bottom: 1px solid var(--color-border);
    }

    .review-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 1rem;
        margin-bottom: 1.5rem;
    }

    .review-item {
        display: flex;
        justify-content: space-between;
        padding: 0.5rem 0;
        border-bottom: 1px solid rgba(148, 163, 253, 0.1);
    }

    .review-label {
        color: var(--color-text-muted);
        font-size: 0.9rem;
    }

    .review-value {
        color: var(--color-text);
        font-weight: 500;
        text-align: right;
    }

    .review-description,
    .review-objectives,
    .review-requirements {
        margin-bottom: 1.5rem;
    }

    .review-summary h5 {
        font-size: 1rem;
        font-weight: 600;
        color: var(--color-text);
        margin-bottom: 0.5rem;
    }

    .review-description p,
    .review-objectives p {
        color: var(--color-text);
        line-height: 1.6;
        white-space: pre-wrap;
        background: rgba(11, 16, 32, 0.3);
        padding: 1rem;
        border-radius: 8px;
        border-left: 3px solid var(--color-accent-blue);
    }

    .review-requirements ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .review-requirements li {
        color: var(--color-text);
        padding: 0.5rem 0;
        padding-left: 1.5rem;
        position: relative;
    }

    .review-requirements li::before {
        content: '✓';
        position: absolute;
        left: 0;
        color: var(--color-accent-green);
        font-weight: bold;
    }

    /* Form Sidebar */
    .form-sidebar {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
    }

    .sidebar-card {
        background: linear-gradient(135deg, rgba(11, 16, 32, 0.8), rgba(5, 8, 22, 0.9));
        border: 1px solid var(--color-border-light);
        border-radius: 12px;
        padding: 1.5rem;
    }

    .sidebar-card h4 {
        font-size: 1rem;
        font-weight: 600;
        color: var(--color-text);
        margin-bottom: 1rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .sidebar-card h4 i {
        color: var(--color-accent-blue);
    }

    .tips-list {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .tips-list li {
        color: var(--color-text);
        font-size: 0.85rem;
        padding: 0.5rem 0;
        padding-left: 1.5rem;
        position: relative;
        line-height: 1.4;
    }

    .tips-list li::before {
        content: '•';
        position: absolute;
        left: 0;
        color: var(--color-accent-blue);
        font-size: 1.2rem;
    }

    .quick-actions {
        display: flex;
        flex-direction: column;
        gap: 0.75rem;
    }

    .privacy-note {
        color: var(--color-text-muted);
        font-size: 0.85rem;
        line-height: 1.5;
        margin: 0;
    }

    /* Responsive Design */
    @media (max-width: 1200px) {
        .form-container {
            grid-template-columns: 1fr;
        }
        
        .form-sidebar {
            order: -1;
        }
    }

    @media (max-width: 768px) {
        .zb-project-create {
            padding: 1rem;
        }
        
        .form-card {
            padding: 1.5rem;
        }
        
        .form-grid {
            grid-template-columns: 1fr;
            gap: 1rem;
        }
        
        .wizard-step .step-label {
            font-size: 0.75rem;
        }
        
        .step-number {
            width: 32px;
            height: 32px;
            font-size: 0.9rem;
        }
        
        .review-grid {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 576px) {
        .form-actions {
            flex-direction: column;
            gap: 0.75rem;
        }
        
        .form-actions .btn-action {
            width: 100%;
            justify-content: center;
        }
        
        .wizard-step .step-label {
            display: none;
        }
    }
</style>

<script>
    // Form wizard functionality
    let currentSection = 1;
    const totalSections = 4;
    
    function nextSection() {
        if (!validateSection(currentSection)) {
            return;
        }
        
        // Update wizard progress
        document.querySelectorAll('.wizard-step').forEach((step, index) => {
            step.classList.remove('active');
            if (index + 1 === currentSection + 1) {
                step.classList.add('active');
            }
        });
        
        // Hide current section
        document.getElementById(`section${currentSection}`).classList.remove('active');
        
        // Show next section
        currentSection++;
        document.getElementById(`section${currentSection}`).classList.add('active');
        
        // Update review if we're on the last section
        if (currentSection === 4) {
            updateReview();
        }
        
        // Scroll to top of form
        document.querySelector('.form-card').scrollIntoView({ behavior: 'smooth' });
    }
    
    function prevSection() {
        // Update wizard progress
        document.querySelectorAll('.wizard-step').forEach((step, index) => {
            step.classList.remove('active');
            if (index + 1 === currentSection - 1) {
                step.classList.add('active');
            }
        });
        
        // Hide current section
        document.getElementById(`section${currentSection}`).classList.remove('active');
        
        // Show previous section
        currentSection--;
        document.getElementById(`section${currentSection}`).classList.add('active');
        
        // Scroll to top of form
        document.querySelector('.form-card').scrollIntoView({ behavior: 'smooth' });
    }
    
    function validateSection(section) {
        const sectionEl = document.getElementById(`section${section}`);
        const inputs = sectionEl.querySelectorAll('[data-validation]');
        
        for (const input of inputs) {
            const validation = input.dataset.validation;
            const value = input.value.trim();
            
            if (input.hasAttribute('required') && !value) {
                showError(input, 'This field is required');
                return false;
            }
            
            switch (validation) {
                case 'alphanumeric':
                    if (value && !/^[a-zA-Z0-9\-\s]+$/.test(value)) {
                        showError(input, 'Only letters, numbers, and hyphens allowed');
                        return false;
                    }
                    break;
                case 'date':
                    if (value && isNaN(Date.parse(value))) {
                        showError(input, 'Please enter a valid date');
                        return false;
                    }
                    break;
            }
        }
        
        return true;
    }
    
    function showError(input, message) {
        // Remove any existing error
        const existingError = input.parentElement.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }
        
        // Add error styling
        input.style.borderColor = '#ef4444';
        input.style.boxShadow = '0 0 0 3px rgba(239, 68, 68, 0.15)';
        
        // Create error message
        const error = document.createElement('div');
        error.className = 'error-message';
        error.style.color = '#ef4444';
        error.style.fontSize = '0.8rem';
        error.style.marginTop = '0.5rem';
        error.textContent = message;
        
        input.parentElement.appendChild(error);
        
        // Scroll to error
        input.scrollIntoView({ behavior: 'smooth', block: 'center' });
        input.focus();
    }
    
    // Requirements functionality
    function addRequirement() {
        const list = document.getElementById('requirementsList');
        const item = document.createElement('div');
        item.className = 'requirement-item';
        item.innerHTML = `
            <input type="text" class="form-control requirement-input" placeholder="Add a key requirement">
            <button type="button" class="btn-action-sm btn-secondary" onclick="removeRequirement(this)">
                <i class="bi bi-x"></i>
            </button>
        `;
        list.appendChild(item);
        
        // Focus the new input
        item.querySelector('.requirement-input').focus();
    }
    
    function removeRequirement(button) {
        const item = button.closest('.requirement-item');
        if (document.querySelectorAll('.requirement-item').length > 1) {
            item.remove();
        } else {
            // Don't remove the last one, just clear it
            item.querySelector('.requirement-input').value = '';
        }
    }
    
    // Update review section
    function updateReview() {
        // Collect form data
        const formData = {
            name: document.querySelector('[name="name"]').value,
            code: document.querySelector('[name="code"]').value || 'Not specified',
            category: document.querySelector('[name="category"]').value || 'Not specified',
            client_name: document.querySelector('[name="client_name"]').value || 'Not specified',
            status: document.querySelector('[name="status"]').value || 'Not specified',
            priority: document.querySelector('[name="priority"]').value || 'Not specified',
            start_date: document.querySelector('[name="start_date"]').value || 'Not specified',
            target_end_date: document.querySelector('[name="target_end_date"]').value || 'Not specified',
            description: document.querySelector('[name="description"]').value || 'Not specified',
            objectives: document.querySelector('[name="objectives"]').value || 'Not specified'
        };
        
        // Update review display
        document.getElementById('reviewName').textContent = formData.name;
        document.getElementById('reviewCode').textContent = formData.code;
        document.getElementById('reviewCategory').textContent = formData.category;
        document.getElementById('reviewClient').textContent = formData.client_name;
        document.getElementById('reviewStatus').textContent = formData.status.replace('_', ' ');
        document.getElementById('reviewPriority').textContent = formData.priority;
        document.getElementById('reviewStart').textContent = formData.start_date;
        document.getElementById('reviewEnd').textContent = formData.target_end_date;
        document.getElementById('reviewDescription').textContent = formData.description;
        document.getElementById('reviewObjectives').textContent = formData.objectives;
        
        // Update requirements
        const requirementsList = document.getElementById('reviewRequirements');
        requirementsList.innerHTML = '';
        
        const requirementInputs = document.querySelectorAll('.requirement-input');
        requirementInputs.forEach(input => {
            if (input.value.trim()) {
                const li = document.createElement('li');
                li.textContent = input.value;
                requirementsList.appendChild(li);
            }
        });
        
        // Update hidden requirements input
        const requirements = Array.from(requirementInputs)
            .map(input => input.value.trim())
            .filter(value => value);
        document.getElementById('requirementsInput').value = JSON.stringify(requirements);
    }
    
    // Form submission
    document.getElementById('projectForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (!validateSection(currentSection)) {
            return;
        }
        
        // Update requirements input before submit
        updateReview();
        
        // Show loading state
        const submitBtn = this.querySelector('button[type="submit"]');
        const originalHTML = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="bi bi-hourglass-split"></i> Creating Project...';
        submitBtn.disabled = true;
        
        // Simulate API call
        setTimeout(() => {
            // In a real application, this would submit the form
            console.log('Form submitted:', new FormData(this));
            
            // For demo, show success message
            showSuccessMessage();
        }, 1500);
    });
    
    function showSuccessMessage() {
        const success = document.createElement('div');
        success.className = 'success-message';
        success.innerHTML = `
            <div class="success-content">
                <i class="bi bi-check-circle-fill"></i>
                <div>
                    <h4>Project Created Successfully!</h4>
                    <p>Your project has been created and is now ready for team collaboration.</p>
                </div>
            </div>
            <div class="success-actions">
                <a href="/projects" class="btn-action btn-secondary">View All Projects</a>
                <a href="/projects/show?id=<?= $id ?? 'new' ?>" class="btn-action btn-primary">View Project</a>
            </div>
        `;
        
        // Replace form with success message
        const formCard = document.querySelector('.form-card');
        formCard.innerHTML = '';
        formCard.appendChild(success);
        
        // Add success styling
        success.style.padding = '2rem';
        success.style.textAlign = 'center';
        
        const successContent = success.querySelector('.success-content');
        successContent.style.display = 'flex';
        successContent.style.flexDirection = 'column';
        successContent.style.alignItems = 'center';
        successContent.style.gap = '1rem';
        successContent.style.marginBottom = '2rem';
        
        successContent.querySelector('i').style.color = '#34c759';
        successContent.querySelector('i').style.fontSize = '3rem';
        
        successContent.querySelector('h4').style.fontSize = '1.5rem';
        successContent.querySelector('h4').style.fontWeight = '600';
        successContent.querySelector('h4').style.color = 'var(--color-text)';
        successContent.querySelector('h4').style.margin = '0 0 0.5rem';
        
        successContent.querySelector('p').style.color = 'var(--color-text-muted)';
        
        const successActions = success.querySelector('.success-actions');
        successActions.style.display = 'flex';
        successActions.style.gap = '1rem';
        successActions.style.justifyContent = 'center';
        
        // Auto-redirect after 5 seconds
        setTimeout(() => {
            window.location.href = '/projects';
        }, 5000);
    }
    
    // Auto-save functionality
    let autoSaveTimeout;
    document.querySelectorAll('.form-control, .form-select').forEach(input => {
        input.addEventListener('input', () => {
            clearTimeout(autoSaveTimeout);
            autoSaveTimeout = setTimeout(() => {
                saveDraft();
            }, 1000);
        });
    });
    
    function saveDraft() {
        console.log('Auto-saving draft...');
        // In a real app, this would save to localStorage or send to server
    }
    
    // Load draft on page load
    document.addEventListener('DOMContentLoaded', () => {
        // Load any saved draft
        const savedDraft = localStorage.getItem('projectDraft');
        if (savedDraft) {
            try {
                const draft = JSON.parse(savedDraft);
                Object.keys(draft).forEach(key => {
                    const input = document.querySelector(`[name="${key}"]`);
                    if (input) {
                        input.value = draft[key];
                    }
                });
                
                // Show draft restored notification
                showToast('Draft restored from auto-save', 'info');
            } catch (e) {
                console.error('Failed to load draft:', e);
            }
        }
    });
    
    function showToast(message, type) {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <i class="bi bi-info-circle-fill"></i>
                <span>${message}</span>
            </div>
            <button class="toast-close" onclick="this.parentElement.remove()">
                <i class="bi bi-x"></i>
            </button>
        `;
        
        const container = document.querySelector('.toast-container') || createToastContainer();
        container.appendChild(toast);
        
        setTimeout(() => {
            if (toast.parentElement) {
                toast.remove();
            }
        }, 3000);
    }
    
    function createToastContainer() {
        const container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
        return container;
    }
</script>