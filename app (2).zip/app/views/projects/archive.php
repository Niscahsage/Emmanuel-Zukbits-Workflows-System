<?php
// app/views/projects/archive.php
// archive.php lists archived or completed projects for reference.

/** @var array $projects */

use App\core\View;
use App\core\Auth;

$user = Auth::user();
$roleKey = $user['role_key'] ?? '';
?>
<div class="zb-project-archive">
    <!-- Page Header -->
    <div class="page-header">
        <div class="header-content">
            <?php require __DIR__ . '/../partials/breadcrumbs.php'; ?>
            <div class="title-section">
                <h1 class="page-title">Archived Projects</h1>
                <p class="page-subtitle">
                    Historical projects kept for reference and reporting
                </p>
            </div>
        </div>
        <div class="header-actions">
            <a href="/projects" class="btn-action btn-primary">
                <i class="bi bi-arrow-left"></i>
                Back to Active
            </a>
            <button class="btn-action btn-secondary" onclick="exportArchive()">
                <i class="bi bi-download"></i>
                Export Archive
            </button>
        </div>
    </div>

    <?php if (empty($projects)): ?>
        <!-- Empty State -->
        <div class="empty-state">
            <div class="empty-icon">
                <i class="bi bi-archive"></i>
            </div>
            <h3>No Archived Projects</h3>
            <p>No archived or completed projects found in the system.</p>
            <a href="/projects/create" class="btn-action btn-primary">
                <i class="bi bi-plus-circle"></i>
                Create New Project
            </a>
        </div>
    <?php else: ?>
        <!-- Archive Stats -->
        <div class="archive-stats">
            <div class="stats-grid">
                <?php
                $total = count($projects);
                $completed = 0;
                $cancelled = 0;
                $onHold = 0;
                $totalDuration = 0;
                
                foreach ($projects as $p) {
                    $status = $p['status'] ?? '';
                    if ($status === 'completed') $completed++;
                    elseif ($status === 'cancelled') $cancelled++;
                    elseif ($status === 'on_hold') $onHold++;
                    
                    // Calculate duration if dates exist
                    $start = $p['start_date'] ?? '';
                    $end = $p['completed_at'] ?? $p['updated_at'] ?? '';
                    if ($start && $end) {
                        $startTime = strtotime($start);
                        $endTime = strtotime($end);
                        $totalDuration += ($endTime - $startTime) / (60 * 60 * 24); // Days
                    }
                }
                
                $avgDuration = $total > 0 ? round($totalDuration / $total) : 0;
                ?>
                
                <div class="stat-card">
                    <div class="stat-value"><?= $total ?></div>
                    <div class="stat-label">Total Archived</div>
                    <div class="stat-trend">
                        <span class="trend-up">Historical records</span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-value text-success"><?= $completed ?></div>
                    <div class="stat-label">Successfully Completed</div>
                    <div class="stat-trend">
                        <span class="trend-up"><?= $total > 0 ? round(($completed / $total) * 100) : 0 ?>% success rate</span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-value text-warning"><?= $onHold ?></div>
                    <div class="stat-label">On Hold</div>
                    <div class="stat-trend">
                        <span class="trend-up">May resume</span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-value text-danger"><?= $cancelled ?></div>
                    <div class="stat-label">Cancelled</div>
                    <div class="stat-trend">
                        <span class="trend-down">Terminated early</span>
                    </div>
                </div>
            </div>
            
            <div class="stats-grid mt-3">
                <div class="stat-card">
                    <div class="stat-value"><?= $avgDuration ?></div>
                    <div class="stat-label">Avg. Duration (Days)</div>
                    <div class="stat-trend">
                        <span class="trend-up">Across all projects</span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-value"><?= date('Y') ?></div>
                    <div class="stat-label">Current Year</div>
                    <div class="stat-trend">
                        <span class="trend-up">Archive maintained</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filter and Search -->
        <div class="filter-section">
            <div class="search-box">
                <i class="bi bi-search search-icon"></i>
                <input type="text" 
                       class="search-input" 
                       placeholder="Search archived projects..."
                       id="archiveSearch"
                       onkeyup="filterProjects()">
            </div>
            
            <div class="filter-buttons">
                <div class="filter-group">
                    <button class="filter-btn active" data-filter="all" onclick="setFilter('all')">
                        All (<?= $total ?>)
                    </button>
                    <button class="filter-btn" data-filter="completed" onclick="setFilter('completed')">
                        Completed (<?= $completed ?>)
                    </button>
                    <button class="filter-btn" data-filter="cancelled" onclick="setFilter('cancelled')">
                        Cancelled (<?= $cancelled ?>)
                    </button>
                    <button class="filter-btn" data-filter="on_hold" onclick="setFilter('on_hold')">
                        On Hold (<?= $onHold ?>)
                    </button>
                </div>
            </div>
        </div>

        <!-- Projects Grid -->
        <div class="projects-grid" id="projectsGrid">
            <?php foreach ($projects as $p): ?>
                <?php
                $id = (int) ($p['id'] ?? 0);
                $name = $p['name'] ?? '';
                $code = $p['code'] ?? '';
                $status = $p['status'] ?? '';
                $client = $p['client_name'] ?? '';
                $completedAt = $p['completed_at'] ?? $p['updated_at'] ?? '';
                $description = $p['description'] ?? '';
                $category = $p['category'] ?? '';
                
                // Status colors
                $statusClass = '';
                if ($status === 'completed') {
                    $statusClass = 'status-completed';
                } elseif ($status === 'cancelled') {
                    $statusClass = 'status-cancelled';
                } elseif ($status === 'on_hold') {
                    $statusClass = 'status-on-hold';
                }
                
                // Format date
                $formattedDate = $completedAt ? date('M j, Y', strtotime($completedAt)) : '';
                $timeAgo = $completedAt ? time_ago($completedAt) : '';
                
                // Truncate description
                $truncatedDesc = strlen($description) > 120 ? substr($description, 0, 120) . '...' : $description;
                ?>
                
                <div class="project-card" data-status="<?= $status ?>" data-category="<?= strtolower($category) ?>">
                    <div class="card-header">
                        <div class="project-status <?= $statusClass ?>">
                            <i class="bi <?= $status === 'completed' ? 'bi-check-circle' : ($status === 'cancelled' ? 'bi-x-circle' : 'bi-pause-circle') ?>"></i>
                            <?= ucwords(str_replace('_', ' ', $status)) ?>
                        </div>
                        <div class="project-actions">
                            <a href="/projects/show?id=<?= View::e((string)$id) ?>" class="btn-action-sm">
                                <i class="bi bi-eye"></i>
                            </a>
                            <?php if (in_array($roleKey, ['super_admin', 'director', 'system_admin'])): ?>
                                <a href="/projects/restore?id=<?= View::e((string)$id) ?>" class="btn-action-sm btn-warning">
                                    <i class="bi bi-arrow-counterclockwise"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="card-body">
                        <h3 class="project-title">
                            <?= View::e($name) ?>
                            <?php if ($code): ?>
                                <span class="project-code"><?= View::e($code) ?></span>
                            <?php endif; ?>
                        </h3>
                        
                        <?php if ($category): ?>
                            <div class="project-category">
                                <i class="bi bi-tag"></i>
                                <?= View::e($category) ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($client): ?>
                            <div class="project-client">
                                <i class="bi bi-building"></i>
                                <?= View::e($client) ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($truncatedDesc): ?>
                            <p class="project-description">
                                <?= nl2br(View::e($truncatedDesc)) ?>
                            </p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="card-footer">
                        <div class="project-meta">
                            <?php if ($formattedDate): ?>
                                <div class="meta-item">
                                    <i class="bi bi-calendar-check"></i>
                                    <span><?= $formattedDate ?></span>
                                    <?php if ($timeAgo): ?>
                                        <small class="text-muted">(<?= $timeAgo ?>)</small>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            <div class="meta-item">
                                <i class="bi bi-clock-history"></i>
                                <span>Archived</span>
                            </div>
                        </div>
                        <a href="/projects/show?id=<?= View::e((string)$id) ?>" class="btn-action btn-secondary btn-sm">
                            View Details
                            <i class="bi bi-arrow-right"></i>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Table View (Alternative) -->
        <div class="table-view-toggle">
            <button class="btn-action btn-secondary" onclick="toggleView()">
                <i class="bi bi-table"></i>
                Switch to Table View
            </button>
        </div>

        <div class="archive-table" id="archiveTable" style="display: none;">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Archived Projects - Table View</h3>
                    <div class="card-actions">
                        <button class="btn-action btn-secondary" onclick="exportTable()">
                            <i class="bi bi-download"></i>
                            Export CSV
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Code</th>
                                    <th>Status</th>
                                    <th>Client</th>
                                    <th>Category</th>
                                    <th>Completed At</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($projects as $p): ?>
                                    <?php
                                    $id = (int) ($p['id'] ?? 0);
                                    ?>
                                    <tr>
                                        <td>
                                            <strong><?= View::e($p['name'] ?? '') ?></strong>
                                        </td>
                                        <td>
                                            <span class="badge-id"><?= View::e($p['code'] ?? '') ?></span>
                                        </td>
                                        <td>
                                            <span class="status-badge status-<?= $p['status'] ?? '' ?>">
                                                <?= ucwords(str_replace('_', ' ', $p['status'] ?? '')) ?>
                                            </span>
                                        </td>
                                        <td><?= View::e($p['client_name'] ?? '') ?></td>
                                        <td><?= View::e($p['category'] ?? '') ?></td>
                                        <td>
                                            <div class="date-cell">
                                                <i class="bi bi-calendar"></i>
                                                <?= View::e($p['completed_at'] ?? $p['updated_at'] ?? '') ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="/projects/show?id=<?= View::e((string)$id) ?>" class="btn-action-sm btn-secondary">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                                <?php if (in_array($roleKey, ['super_admin', 'director', 'system_admin'])): ?>
                                                    <a href="/projects/restore?id=<?= View::e((string)$id) ?>" class="btn-action-sm btn-warning">
                                                        <i class="bi bi-arrow-counterclockwise"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<style>
    /* Archive Styles */
    .zb-project-archive {
        padding: 1.5rem;
    }

    /* Stats Grid */
    .archive-stats {
        margin-bottom: 2rem;
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
    }

    .stat-card {
        background: linear-gradient(135deg, rgba(11, 16, 32, 0.8), rgba(5, 8, 22, 0.9));
        border: 1px solid var(--color-border-light);
        border-radius: 12px;
        padding: 1.25rem;
        transition: all 0.3s ease;
    }

    .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
    }

    .stat-value {
        font-size: 2rem;
        font-weight: 700;
        color: var(--color-text);
        margin-bottom: 0.25rem;
    }

    .stat-label {
        font-size: 0.85rem;
        color: var(--color-text-muted);
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 0.5rem;
    }

    .stat-trend {
        font-size: 0.8rem;
        display: flex;
        align-items: center;
        gap: 0.25rem;
    }

    .trend-up {
        color: var(--color-accent-green);
    }

    .trend-down {
        color: var(--color-accent-red);
    }

    /* Filter Section */
    .filter-section {
        margin-bottom: 2rem;
        display: flex;
        flex-direction: column;
        gap: 1rem;
    }

    .search-box {
        position: relative;
        max-width: 400px;
    }

    .search-input {
        width: 100%;
        background: rgba(11, 16, 32, 0.8);
        border: 1px solid var(--color-border);
        border-radius: 10px;
        padding: 0.75rem 1rem 0.75rem 2.5rem;
        color: var(--color-text);
        font-size: 0.9rem;
        transition: all 0.3s ease;
    }

    .search-input:focus {
        outline: none;
        border-color: var(--color-accent-blue);
        box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.15);
        background: rgba(11, 16, 32, 0.95);
    }

    .search-icon {
        position: absolute;
        left: 0.75rem;
        top: 50%;
        transform: translateY(-50%);
        color: var(--color-text-muted);
        font-size: 1rem;
    }

    .filter-buttons {
        display: flex;
        gap: 1rem;
        flex-wrap: wrap;
    }

    .filter-group {
        display: flex;
        gap: 0.5rem;
        flex-wrap: wrap;
    }

    .filter-btn {
        padding: 0.5rem 1rem;
        background: rgba(11, 16, 32, 0.6);
        border: 1px solid var(--color-border);
        color: var(--color-text-muted);
        border-radius: 8px;
        font-size: 0.85rem;
        font-weight: 500;
        transition: all 0.3s ease;
        cursor: pointer;
    }

    .filter-btn:hover {
        border-color: var(--color-accent-blue);
        color: var(--color-accent-blue);
    }

    .filter-btn.active {
        background: linear-gradient(135deg, var(--color-accent-blue), var(--color-accent-purple));
        color: white;
        border-color: transparent;
    }

    /* Projects Grid */
    .projects-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
        gap: 1.5rem;
        margin-bottom: 2rem;
    }

    .project-card {
        background: linear-gradient(135deg, rgba(11, 16, 32, 0.8), rgba(5, 8, 22, 0.9));
        border: 1px solid var(--color-border-light);
        border-radius: 12px;
        overflow: hidden;
        transition: all 0.3s ease;
        display: flex;
        flex-direction: column;
    }

    .project-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.4);
        border-color: var(--color-accent-blue);
    }

    .card-header {
        padding: 1rem 1.25rem;
        border-bottom: 1px solid var(--color-border);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .project-status {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-size: 0.8rem;
        font-weight: 600;
        padding: 0.25rem 0.75rem;
        border-radius: 20px;
    }

    .status-completed {
        background: rgba(52, 199, 89, 0.15);
        color: var(--color-accent-green);
        border: 1px solid rgba(52, 199, 89, 0.3);
    }

    .status-cancelled {
        background: rgba(239, 68, 68, 0.15);
        color: var(--color-accent-red);
        border: 1px solid rgba(239, 68, 68, 0.3);
    }

    .status-on-hold {
        background: rgba(251, 191, 36, 0.15);
        color: var(--color-accent);
        border: 1px solid rgba(251, 191, 36, 0.3);
    }

    .project-actions {
        display: flex;
        gap: 0.5rem;
    }

    .btn-action-sm {
        padding: 0.375rem;
        border-radius: 6px;
        font-size: 0.85rem;
        min-width: 32px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: rgba(11, 16, 32, 0.6);
        border: 1px solid var(--color-border);
        color: var(--color-text);
        transition: all 0.3s ease;
    }

    .btn-action-sm:hover {
        border-color: var(--color-accent-blue);
        color: var(--color-accent-blue);
        background: rgba(56, 189, 248, 0.1);
    }

    .btn-action-sm.btn-warning:hover {
        border-color: var(--color-accent);
        color: var(--color-accent);
        background: rgba(251, 191, 36, 0.1);
    }

    .card-body {
        padding: 1.25rem;
        flex: 1;
    }

    .project-title {
        font-size: 1.1rem;
        font-weight: 600;
        color: var(--color-text);
        margin: 0 0 0.75rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .project-code {
        font-size: 0.8rem;
        font-family: monospace;
        background: rgba(148, 163, 253, 0.1);
        color: var(--color-text);
        padding: 0.15rem 0.5rem;
        border-radius: 4px;
    }

    .project-category,
    .project-client {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        color: var(--color-text-muted);
        font-size: 0.85rem;
        margin-bottom: 0.5rem;
    }

    .project-category i,
    .project-client i {
        color: var(--color-accent-blue);
    }

    .project-description {
        color: var(--color-text);
        font-size: 0.9rem;
        line-height: 1.5;
        margin: 1rem 0 0;
        opacity: 0.9;
    }

    .card-footer {
        padding: 1rem 1.25rem;
        border-top: 1px solid var(--color-border);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .project-meta {
        display: flex;
        flex-direction: column;
        gap: 0.25rem;
    }

    .meta-item {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        color: var(--color-text-muted);
        font-size: 0.8rem;
    }

    .meta-item i {
        color: var(--color-text-muted);
    }

    .btn-action.btn-sm {
        padding: 0.375rem 0.75rem;
        font-size: 0.8rem;
    }

    /* Table View */
    .table-view-toggle {
        text-align: center;
        margin: 2rem 0;
    }

    .archive-table {
        margin-top: 2rem;
    }

    .card {
        background: linear-gradient(135deg, rgba(11, 16, 32, 0.8), rgba(5, 8, 22, 0.9));
        border: 1px solid var(--color-border-light);
        border-radius: 12px;
        overflow: hidden;
    }

    .card-header {
        padding: 1.25rem;
        border-bottom: 1px solid var(--color-border);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .card-title {
        font-size: 1.1rem;
        font-weight: 600;
        color: var(--color-text);
        margin: 0;
    }

    .card-body {
        padding: 1.25rem;
    }

    .table {
        width: 100%;
        color: var(--color-text);
        border-collapse: separate;
        border-spacing: 0;
    }

    .table thead th {
        border-bottom: 2px solid var(--color-border);
        padding: 0.75rem 1rem;
        font-weight: 600;
        color: var(--color-text-muted);
        text-transform: uppercase;
        font-size: 0.8rem;
        letter-spacing: 0.5px;
        background: rgba(11, 16, 32, 0.5);
    }

    .table tbody td {
        padding: 1rem;
        border-bottom: 1px solid var(--color-border);
        vertical-align: middle;
    }

    .table tbody tr:hover {
        background: rgba(56, 189, 248, 0.05);
    }

    .badge-id {
        background: rgba(148, 163, 253, 0.1);
        color: var(--color-text);
        padding: 0.25rem 0.5rem;
        border-radius: 6px;
        font-family: monospace;
        font-weight: 600;
    }

    .status-badge {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .status-completed {
        background: rgba(52, 199, 89, 0.15);
        color: var(--color-accent-green);
        border: 1px solid rgba(52, 199, 89, 0.3);
    }

    .status-cancelled {
        background: rgba(239, 68, 68, 0.15);
        color: var(--color-accent-red);
        border: 1px solid rgba(239, 68, 68, 0.3);
    }

    .status-on_hold {
        background: rgba(251, 191, 36, 0.15);
        color: var(--color-accent);
        border: 1px solid rgba(251, 191, 36, 0.3);
    }

    .date-cell {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-size: 0.85rem;
    }

    .date-cell i {
        color: var(--color-text-muted);
    }

    .action-buttons {
        display: flex;
        gap: 0.5rem;
    }

    /* Responsive */
    @media (max-width: 1200px) {
        .projects-grid {
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        }
    }

    @media (max-width: 992px) {
        .projects-grid {
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        }
        
        .filter-section {
            flex-direction: column;
        }
    }

    @media (max-width: 768px) {
        .zb-project-archive {
            padding: 1rem;
        }
        
        .projects-grid {
            grid-template-columns: 1fr;
        }
        
        .stats-grid {
            grid-template-columns: repeat(2, 1fr);
        }
        
        .card-footer {
            flex-direction: column;
            gap: 1rem;
            align-items: flex-start;
        }
    }

    @media (max-width: 576px) {
        .stats-grid {
            grid-template-columns: 1fr;
        }
        
        .filter-group {
            justify-content: center;
        }
        
        .table {
            display: block;
            overflow-x: auto;
        }
    }
</style>

<script>
    // Time ago helper function
    function time_ago(datetime) {
        const date = new Date(datetime);
        const now = new Date();
        const seconds = Math.floor((now - date) / 1000);
        
        let interval = seconds / 31536000;
        if (interval > 1) return Math.floor(interval) + " years ago";
        
        interval = seconds / 2592000;
        if (interval > 1) return Math.floor(interval) + " months ago";
        
        interval = seconds / 86400;
        if (interval > 1) return Math.floor(interval) + " days ago";
        
        interval = seconds / 3600;
        if (interval > 1) return Math.floor(interval) + " hours ago";
        
        interval = seconds / 60;
        if (interval > 1) return Math.floor(interval) + " minutes ago";
        
        return "just now";
    }
    
    // Filter projects by status
    function setFilter(status) {
        const buttons = document.querySelectorAll('.filter-btn');
        buttons.forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.filter === status) {
                btn.classList.add('active');
            }
        });
        
        const projects = document.querySelectorAll('.project-card');
        projects.forEach(project => {
            if (status === 'all' || project.dataset.status === status) {
                project.style.display = 'block';
                setTimeout(() => {
                    project.style.opacity = '1';
                    project.style.transform = 'scale(1)';
                }, 10);
            } else {
                project.style.opacity = '0';
                project.style.transform = 'scale(0.9)';
                setTimeout(() => {
                    project.style.display = 'none';
                }, 300);
            }
        });
    }
    
    // Search filter
    function filterProjects() {
        const search = document.getElementById('archiveSearch').value.toLowerCase();
        const projects = document.querySelectorAll('.project-card');
        
        projects.forEach(project => {
            const title = project.querySelector('.project-title').textContent.toLowerCase();
            const description = project.querySelector('.project-description')?.textContent.toLowerCase() || '';
            const client = project.querySelector('.project-client')?.textContent.toLowerCase() || '';
            const category = project.querySelector('.project-category')?.textContent.toLowerCase() || '';
            
            const matches = title.includes(search) || 
                           description.includes(search) || 
                           client.includes(search) || 
                           category.includes(search);
            
            if (matches) {
                project.style.display = 'block';
                setTimeout(() => {
                    project.style.opacity = '1';
                    project.style.transform = 'scale(1)';
                }, 10);
            } else {
                project.style.opacity = '0';
                project.style.transform = 'scale(0.9)';
                setTimeout(() => {
                    project.style.display = 'none';
                }, 300);
            }
        });
    }
    
    // Toggle between grid and table view
    function toggleView() {
        const grid = document.getElementById('projectsGrid');
        const table = document.getElementById('archiveTable');
        const button = event.target.closest('.btn-action');
        
        if (grid.style.display !== 'none') {
            grid.style.display = 'none';
            table.style.display = 'block';
            button.innerHTML = '<i class="bi bi-grid"></i> Switch to Grid View';
        } else {
            grid.style.display = 'grid';
            table.style.display = 'none';
            button.innerHTML = '<i class="bi bi-table"></i> Switch to Table View';
        }
    }
    
    // Export archive data
    function exportArchive() {
        console.log('Exporting archive...');
        
        const btn = event.target.closest('.btn-action');
        const originalHTML = btn.innerHTML;
        btn.innerHTML = '<i class="bi bi-hourglass-split"></i> Exporting...';
        btn.disabled = true;
        
        setTimeout(() => {
            const data = 'Name,Code,Status,Client,Category,Completed At\n' +
                <?php 
                $exportData = [];
                foreach ($projects as $p) {
                    $exportData[] = [
                        $p['name'] ?? '',
                        $p['code'] ?? '',
                        $p['status'] ?? '',
                        $p['client_name'] ?? '',
                        $p['category'] ?? '',
                        $p['completed_at'] ?? $p['updated_at'] ?? ''
                    ];
                }
                echo json_encode($exportData);
                ?>.map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
            
            const blob = new Blob([data], { type: 'text/csv' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `project-archive-<?= date('Y-m-d') ?>.csv`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            
            btn.innerHTML = originalHTML;
            btn.disabled = false;
            
            showToast('Archive exported successfully', 'success');
        }, 1000);
    }
    
    function exportTable() {
        exportArchive(); // Reuse same function
    }
    
    function showToast(message, type) {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <i class="bi bi-check-circle-fill"></i>
                <span>${message}</span>
            </div>
            <button class="toast-close" onclick="this.parentElement.remove()">
                <i class="bi bi-x"></i>
            </button>
        `;
        
        const container = document.querySelector('.toast-container') || createToastContainer();
        container.appendChild(toast);
        
        setTimeout(() => {
            if (toast.parentElement) {
                toast.remove();
            }
        }, 3000);
    }
    
    function createToastContainer() {
        const container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
        return container;
    }
</script>

<?php
// Helper function for time ago
function time_ago($datetime) {
    $time = strtotime($datetime);
    $now = time();
    $diff = $now - $time;
    
    if ($diff < 60) {
        return 'just now';
    } elseif ($diff < 3600) {
        $minutes = floor($diff / 60);
        return $minutes . ' min ago';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . ' hour' . ($hours != 1 ? 's' : '') . ' ago';
    } else {
        $days = floor($diff / 86400);
        if ($days == 1) {
            return 'yesterday';
        } else {
            return $days . ' days ago';
        }
    }
}
?>