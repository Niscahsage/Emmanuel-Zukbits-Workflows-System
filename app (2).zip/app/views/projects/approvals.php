<?php
// app/views/projects/approvals.php
// approvals.php shows the approval status and history for a specific project.

/** @var array $project */
/** @var array $approvals */

use App\core\View;
use App\core\Auth;

$user = Auth::user();
$id    = (int) ($project['id'] ?? 0);
$name  = $project['name'] ?? '';
$code  = $project['code'] ?? '';
?>
<div class="zb-project-approvals">
    <!-- Page Header -->
    <div class="page-header">
        <div class="header-content">
            <?php require __DIR__ . '/../partials/breadcrumbs.php'; ?>
            <div class="title-section">
                <h1 class="page-title">Approval History</h1>
                <p class="page-subtitle">
                    For project: <strong><?= View::e($name) ?></strong>
                    <?php if ($code): ?> • <?= View::e($code) ?><?php endif; ?>
                </p>
            </div>
        </div>
        <div class="header-actions">
            <a href="/projects/show?id=<?= View::e((string)$id) ?>" class="btn-action btn-secondary">
                <i class="bi bi-arrow-left"></i>
                Back to Project
            </a>
        </div>
    </div>

    <?php if (empty($approvals)): ?>
        <!-- Empty State -->
        <div class="empty-state">
            <div class="empty-icon">
                <i class="bi bi-clipboard-check"></i>
            </div>
            <h3>No Approval Requests</h3>
            <p>No approval requests have been recorded for this project yet.</p>
            <a href="/approvals/create?project_id=<?= View::e((string)$id) ?>" class="btn-action btn-primary">
                <i class="bi bi-plus-circle"></i>
                Create First Approval
            </a>
        </div>
    <?php else: ?>
        <!-- Approval Stats -->
        <div class="approval-stats">
            <div class="stats-grid">
                <?php
                $total = count($approvals);
                $approved = 0;
                $pending = 0;
                $rejected = 0;
                
                foreach ($approvals as $a) {
                    $status = $a['status'] ?? 'pending';
                    if ($status === 'approved') $approved++;
                    elseif ($status === 'rejected') $rejected++;
                    else $pending++;
                }
                ?>
                
                <div class="stat-card">
                    <div class="stat-value"><?= $total ?></div>
                    <div class="stat-label">Total Requests</div>
                    <div class="stat-trend">
                        <span class="trend-up">All approvals</span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-value text-success"><?= $approved ?></div>
                    <div class="stat-label">Approved</div>
                    <div class="stat-trend">
                        <span class="trend-up"><?= $total > 0 ? round(($approved / $total) * 100) : 0 ?>% success rate</span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-value text-warning"><?= $pending ?></div>
                    <div class="stat-label">Pending</div>
                    <div class="stat-trend">
                        <span class="trend-up">Awaiting review</span>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-value text-danger"><?= $rejected ?></div>
                    <div class="stat-label">Rejected</div>
                    <div class="stat-trend">
                        <span class="trend-down">Requires attention</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Approval Timeline -->
        <div class="timeline-container">
            <h3 class="timeline-title">Approval Timeline</h3>
            <div class="timeline">
                <?php foreach ($approvals as $a): ?>
                    <?php
                    $aid = (int) ($a['id'] ?? 0);
                    $type = $a['approval_type'] ?? '';
                    $status = $a['status'] ?? 'pending';
                    $requester = $a['requester_name'] ?? ($a['requested_by'] ?? '');
                    $createdAt = $a['created_at'] ?? '';
                    $updatedAt = $a['updated_at'] ?? '';
                    
                    // Format dates
                    $requestDate = $createdAt ? date('M j, Y', strtotime($createdAt)) : '';
                    $decisionDate = $updatedAt ? date('M j, Y', strtotime($updatedAt)) : '';
                    
                    // Status colors
                    $statusClass = '';
                    $statusIcon = '';
                    if ($status === 'approved') {
                        $statusClass = 'approved';
                        $statusIcon = 'bi-check-circle-fill';
                    } elseif ($status === 'rejected') {
                        $statusClass = 'rejected';
                        $statusIcon = 'bi-x-circle-fill';
                    } else {
                        $statusClass = 'pending';
                        $statusIcon = 'bi-clock-fill';
                    }
                    ?>
                    
                    <div class="timeline-item <?= $statusClass ?>">
                        <div class="timeline-marker">
                            <i class="bi <?= $statusIcon ?>"></i>
                        </div>
                        <div class="timeline-content">
                            <div class="timeline-header">
                                <div class="timeline-title">
                                    <h4>#<?= View::e((string)$aid) ?> - <?= View::e(ucwords(str_replace('_', ' ', $type))) ?></h4>
                                    <span class="status-badge <?= $statusClass ?>">
                                        <?= ucfirst($status) ?>
                                    </span>
                                </div>
                                <div class="timeline-actions">
                                    <a href="/approvals/show?id=<?= View::e((string)$aid) ?>" class="btn-timeline">
                                        <i class="bi bi-eye"></i>
                                        View Details
                                    </a>
                                </div>
                            </div>
                            
                            <div class="timeline-body">
                                <div class="timeline-meta">
                                    <div class="meta-item">
                                        <i class="bi bi-person"></i>
                                        <span>Requested by: <strong><?= View::e($requester) ?></strong></span>
                                    </div>
                                    <div class="meta-item">
                                        <i class="bi bi-calendar"></i>
                                        <span>Requested: <?= View::e($requestDate) ?></span>
                                    </div>
                                    <?php if ($decisionDate): ?>
                                        <div class="meta-item">
                                            <i class="bi bi-calendar-check"></i>
                                            <span>Decided: <?= View::e($decisionDate) ?></span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Approval Table (Detailed View) -->
        <div class="approval-table-container">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">All Approval Requests</h3>
                    <div class="card-actions">
                        <button class="btn-action btn-secondary" onclick="exportApprovals()">
                            <i class="bi bi-download"></i>
                            Export
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Type</th>
                                    <th>Status</th>
                                    <th>Requester</th>
                                    <th>Requested</th>
                                    <th>Last Decision</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($approvals as $a): ?>
                                    <?php
                                    $aid = (int) ($a['id'] ?? 0);
                                    $type = $a['approval_type'] ?? '';
                                    $status = $a['status'] ?? 'pending';
                                    $requester = $a['requester_name'] ?? ($a['requested_by'] ?? '');
                                    $createdAt = $a['created_at'] ?? '';
                                    $updatedAt = $a['updated_at'] ?? '';
                                    ?>
                                    <tr>
                                        <td>
                                            <span class="badge-id">#<?= View::e((string)$aid) ?></span>
                                        </td>
                                        <td>
                                            <div class="type-cell">
                                                <i class="bi bi-clipboard-check"></i>
                                                <?= View::e(ucwords(str_replace('_', ' ', $type))) ?>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="status-badge status-<?= $status ?>">
                                                <?= ucfirst($status) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="user-cell">
                                                <div class="user-avatar-sm">
                                                    <?= strtoupper(substr($requester, 0, 1)) ?>
                                                </div>
                                                <?= View::e($requester) ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="date-cell">
                                                <i class="bi bi-calendar"></i>
                                                <?= View::e($createdAt) ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="date-cell">
                                                <i class="bi bi-clock"></i>
                                                <?= $updatedAt ? View::e($updatedAt) : '<span class="text-muted">—</span>' ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="/approvals/show?id=<?= View::e((string)$aid) ?>" class="btn-action-sm btn-secondary">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                                <?php if (in_array($user['role_key'] ?? '', ['super_admin', 'director', 'system_admin'])): ?>
                                                    <a href="/approvals/edit?id=<?= View::e((string)$aid) ?>" class="btn-action-sm btn-secondary">
                                                        <i class="bi bi-pencil"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<style>
    /* Project Approvals Styles */
    .zb-project-approvals {
        padding: 1.5rem;
    }

    /* Empty State */
    .empty-state {
        text-align: center;
        padding: 3rem 2rem;
        background: linear-gradient(135deg, rgba(11, 16, 32, 0.8), rgba(5, 8, 22, 0.9));
        border: 1px solid var(--color-border-light);
        border-radius: 16px;
        margin-top: 2rem;
    }

    .empty-icon {
        width: 80px;
        height: 80px;
        background: linear-gradient(135deg, rgba(56, 189, 248, 0.15), rgba(168, 85, 247, 0.15));
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 1.5rem;
        color: var(--color-accent-blue);
        font-size: 2rem;
    }

    .empty-state h3 {
        font-size: 1.5rem;
        font-weight: 600;
        color: var(--color-text);
        margin-bottom: 0.5rem;
    }

    .empty-state p {
        color: var(--color-text-muted);
        margin-bottom: 1.5rem;
        max-width: 400px;
        margin-left: auto;
        margin-right: auto;
    }

    /* Stats Grid */
    .approval-stats {
        margin-bottom: 2rem;
    }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
    }

    .stat-card {
        background: linear-gradient(135deg, rgba(11, 16, 32, 0.8), rgba(5, 8, 22, 0.9));
        border: 1px solid var(--color-border-light);
        border-radius: 12px;
        padding: 1.25rem;
        transition: all 0.3s ease;
    }

    .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
    }

    .stat-value {
        font-size: 2rem;
        font-weight: 700;
        color: var(--color-text);
        margin-bottom: 0.25rem;
    }

    .stat-label {
        font-size: 0.85rem;
        color: var(--color-text-muted);
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 0.5rem;
    }

    .stat-trend {
        font-size: 0.8rem;
        display: flex;
        align-items: center;
        gap: 0.25rem;
    }

    .trend-up {
        color: var(--color-accent-green);
    }

    .trend-down {
        color: var(--color-accent-red);
    }

    .stat-card .text-success {
        color: var(--color-accent-green);
    }

    .stat-card .text-warning {
        color: var(--color-accent);
    }

    .stat-card .text-danger {
        color: var(--color-accent-red);
    }

    /* Timeline */
    .timeline-container {
        margin-bottom: 2rem;
    }

    .timeline-title {
        font-size: 1.25rem;
        font-weight: 600;
        color: var(--color-text);
        margin-bottom: 1.5rem;
    }

    .timeline {
        position: relative;
        padding-left: 2rem;
    }

    .timeline::before {
        content: '';
        position: absolute;
        left: 0.75rem;
        top: 0;
        bottom: 0;
        width: 2px;
        background: var(--color-border);
    }

    .timeline-item {
        position: relative;
        margin-bottom: 1.5rem;
    }

    .timeline-marker {
        position: absolute;
        left: -2rem;
        top: 0;
        width: 1.5rem;
        height: 1.5rem;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1;
    }

    .timeline-item.approved .timeline-marker {
        background: rgba(52, 199, 89, 0.2);
        color: var(--color-accent-green);
    }

    .timeline-item.rejected .timeline-marker {
        background: rgba(239, 68, 68, 0.2);
        color: var(--color-accent-red);
    }

    .timeline-item.pending .timeline-marker {
        background: rgba(251, 191, 36, 0.2);
        color: var(--color-accent);
    }

    .timeline-content {
        background: linear-gradient(135deg, rgba(11, 16, 32, 0.8), rgba(5, 8, 22, 0.9));
        border: 1px solid var(--color-border-light);
        border-radius: 12px;
        padding: 1.25rem;
        transition: all 0.3s ease;
    }

    .timeline-item:hover .timeline-content {
        border-color: var(--color-accent-blue);
        transform: translateX(5px);
    }

    .timeline-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 1rem;
    }

    .timeline-title h4 {
        font-size: 1rem;
        font-weight: 600;
        color: var(--color-text);
        margin: 0;
    }

    .status-badge {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .status-badge.approved {
        background: rgba(52, 199, 89, 0.15);
        color: var(--color-accent-green);
        border: 1px solid rgba(52, 199, 89, 0.3);
    }

    .status-badge.rejected {
        background: rgba(239, 68, 68, 0.15);
        color: var(--color-accent-red);
        border: 1px solid rgba(239, 68, 68, 0.3);
    }

    .status-badge.pending {
        background: rgba(251, 191, 36, 0.15);
        color: var(--color-accent);
        border: 1px solid rgba(251, 191, 36, 0.3);
    }

    .timeline-actions .btn-timeline {
        padding: 0.375rem 0.75rem;
        font-size: 0.8rem;
    }

    .timeline-body {
        padding-top: 1rem;
        border-top: 1px solid var(--color-border);
    }

    .timeline-meta {
        display: flex;
        flex-wrap: wrap;
        gap: 1rem;
    }

    .meta-item {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        color: var(--color-text-muted);
        font-size: 0.85rem;
    }

    .meta-item i {
        color: var(--color-accent-blue);
    }

    .meta-item strong {
        color: var(--color-text);
    }

    /* Table Styles */
    .approval-table-container {
        margin-top: 2rem;
    }

    .card {
        background: linear-gradient(135deg, rgba(11, 16, 32, 0.8), rgba(5, 8, 22, 0.9));
        border: 1px solid var(--color-border-light);
        border-radius: 12px;
        overflow: hidden;
    }

    .card-header {
        padding: 1.25rem;
        border-bottom: 1px solid var(--color-border);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .card-title {
        font-size: 1.1rem;
        font-weight: 600;
        color: var(--color-text);
        margin: 0;
    }

    .card-body {
        padding: 1.25rem;
    }

    .table {
        width: 100%;
        color: var(--color-text);
        border-collapse: separate;
        border-spacing: 0;
    }

    .table thead th {
        border-bottom: 2px solid var(--color-border);
        padding: 0.75rem 1rem;
        font-weight: 600;
        color: var(--color-text-muted);
        text-transform: uppercase;
        font-size: 0.8rem;
        letter-spacing: 0.5px;
        background: rgba(11, 16, 32, 0.5);
    }

    .table tbody td {
        padding: 1rem;
        border-bottom: 1px solid var(--color-border);
        vertical-align: middle;
    }

    .table tbody tr:hover {
        background: rgba(56, 189, 248, 0.05);
    }

    .badge-id {
        background: rgba(148, 163, 253, 0.1);
        color: var(--color-text);
        padding: 0.25rem 0.5rem;
        border-radius: 6px;
        font-family: monospace;
        font-weight: 600;
    }

    .type-cell {
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .user-cell {
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .user-avatar-sm {
        width: 24px;
        height: 24px;
        border-radius: 6px;
        background: linear-gradient(135deg, var(--color-accent-blue), var(--color-accent-purple));
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.75rem;
        font-weight: 600;
    }

    .date-cell {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-size: 0.85rem;
    }

    .date-cell i {
        color: var(--color-text-muted);
    }

    .action-buttons {
        display: flex;
        gap: 0.5rem;
    }

    .btn-action-sm {
        padding: 0.375rem;
        border-radius: 6px;
        font-size: 0.85rem;
        min-width: 32px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }

    /* Status badges in table */
    .status-badge.status-approved {
        background: rgba(52, 199, 89, 0.15);
        color: var(--color-accent-green);
        border: 1px solid rgba(52, 199, 89, 0.3);
    }

    .status-badge.status-rejected {
        background: rgba(239, 68, 68, 0.15);
        color: var(--color-accent-red);
        border: 1px solid rgba(239, 68, 68, 0.3);
    }

    .status-badge.status-pending {
        background: rgba(251, 191, 36, 0.15);
        color: var(--color-accent);
        border: 1px solid rgba(251, 191, 36, 0.3);
    }

    @media (max-width: 768px) {
        .zb-project-approvals {
            padding: 1rem;
        }
        
        .timeline-header {
            flex-direction: column;
            gap: 0.75rem;
        }
        
        .timeline-meta {
            flex-direction: column;
            gap: 0.5rem;
        }
        
        .table {
            display: block;
            overflow-x: auto;
        }
        
        .stats-grid {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    @media (max-width: 576px) {
        .stats-grid {
            grid-template-columns: 1fr;
        }
        
        .timeline::before {
            left: 0.875rem;
        }
        
        .timeline-marker {
            left: -1.5rem;
            width: 1.25rem;
            height: 1.25rem;
            font-size: 0.75rem;
        }
    }
</style>

<script>
    function exportApprovals() {
        // In a real implementation, this would trigger a CSV/PDF export
        console.log('Exporting approvals...');
        
        // Show loading state
        const btn = event.target.closest('.btn-action');
        const originalHTML = btn.innerHTML;
        btn.innerHTML = '<i class="bi bi-hourglass-split"></i> Exporting...';
        btn.disabled = true;
        
        // Simulate export process
        setTimeout(() => {
            // Create a dummy download
            const data = 'ID,Type,Status,Requester,Requested,Last Decision\n' +
                <?php 
                $exportData = [];
                foreach ($approvals as $a) {
                    $exportData[] = [
                        $a['id'] ?? '',
                        $a['approval_type'] ?? '',
                        $a['status'] ?? '',
                        $a['requester_name'] ?? '',
                        $a['created_at'] ?? '',
                        $a['updated_at'] ?? ''
                    ];
                }
                echo json_encode($exportData);
                ?>.map(row => row.join(',')).join('\n');
            
            const blob = new Blob([data], { type: 'text/csv' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `project-<?= $id ?>-approvals-<?= date('Y-m-d') ?>.csv`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            
            // Reset button
            btn.innerHTML = originalHTML;
            btn.disabled = false;
            
            // Show success message
            showToast('Approvals exported successfully', 'success');
        }, 1000);
    }
    
    function showToast(message, type) {
        // Create toast element
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <i class="bi bi-check-circle-fill"></i>
                <span>${message}</span>
            </div>
            <button class="toast-close" onclick="this.parentElement.remove()">
                <i class="bi bi-x"></i>
            </button>
        `;
        
        // Add to container
        const container = document.querySelector('.toast-container') || createToastContainer();
        container.appendChild(toast);
        
        // Auto remove after 3 seconds
        setTimeout(() => {
            if (toast.parentElement) {
                toast.remove();
            }
        }, 3000);
    }
    
    function createToastContainer() {
        const container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
        return container;
    }
</script>

<style>
    /* Toast Styles */
    .toast-container {
        position: fixed;
        top: 1rem;
        right: 1rem;
        z-index: 9999;
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .toast {
        background: linear-gradient(135deg, rgba(11, 16, 32, 0.95), rgba(5, 8, 22, 0.98));
        border: 1px solid var(--color-border-light);
        border-radius: 8px;
        padding: 0.75rem 1rem;
        color: var(--color-text);
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 0.75rem;
        min-width: 300px;
        max-width: 400px;
        animation: slideIn 0.3s ease-out;
    }

    .toast-success {
        border-left: 4px solid var(--color-accent-green);
    }

    .toast-error {
        border-left: 4px solid var(--color-accent-red);
    }

    .toast-content {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        flex: 1;
    }

    .toast-content i {
        color: var(--color-accent-green);
        font-size: 1.1rem;
    }

    .toast-error .toast-content i {
        color: var(--color-accent-red);
    }

    .toast-close {
        background: none;
        border: none;
        color: var(--color-text-muted);
        cursor: pointer;
        padding: 0.25rem;
        border-radius: 4px;
        transition: all 0.3s ease;
    }

    .toast-close:hover {
        background: rgba(255, 255, 255, 0.1);
        color: var(--color-text);
    }

    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateX(100%);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }

    @media (max-width: 576px) {
        .toast-container {
            left: 1rem;
            right: 1rem;
        }
        
        .toast {
            min-width: auto;
            max-width: none;
        }
    }
</style>