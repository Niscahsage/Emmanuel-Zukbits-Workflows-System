<?php
// reset_password.php displays the form for users to set a new password.

use App\core\View;

// token is typically provided in the reset link as ?token=...
$token = $_GET['token'] ?? '';
$email = $_GET['email'] ?? '';

// Check for error
$error = $_GET['error'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Set New Password - ZukBits</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="/styles/auth.css">
</head>
<body class="auth-page">
    <!-- Decorative elements -->
    <div class="auth-decoration decoration-1"></div>
    <div class="auth-decoration decoration-2"></div>
    
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-card-header">
                <div class="auth-logo">
                    <div class="auth-logo-icon">
                        <i class="bi bi-shield-lock"></i>
                    </div>
                    <span class="auth-logo-text">ZukBits</span>
                </div>
                <h1 class="h5 mt-4 mb-2">Set new password</h1>
                <p class="auth-subtitle">
                    Choose a strong password for your account.
                </p>
            </div>

            <div class="auth-card-body">
                <?php if ($error): ?>
                    <div class="auth-alert auth-alert-warning">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i>
                        This password reset link is invalid or has expired.
                    </div>
                <?php endif; ?>
                
                <form method="post" action="/reset-password" class="auth-form">
                    <input type="hidden" name="token" value="<?= View::e($token) ?>">

                    <div class="mb-4">
                        <label for="email" class="form-label">
                            <i class="bi bi-envelope me-2"></i>Email Address
                        </label>
                        <div class="position-relative">
                            <input
                                type="email"
                                name="email"
                                id="email"
                                class="form-control"
                                required
                                autocomplete="email"
                                value="<?= View::e($email) ?>"
                                readonly
                            >
                            <i class="bi bi-envelope position-absolute top-50 end-0 translate-middle-y me-3 text-muted"></i>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="password" class="form-label">
                            <i class="bi bi-lock me-2"></i>New Password
                        </label>
                        <div class="position-relative">
                            <input
                                type="password"
                                name="password"
                                id="password"
                                class="form-control"
                                required
                                autocomplete="new-password"
                                placeholder="••••••••"
                            >
                            <button type="button" class="password-toggle">
                                <i class="bi bi-eye"></i>
                            </button>
                        </div>
                        <div class="password-strength">
                            <div class="strength-bar">
                                <div class="strength-fill"></div>
                            </div>
                            <div class="strength-text">Password strength: None</div>
                        </div>
                        <div class="form-text mt-2">
                            <i class="bi bi-info-circle me-1"></i>
                            Use at least 8 characters with letters, numbers, and symbols
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="password_confirmation" class="form-label">
                            <i class="bi bi-lock-fill me-2"></i>Confirm New Password
                        </label>
                        <div class="position-relative">
                            <input
                                type="password"
                                name="password_confirmation"
                                id="password_confirmation"
                                class="form-control"
                                required
                                autocomplete="new-password"
                                placeholder="••••••••"
                            >
                            <button type="button" class="password-toggle">
                                <i class="bi bi-eye"></i>
                            </button>
                        </div>
                    </div>

                    <div class="d-grid gap-3">
                        <button type="submit" class="auth-btn">
                            <i class="bi bi-check-circle me-2"></i>Set New Password
                        </button>
                        
                        <a href="/login" class="auth-back-link text-center">
                            <i class="bi bi-arrow-left"></i>Back to login
                        </a>
                    </div>
                </form>
            </div>

            <div class="auth-card-footer">
                <div class="copyright">
                    <i class="bi bi-shield-fill-check me-1"></i>
                    &copy; <?= View::e(date('Y')) ?> ZukBits Online
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/scripts/auth.js"></script>
</body>
</html>