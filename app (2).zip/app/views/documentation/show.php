<?php
// show.php displays the full content of a documentation entry.

/** @var array $document */

use App\core\View;

$id        = (int) ($document['id'] ?? 0);
$title     = $document['title'] ?? '';
$project   = $document['project_name'] ?? ($document['project_id'] ?? '');
$type      = $document['type'] ?? '';
$tags      = $document['tags'] ?? '';
$body      = $document['body'] ?? '';
$createdBy = $document['created_by_name'] ?? ($document['created_by'] ?? '');
$createdAt = $document['created_at'] ?? '';
$updatedAt = $document['updated_at'] ?? '';

// Prepare tags array
$tagArray = $tags ? explode(',', $tags) : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= View::e($title) ?> - Documentation - ZukBits</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --color-bg: #050816;
            --color-surface: #0b1020;
            --color-surface-alt: #111827;
            --color-surface-soft: #0f172a;
            --color-accent: #ffc857;
            --color-accent-strong: #fbbf24;
            --color-accent-blue: #38bdf8;
            --color-accent-purple: #a855f7;
            --color-accent-green: #34c759;
            --color-text: #f7f7ff;
            --color-text-muted: #c3c5d4;
            --color-border: #22263b;
            --gradient-primary: linear-gradient(135deg, var(--color-accent-blue), var(--color-accent-purple));
            --gradient-bg-card: radial-gradient(circle at top left, rgba(148, 163, 253, 0.18), rgba(15, 23, 42, 0.96));
        }

        body {
            background: var(--color-bg);
            color: var(--color-text);
            min-height: 100vh;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
        }

        .document-container {
            padding: 1.5rem;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Header Styles */
        .document-header {
            background: var(--gradient-bg-card);
            border: 1px solid var(--color-border);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            position: relative;
            overflow: hidden;
            border-top: 4px solid var(--color-accent-green);
        }

        .document-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--gradient-primary);
        }

        .document-title {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 1rem;
            color: var(--color-text);
            line-height: 1.3;
        }

        .document-title::after {
            content: '';
            display: block;
            width: 60px;
            height: 4px;
            background: var(--gradient-primary);
            margin-top: 0.75rem;
            border-radius: 2px;
        }

        .document-subtitle {
            color: var(--color-text-muted);
            font-size: 1rem;
        }

        .doc-id-badge {
            background: var(--color-surface-alt);
            border: 1px solid var(--color-border);
            color: var(--color-accent-blue);
            font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
            padding: 0.5rem 1rem;
            border-radius: 12px;
            font-size: 0.9rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 0.75rem;
            flex-wrap: wrap;
        }

        .btn-primary {
            background: var(--gradient-primary);
            border: none;
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(56, 189, 248, 0.25);
        }

        .btn-outline {
            background: transparent;
            border: 1px solid var(--color-border);
            color: var(--color-text);
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 500;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
        }

        .btn-outline:hover {
            background: var(--color-surface-alt);
            border-color: var(--color-border-light);
        }

        /* Metadata Card */
        .metadata-card {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: 16px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .metadata-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
        }

        .metadata-item {
            margin-bottom: 1.5rem;
        }

        .metadata-label {
            color: var(--color-text-muted);
            font-size: 0.875rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .metadata-value {
            color: var(--color-text);
            font-size: 1.1rem;
            font-weight: 500;
        }

        .metadata-value.empty {
            color: var(--color-text-muted);
            font-style: italic;
        }

        .project-badge {
            background: rgba(56, 189, 248, 0.1);
            border: 1px solid rgba(56, 189, 248, 0.2);
            color: var(--color-accent-blue);
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.95rem;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .type-badge {
            background: rgba(168, 85, 247, 0.1);
            border: 1px solid rgba(168, 85, 247, 0.2);
            color: var(--color-accent-purple);
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.95rem;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .tags-container {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }

        .tag {
            background: rgba(255, 200, 87, 0.1);
            border: 1px solid rgba(255, 200, 87, 0.2);
            color: var(--color-accent);
            padding: 0.5rem 0.75rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
        }

        .tag:hover {
            background: rgba(255, 200, 87, 0.2);
            cursor: pointer;
        }

        .author-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .author-avatar {
            width: 40px;
            height: 40px;
            background: var(--gradient-primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        .author-details {
            display: flex;
            flex-direction: column;
        }

        .author-name {
            color: var(--color-text);
            font-weight: 500;
        }

        .author-date {
            color: var(--color-text-muted);
            font-size: 0.85rem;
        }

        /* Content Card */
        .content-card {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .content-header {
            background: var(--color-surface-alt);
            padding: 1.5rem 2rem;
            border-bottom: 1px solid var(--color-border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .content-title {
            font-weight: 600;
            font-size: 1.25rem;
            color: var(--color-text);
            margin: 0;
        }

        .content-actions {
            display: flex;
            gap: 0.5rem;
        }

        .content-action-btn {
            background: transparent;
            border: 1px solid var(--color-border);
            color: var(--color-text-muted);
            padding: 0.5rem 0.75rem;
            border-radius: 8px;
            font-size: 0.875rem;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .content-action-btn:hover {
            background: var(--color-surface-soft);
            color: var(--color-text);
        }

        .content-body {
            padding: 2rem;
            min-height: 300px;
        }

        .document-content {
            color: var(--color-text);
            line-height: 1.8;
            font-size: 1.05rem;
        }

        .document-content pre {
            background: var(--color-bg);
            border: 1px solid var(--color-border);
            border-radius: 12px;
            padding: 1.5rem;
            overflow-x: auto;
            margin: 1.5rem 0;
            font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
            font-size: 0.95rem;
            line-height: 1.6;
        }

        .document-content code {
            background: var(--color-bg);
            border: 1px solid var(--color-border);
            padding: 0.125rem 0.375rem;
            border-radius: 4px;
            font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
            font-size: 0.9em;
        }

        .document-content h1,
        .document-content h2,
        .document-content h3,
        .document-content h4 {
            color: var(--color-text);
            margin-top: 2rem;
            margin-bottom: 1rem;
            font-weight: 600;
        }

        .document-content h1 {
            font-size: 2rem;
            border-bottom: 2px solid var(--color-border);
            padding-bottom: 0.5rem;
        }

        .document-content h2 {
            font-size: 1.75rem;
        }

        .document-content h3 {
            font-size: 1.5rem;
        }

        .document-content ul,
        .document-content ol {
            padding-left: 1.5rem;
            margin: 1rem 0;
        }

        .document-content li {
            margin-bottom: 0.5rem;
        }

        .document-content blockquote {
            border-left: 4px solid var(--color-accent-blue);
            padding-left: 1.5rem;
            margin: 1.5rem 0;
            color: var(--color-text-muted);
            font-style: italic;
        }

        .document-content table {
            width: 100%;
            border-collapse: collapse;
            margin: 1.5rem 0;
        }

        .document-content th,
        .document-content td {
            border: 1px solid var(--color-border);
            padding: 0.75rem;
            text-align: left;
        }

        .document-content th {
            background: var(--color-surface-alt);
            font-weight: 600;
        }

        /* Empty Content State */
        .empty-content {
            text-align: center;
            padding: 4rem 2rem;
            color: var(--color-text-muted);
        }

        .empty-content-icon {
            font-size: 4rem;
            margin-bottom: 1.5rem;
            color: var(--color-text-muted);
            opacity: 0.5;
        }

        /* Toast Notification */
        .toast {
            position: fixed;
            bottom: 2rem;
            right: 2rem;
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: 12px;
            padding: 1rem 1.5rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            display: flex;
            align-items: center;
            gap: 0.75rem;
            z-index: 1000;
            transform: translateY(100px);
            opacity: 0;
            transition: all 0.3s ease;
        }

        .toast.show {
            transform: translateY(0);
            opacity: 1;
        }

        .toast.success {
            border-left: 4px solid var(--color-accent-green);
        }

        .toast.info {
            border-left: 4px solid var(--color-accent-blue);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .document-container {
                padding: 1rem;
            }
            
            .document-header {
                padding: 1.5rem;
            }
            
            .document-title {
                font-size: 1.5rem;
            }
            
            .metadata-card,
            .content-card {
                padding: 1.25rem;
            }
            
            .content-header {
                padding: 1rem 1.25rem;
                flex-direction: column;
                align-items: flex-start;
                gap: 1rem;
            }
            
            .metadata-grid {
                grid-template-columns: 1fr;
            }
            
            .action-buttons {
                flex-direction: column;
                width: 100%;
            }
            
            .btn-primary,
            .btn-outline {
                width: 100%;
                justify-content: center;
            }
        }

        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .document-header,
        .metadata-card,
        .content-card {
            animation: fadeInUp 0.6s ease-out;
        }

        .metadata-card {
            animation-delay: 0.1s;
        }

        .content-card {
            animation-delay: 0.2s;
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 10px;
            height: 10px;
        }

        ::-webkit-scrollbar-track {
            background: var(--color-surface);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--color-border);
            border-radius: 5px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--color-text-muted);
        }
    </style>
</head>
<body>
    <div class="document-container">
        <!-- Document Header -->
        <div class="document-header">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4">
                <div class="mb-3 mb-md-0">
                    <h1 class="document-title"><?= View::e($title) ?></h1>
                    <p class="document-subtitle">
                        <span class="doc-id-badge">
                            <i class="bi bi-hash"></i> #<?= View::e((string)$id) ?>
                        </span>
                    </p>
                </div>
                <div class="action-buttons">
                    <a href="/documentation" class="btn-outline">
                        <i class="bi bi-arrow-left"></i> Back to List
                    </a>
                    <a href="/documentation/edit?id=<?= View::e((string)$id) ?>" class="btn-primary">
                        <i class="bi bi-pencil"></i> Edit
                    </a>
                </div>
            </div>
        </div>

        <!-- Metadata Card -->
        <div class="metadata-card">
            <div class="metadata-grid">
                <div class="metadata-item">
                    <div class="metadata-label">
                        <i class="bi bi-folder"></i> Project
                    </div>
                    <div class="metadata-value">
                        <?php if ($project !== '' && $project !== null): ?>
                            <span class="project-badge">
                                <i class="bi bi-link-45deg"></i>
                                <?= View::e((string)$project) ?>
                            </span>
                        <?php else: ?>
                            <span class="metadata-value empty">
                                <i class="bi bi-globe me-2"></i> General Documentation
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="metadata-item">
                    <div class="metadata-label">
                        <i class="bi bi-tag"></i> Type
                    </div>
                    <div class="metadata-value">
                        <?php if ($type !== ''): ?>
                            <span class="type-badge">
                                <i class="bi bi-bookmark"></i>
                                <?= View::e($type) ?>
                            </span>
                        <?php else: ?>
                            <span class="metadata-value empty">
                                Not specified
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="metadata-item">
                    <div class="metadata-label">
                        <i class="bi bi-tags"></i> Tags
                    </div>
                    <div class="metadata-value">
                        <?php if (!empty($tagArray)): ?>
                            <div class="tags-container">
                                <?php foreach ($tagArray as $tag): ?>
                                    <?php $trimmedTag = trim($tag); ?>
                                    <?php if ($trimmedTag): ?>
                                        <span class="tag" onclick="searchTag('<?= View::e($trimmedTag) ?>')">
                                            <i class="bi bi-tag-fill"></i> <?= View::e($trimmedTag) ?>
                                        </span>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <span class="metadata-value empty">No tags</span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="metadata-item">
                    <div class="metadata-label">
                        <i class="bi bi-person-plus"></i> Created By
                    </div>
                    <div class="metadata-value">
                        <div class="author-info">
                            <div class="author-avatar">
                                <?= strtoupper(substr($createdBy, 0, 1)) ?>
                            </div>
                            <div class="author-details">
                                <span class="author-name"><?= View::e((string)$createdBy) ?></span>
                                <?php if ($createdAt): ?>
                                    <span class="author-date">on <?= View::e($createdAt) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="metadata-item">
                    <div class="metadata-label">
                        <i class="bi bi-clock-history"></i> Last Updated
                    </div>
                    <div class="metadata-value">
                        <?php if ($updatedAt): ?>
                            <span class="text-muted"><?= View::e($updatedAt) ?></span>
                        <?php else: ?>
                            <span class="metadata-value empty">Never updated</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Content Card -->
        <div class="content-card">
            <div class="content-header">
                <h3 class="content-title">
                    <i class="bi bi-file-text me-2"></i> Documentation Content
                </h3>
                <div class="content-actions">
                    <button class="content-action-btn" onclick="copyToClipboard()" id="copyBtn" title="Copy content">
                        <i class="bi bi-clipboard"></i> Copy
                    </button>
                    <button class="content-action-btn" onclick="toggleDarkMode()" title="Toggle dark mode">
                        <i class="bi bi-moon"></i> Theme
                    </button>
                    <button class="content-action-btn" onclick="printDocument()" title="Print document">
                        <i class="bi bi-printer"></i> Print
                    </button>
                </div>
            </div>
            <div class="content-body">
                <?php if ($body !== ''): ?>
                    <div class="document-content" id="documentContent">
                        <?= nl2br(View::e($body)) ?>
                    </div>
                <?php else: ?>
                    <div class="empty-content">
                        <div class="empty-content-icon">
                            <i class="bi bi-file-earmark-text"></i>
                        </div>
                        <h4 class="h5 mb-3">No Content Available</h4>
                        <p class="text-muted mb-4">
                            This documentation entry doesn't have any content yet.
                        </p>
                        <a href="/documentation/edit?id=<?= View::e((string)$id) ?>" class="btn-primary">
                            <i class="bi bi-pencil me-2"></i> Add Content
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Toast Notification -->
    <div class="toast" id="toast">
        <i class="bi bi-check-circle-fill" id="toastIcon"></i>
        <span id="toastMessage">Copied to clipboard!</span>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    // Format content with basic markdown-like formatting
    function formatContent() {
        const content = document.getElementById('documentContent');
        if (!content) return;
        
        let html = content.innerHTML;
        
        // Convert markdown headers
        html = html.replace(/^### (.*?)$/gm, '<h3>$1</h3>');
        html = html.replace(/^## (.*?)$/gm, '<h2>$1</h2>');
        html = html.replace(/^# (.*?)$/gm, '<h1>$1</h1>');
        
        // Convert bold (**text**)
        html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        
        // Convert italic (*text*)
        html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');
        
        // Convert code blocks (```code```)
        html = html.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
        
        // Convert inline code (`code`)
        html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
        
        // Convert bullet lists
        html = html.replace(/^- (.*?)(?=\n-|\n\n|$)/gm, '<li>$1</li>');
        html = html.replace(/(<li>.*?<\/li>\n?)+/gs, '<ul>$&</ul>');
        
        // Convert numbered lists
        html = html.replace(/^\d+\. (.*?)$/gm, '<li>$1</li>');
        html = html.replace(/(<li>.*?<\/li>\n?)+(?=\n\n|\n[^-]|$)/gs, '<ol>$&</ol>');
        
        // Convert blockquotes
        html = html.replace(/^> (.*?)$/gm, '<blockquote>$1</blockquote>');
        
        // Convert links [text](url)
        html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
        
        content.innerHTML = html;
    }

    // Copy content to clipboard
    async function copyToClipboard() {
        try {
            const content = document.getElementById('documentContent').textContent;
            await navigator.clipboard.writeText(content);
            showToast('Document content copied to clipboard!', 'success');
            
            // Update button temporarily
            const copyBtn = document.getElementById('copyBtn');
            const originalHTML = copyBtn.innerHTML;
            copyBtn.innerHTML = '<i class="bi bi-check"></i> Copied!';
            copyBtn.disabled = true;
            
            setTimeout(() => {
                copyBtn.innerHTML = originalHTML;
                copyBtn.disabled = false;
            }, 2000);
        } catch (err) {
            showToast('Failed to copy content', 'error');
        }
    }

    // Show toast notification
    function showToast(message, type = 'info') {
        const toast = document.getElementById('toast');
        const toastIcon = document.getElementById('toastIcon');
        const toastMessage = document.getElementById('toastMessage');
        
        // Set icon based on type
        switch(type) {
            case 'success':
                toastIcon.className = 'bi bi-check-circle-fill';
                toastIcon.style.color = 'var(--color-accent-green)';
                break;
            case 'error':
                toastIcon.className = 'bi bi-exclamation-circle-fill';
                toastIcon.style.color = '#ef4444';
                break;
            default:
                toastIcon.className = 'bi bi-info-circle-fill';
                toastIcon.style.color = 'var(--color-accent-blue)';
        }
        
        toastMessage.textContent = message;
        toast.className = `toast ${type} show`;
        
        // Hide after 3 seconds
        setTimeout(() => {
            toast.className = 'toast';
        }, 3000);
    }

    // Search for tag
    function searchTag(tag) {
        const encodedTag = encodeURIComponent(tag.trim());
        showToast(`Searching for "${tag}"`, 'info');
        
        // Wait a moment then redirect
        setTimeout(() => {
            window.location.href = `/documentation?search=${encodedTag}`;
        }, 1000);
    }

    // Toggle dark mode
    function toggleDarkMode() {
        const body = document.body;
        const isDark = body.style.backgroundColor === 'white';
        
        if (isDark) {
            // Switch back to dark
            body.style.backgroundColor = '';
            body.style.color = '';
            showToast('Switched to dark mode', 'info');
        } else {
            // Switch to light
            body.style.backgroundColor = 'white';
            body.style.color = '#1f2937';
            showToast('Switched to light mode', 'info');
        }
    }

    // Print document
    function printDocument() {
        const printContent = document.documentElement.innerHTML;
        const originalContent = document.body.innerHTML;
        
        // Create print-friendly content
        const printDocument = `
            <!DOCTYPE html>
            <html>
            <head>
                <title><?= View::e($title) ?> - Documentation</title>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; padding: 2rem; }
                    .header { border-bottom: 2px solid #333; padding-bottom: 1rem; margin-bottom: 2rem; }
                    .metadata { background: #f5f5f5; padding: 1rem; border-radius: 4px; margin-bottom: 2rem; }
                    .content { font-size: 14px; }
                    @media print {
                        .no-print { display: none; }
                    }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1><?= View::e($title) ?></h1>
                    <p>Documentation #<?= View::e((string)$id) ?></p>
                </div>
                
                <div class="metadata">
                    <p><strong>Project:</strong> <?= $project !== '' && $project !== null ? View::e((string)$project) : 'General' ?></p>
                    <p><strong>Type:</strong> <?= $type !== '' ? View::e($type) : 'Not specified' ?></p>
                    <p><strong>Created by:</strong> <?= View::e((string)$createdBy) ?> on <?= View::e($createdAt) ?></p>
                </div>
                
                <div class="content">
                    <?= nl2br(View::e($body)) ?>
                </div>
                
                <div class="no-print" style="margin-top: 2rem; padding-top: 1rem; border-top: 1px solid #ccc;">
                    <p><small>Printed from ZukBits Documentation System on ${new Date().toLocaleString()}</small></p>
                </div>
            </body>
            </html>
        `;
        
        // Open print window
        const printWindow = window.open('', '_blank');
        printWindow.document.write(printDocument);
        printWindow.document.close();
        printWindow.focus();
        
        setTimeout(() => {
            printWindow.print();
            printWindow.close();
        }, 250);
    }

    // Add syntax highlighting for code blocks
    function highlightCode() {
        const codeBlocks = document.querySelectorAll('pre code');
        codeBlocks.forEach(block => {
            // Simple syntax highlighting for common languages
            const text = block.textContent;
            let highlighted = text
                .replace(/(\b(function|const|let|var|return|if|else|for|while|class)\b)/g, '<span class="keyword">$1</span>')
                .replace(/(\b(true|false|null|undefined)\b)/g, '<span class="literal">$1</span>')
                .replace(/(\b(console|document|window|Math)\b)/g, '<span class="builtin">$1</span>')
                .replace(/(["'].*?["'])/g, '<span class="string">$1</span>')
                .replace(/(\/\/.*?$)/gm, '<span class="comment">$1</span>')
                .replace(/(\/\*[\s\S]*?\*\/)/g, '<span class="comment">$1</span>');
            
            block.innerHTML = highlighted;
        });
    }

    // Initialize when page loads
    document.addEventListener('DOMContentLoaded', function() {
        // Format content if it exists
        if (document.getElementById('documentContent')) {
            formatContent();
            highlightCode();
        }
        
        // Add CSS for syntax highlighting
        const style = document.createElement('style');
        style.textContent = `
            .keyword { color: #ff79c6; }
            .literal { color: #bd93f9; }
            .string { color: #f1fa8c; }
            .builtin { color: #8be9fd; }
            .comment { color: #6272a4; font-style: italic; }
        `;
        document.head.appendChild(style);
        
        // Add click handlers for links in content
        document.addEventListener('click', function(e) {
            if (e.target.tagName === 'A' && e.target.href) {
                e.preventDefault();
                window.open(e.target.href, '_blank', 'noopener,noreferrer');
            }
        });
    });
    </script>
</body>
</html>