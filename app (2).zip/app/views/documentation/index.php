<?php
// index.php lists documentation entries for a selected project or the entire system.

/** @var array $documents */
/** @var int   $project_id */

use App\core\View;
use App\core\Auth;

$user = Auth::user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Documentation - ZukBits</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --color-bg: #050816;
            --color-surface: #0b1020;
            --color-surface-alt: #111827;
            --color-surface-soft: #0f172a;
            --color-accent: #ffc857;
            --color-accent-strong: #fbbf24;
            --color-accent-blue: #38bdf8;
            --color-accent-purple: #a855f7;
            --color-accent-green: #34c759;
            --color-text: #f7f7ff;
            --color-text-muted: #c3c5d4;
            --color-border: #22263b;
            --gradient-primary: linear-gradient(135deg, var(--color-accent-blue), var(--color-accent-purple));
            --gradient-bg-card: radial-gradient(circle at top left, rgba(148, 163, 253, 0.18), rgba(15, 23, 42, 0.96));
        }

        body {
            background: var(--color-bg);
            color: var(--color-text);
            min-height: 100vh;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }

        .dashboard-container {
            padding: 1.5rem;
            max-width: 1400px;
            margin: 0 auto;
        }

        /* Header Styles */
        .dashboard-header {
            background: var(--gradient-bg-card);
            border: 1px solid var(--color-border);
            border-radius: 20px;
            padding: 1.5rem 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            position: relative;
            overflow: hidden;
            border-top: 4px solid var(--color-accent-green);
        }

        .dashboard-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--gradient-primary);
        }

        .header-title {
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: 700;
            margin: 0;
        }

        .header-subtitle {
            color: var(--color-text-muted);
            font-size: 1rem;
        }

        /* Action Button */
        .action-btn {
            background: var(--gradient-primary);
            border: none;
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
        }

        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(56, 189, 248, 0.25);
        }

        /* Filter Badge */
        .filter-badge {
            background: rgba(56, 189, 248, 0.1);
            border: 1px solid rgba(56, 189, 248, 0.2);
            color: var(--color-accent-blue);
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.875rem;
            font-weight: 500;
        }

        /* Empty State */
        .empty-state {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: 16px;
            padding: 4rem 2rem;
            text-align: center;
        }

        .empty-state-icon {
            font-size: 4rem;
            color: var(--color-text-muted);
            margin-bottom: 1.5rem;
        }

        /* Documentation Cards */
        .documents-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }

        .document-card {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: 16px;
            padding: 1.5rem;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        .document-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--gradient-primary);
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .document-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.4);
        }

        .document-card:hover::before {
            opacity: 1;
        }

        .document-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
        }

        .document-id {
            background: var(--color-surface-alt);
            color: var(--color-text-muted);
            font-size: 0.75rem;
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
        }

        .document-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin: 0 0 1rem 0;
            color: var(--color-text);
            line-height: 1.4;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .document-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            margin-bottom: 1.5rem;
        }

        .meta-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--color-text-muted);
            font-size: 0.875rem;
        }

        .meta-badge {
            background: var(--color-surface-alt);
            border: 1px solid var(--color-border);
            color: var(--color-accent-blue);
            padding: 0.25rem 0.75rem;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .meta-badge.general {
            background: rgba(168, 85, 247, 0.1);
            border-color: rgba(168, 85, 247, 0.2);
            color: var(--color-accent-purple);
        }

        .document-preview {
            color: var(--color-text-muted);
            font-size: 0.95rem;
            line-height: 1.6;
            margin-bottom: 1.5rem;
            flex-grow: 1;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .document-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 1rem;
            border-top: 1px solid var(--color-border);
        }

        .document-author {
            color: var(--color-text-muted);
            font-size: 0.875rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .document-date {
            color: var(--color-text-muted);
            font-size: 0.75rem;
        }

        .view-btn {
            background: transparent;
            border: 1px solid var(--color-border);
            color: var(--color-text);
            padding: 0.5rem 1rem;
            border-radius: 10px;
            font-size: 0.875rem;
            font-weight: 500;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.2s ease;
        }

        .view-btn:hover {
            background: var(--color-surface-alt);
            border-color: var(--color-border-light);
        }

        /* Tags Container */
        .tags-container {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }

        .tag {
            background: rgba(255, 200, 87, 0.1);
            border: 1px solid rgba(255, 200, 87, 0.2);
            color: var(--color-accent);
            padding: 0.25rem 0.5rem;
            border-radius: 8px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        /* Search and Filter Bar */
        .search-bar {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 1.5rem;
        }

        .search-input {
            flex-grow: 1;
            background: transparent;
            border: none;
            color: var(--color-text);
            font-size: 0.95rem;
            outline: none;
        }

        .search-input::placeholder {
            color: var(--color-text-muted);
        }

        .search-btn {
            background: var(--gradient-primary);
            border: none;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 10px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .search-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(56, 189, 248, 0.25);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .dashboard-container {
                padding: 1rem;
            }
            
            .dashboard-header {
                padding: 1.25rem;
            }
            
            .documents-container {
                grid-template-columns: 1fr;
                gap: 1rem;
            }
            
            .document-card {
                padding: 1.25rem;
            }
            
            .search-bar {
                flex-direction: column;
                align-items: stretch;
            }
        }

        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .dashboard-header {
            animation: fadeInUp 0.6s ease-out;
        }

        .document-card {
            animation: fadeInUp 0.6s ease-out;
        }

        .document-card:nth-child(2) { animation-delay: 0.1s; }
        .document-card:nth-child(3) { animation-delay: 0.2s; }
        .document-card:nth-child(4) { animation-delay: 0.3s; }
        .document-card:nth-child(5) { animation-delay: 0.4s; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Header -->
        <div class="dashboard-header">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center">
                <div class="mb-3 mb-md-0">
                    <h1 class="header-title h3 mb-2">
                        <i class="bi bi-file-text me-2"></i>Documentation
                    </h1>
                    <p class="header-subtitle mb-0">
                        <?php if ($project_id > 0): ?>
                            Showing documentation for project ID <?= View::e((string)$project_id) ?>
                            <span class="filter-badge ms-2">
                                <i class="bi bi-filter"></i> Project Filter
                            </span>
                        <?php else: ?>
                            Showing documentation entries you are allowed to access
                        <?php endif; ?>
                    </p>
                </div>
                <div>
                    <a href="/documentation/create<?= $project_id > 0 ? '?project_id=' . View::e((string)$project_id) : '' ?>"
                       class="action-btn">
                        <i class="bi bi-plus-circle"></i>Add Documentation
                    </a>
                </div>
            </div>
        </div>

        <!-- Search Bar -->
        <div class="search-bar">
            <i class="bi bi-search text-muted"></i>
            <input type="text" 
                   class="search-input" 
                   placeholder="Search documentation by title, tags, or content..."
                   id="searchInput">
            <button class="search-btn" onclick="searchDocuments()">
                <i class="bi bi-search"></i> Search
            </button>
        </div>

        <?php if (empty($documents)): ?>
            <!-- Empty State -->
            <div class="empty-state">
                <div class="empty-state-icon">
                    <i class="bi bi-file-earmark-text"></i>
                </div>
                <h3 class="h5 mb-3">No documentation found</h3>
                <p class="text-muted mb-4">
                    <?php if ($project_id > 0): ?>
                        No documentation entries found for this project. Create the first one!
                    <?php else: ?>
                        No documentation entries available. Start by adding your first documentation.
                    <?php endif; ?>
                </p>
                <a href="/documentation/create<?= $project_id > 0 ? '?project_id=' . View::e((string)$project_id) : '' ?>"
                   class="action-btn">
                    <i class="bi bi-plus-circle"></i>Create First Documentation
                </a>
            </div>
        <?php else: ?>
            <!-- Documents Grid -->
            <div class="documents-container">
                <?php foreach ($documents as $doc): ?>
                    <?php
                    $id        = (int) ($doc['id'] ?? 0);
                    $title     = $doc['title'] ?? '';
                    $project   = $doc['project_name'] ?? ($doc['project_id'] ?? '');
                    $type      = $doc['type'] ?? '';
                    $tags      = $doc['tags'] ?? '';
                    $createdBy = $doc['created_by_name'] ?? ($doc['created_by'] ?? '');
                    $createdAt = $doc['created_at'] ?? '';
                    $bodyPreview = substr(strip_tags($doc['body'] ?? ''), 0, 150) . '...';
                    ?>
                    <div class="document-card" data-title="<?= htmlspecialchars(strtolower($title)) ?>" 
                         data-tags="<?= htmlspecialchars(strtolower($tags)) ?>"
                         data-type="<?= htmlspecialchars(strtolower($type)) ?>">
                        <div class="document-header">
                            <span class="document-id">#<?= View::e((string)$id) ?></span>
                            <?php if ($type): ?>
                                <span class="meta-badge">
                                    <i class="bi bi-tag"></i> <?= View::e($type) ?>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <h3 class="document-title"><?= View::e($title) ?></h3>
                        
                        <div class="document-meta">
                            <div class="meta-item">
                                <i class="bi bi-folder"></i>
                                <?php if ($project !== ''): ?>
                                    <span>Project: <?= View::e((string)$project) ?></span>
                                <?php else: ?>
                                    <span class="meta-badge general">
                                        <i class="bi bi-globe"></i> General
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <?php if ($tags): ?>
                            <div class="tags-container">
                                <?php
                                $tagArray = explode(',', $tags);
                                foreach ($tagArray as $tag):
                                    $trimmedTag = trim($tag);
                                    if ($trimmedTag):
                                ?>
                                    <span class="tag"><?= View::e($trimmedTag) ?></span>
                                <?php
                                    endif;
                                endforeach;
                                ?>
                            </div>
                        <?php endif; ?>
                        
                        <p class="document-preview"><?= View::e($bodyPreview) ?></p>
                        
                        <div class="document-footer">
                            <div class="document-author">
                                <i class="bi bi-person-circle"></i>
                                <?= View::e((string)$createdBy) ?>
                            </div>
                            <div>
                                <span class="document-date">
                                    <i class="bi bi-calendar3"></i> <?= View::e($createdAt) ?>
                                </span>
                                <a href="/documentation/show?id=<?= View::e((string)$id) ?>" class="view-btn ms-2">
                                    <i class="bi bi-eye"></i> View
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function searchDocuments() {
        const searchInput = document.getElementById('searchInput');
        const searchTerm = searchInput.value.toLowerCase();
        const documentCards = document.querySelectorAll('.document-card');
        
        documentCards.forEach(card => {
            const title = card.getAttribute('data-title') || '';
            const tags = card.getAttribute('data-tags') || '';
            const type = card.getAttribute('data-type') || '';
            
            const matches = title.includes(searchTerm) || 
                           tags.includes(searchTerm) || 
                           type.includes(searchTerm);
            
            if (matches || searchTerm === '') {
                card.style.display = 'flex';
                card.style.animation = 'fadeInUp 0.3s ease-out';
            } else {
                card.style.display = 'none';
            }
        });
    }

    // Add enter key support for search
    document.getElementById('searchInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            searchDocuments();
        }
    });

    // Add tag click functionality
    document.addEventListener('DOMContentLoaded', function() {
        const tags = document.querySelectorAll('.tag');
        tags.forEach(tag => {
            tag.addEventListener('click', function() {
                const tagText = this.textContent.trim().toLowerCase();
                const searchInput = document.getElementById('searchInput');
                searchInput.value = tagText;
                searchDocuments();
            });
            
            // Add cursor pointer
            tag.style.cursor = 'pointer';
        });
    });
    </script>
</body>
</html>