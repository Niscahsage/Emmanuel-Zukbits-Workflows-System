<?php
// create.php displays a form to add a new documentation entry.

/** @var int $project_id */

use App\core\View;

$projectId = (int) ($project_id ?? 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Documentation - ZukBits</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --color-bg: #050816;
            --color-surface: #0b1020;
            --color-surface-alt: #111827;
            --color-surface-soft: #0f172a;
            --color-accent: #ffc857;
            --color-accent-strong: #fbbf24;
            --color-accent-blue: #38bdf8;
            --color-accent-purple: #a855f7;
            --color-accent-green: #34c759;
            --color-text: #f7f7ff;
            --color-text-muted: #c3c5d4;
            --color-border: #22263b;
            --gradient-primary: linear-gradient(135deg, var(--color-accent-blue), var(--color-accent-purple));
            --gradient-bg-card: radial-gradient(circle at top left, rgba(148, 163, 253, 0.18), rgba(15, 23, 42, 0.96));
        }

        body {
            background: var(--color-bg);
            color: var(--color-text);
            min-height: 100vh;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }

        .dashboard-container {
            padding: 1.5rem;
            max-width: 1000px;
            margin: 0 auto;
        }

        /* Header Styles */
        .dashboard-header {
            background: var(--gradient-bg-card);
            border: 1px solid var(--color-border);
            border-radius: 20px;
            padding: 1.5rem 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            position: relative;
            overflow: hidden;
            border-top: 4px solid var(--color-accent-green);
        }

        .header-title {
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: 700;
            margin: 0;
        }

        .header-subtitle {
            color: var(--color-text-muted);
            font-size: 1rem;
        }

        /* Form Card */
        .form-card {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .form-section {
            margin-bottom: 2rem;
        }

        .section-title {
            color: var(--color-accent);
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            padding-bottom: 0.75rem;
            border-bottom: 2px solid var(--color-border);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        /* Form Elements */
        .form-label {
            color: var(--color-text);
            font-weight: 500;
            margin-bottom: 0.5rem;
            font-size: 0.95rem;
        }

        .form-label.required::after {
            content: ' *';
            color: #ef4444;
        }

        .form-control {
            background: var(--color-surface-alt);
            border: 1px solid var(--color-border);
            color: var(--color-text);
            border-radius: 12px;
            padding: 0.875rem 1rem;
            font-size: 1rem;
            transition: all 0.2s ease;
        }

        .form-control:focus {
            background: var(--color-surface-soft);
            border-color: var(--color-accent-blue);
            box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.15);
            color: var(--color-text);
        }

        .form-control::placeholder {
            color: var(--color-text-muted);
            opacity: 0.6;
        }

        .form-control:disabled {
            background: var(--color-surface);
            border-color: var(--color-border);
            color: var(--color-text-muted);
            cursor: not-allowed;
        }

        .form-text {
            color: var(--color-text-muted);
            font-size: 0.85rem;
            margin-top: 0.5rem;
            line-height: 1.5;
        }

        .form-text i {
            color: var(--color-accent-blue);
        }

        textarea.form-control {
            min-height: 300px;
            resize: vertical;
            font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
            line-height: 1.6;
        }

        /* Buttons */
        .btn-primary {
            background: var(--gradient-primary);
            border: none;
            color: white;
            padding: 0.75rem 2rem;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(56, 189, 248, 0.25);
        }

        .btn-outline {
            background: transparent;
            border: 1px solid var(--color-border);
            color: var(--color-text);
            padding: 0.75rem 2rem;
            border-radius: 12px;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .btn-outline:hover {
            background: var(--color-surface-alt);
            border-color: var(--color-border-light);
        }

        /* Project Indicator */
        .project-indicator {
            background: rgba(56, 189, 248, 0.1);
            border: 1px solid rgba(56, 189, 248, 0.2);
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 1.5rem;
        }

        .project-indicator strong {
            color: var(--color-accent-blue);
        }

        /* Character Counter */
        .char-counter {
            color: var(--color-text-muted);
            font-size: 0.85rem;
            text-align: right;
            margin-top: 0.5rem;
        }

        .char-counter.warning {
            color: var(--color-accent-strong);
        }

        .char-counter.danger {
            color: #ef4444;
        }

        /* Type Suggestions */
        .type-suggestions {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }

        .type-suggestion {
            background: var(--color-surface-alt);
            border: 1px solid var(--color-border);
            color: var(--color-text);
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.85rem;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .type-suggestion:hover {
            background: var(--color-surface-soft);
            border-color: var(--color-accent-blue);
        }

        /* Tag Input */
        .tags-input-container {
            background: var(--color-surface-alt);
            border: 1px solid var(--color-border);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            min-height: 50px;
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            align-items: center;
        }

        .tag-item {
            background: rgba(255, 200, 87, 0.1);
            border: 1px solid rgba(255, 200, 87, 0.2);
            color: var(--color-accent);
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .tag-remove {
            background: none;
            border: none;
            color: var(--color-accent);
            cursor: pointer;
            padding: 0;
            font-size: 1rem;
            line-height: 1;
        }

        .tags-input {
            flex-grow: 1;
            background: transparent;
            border: none;
            color: var(--color-text);
            font-size: 0.95rem;
            outline: none;
            min-width: 150px;
        }

        .tags-input::placeholder {
            color: var(--color-text-muted);
        }

        /* Markdown Helper */
        .markdown-helper {
            background: var(--color-surface-alt);
            border: 1px solid var(--color-border);
            border-radius: 12px;
            padding: 1rem;
            margin-top: 1rem;
        }

        .markdown-helper h6 {
            color: var(--color-accent);
            margin-bottom: 0.75rem;
        }

        .markdown-examples {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 0.75rem;
            font-size: 0.85rem;
        }

        .markdown-example {
            color: var(--color-text-muted);
        }

        .markdown-example code {
            background: var(--color-bg);
            padding: 0.125rem 0.25rem;
            border-radius: 4px;
            font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
            font-size: 0.8rem;
        }

        @media (max-width: 768px) {
            .dashboard-container {
                padding: 1rem;
            }
            
            .dashboard-header,
            .form-card {
                padding: 1.25rem;
            }
            
            .form-section {
                margin-bottom: 1.5rem;
            }
            
            .btn-primary,
            .btn-outline {
                width: 100%;
                margin-bottom: 0.5rem;
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .dashboard-header,
        .form-card {
            animation: fadeInUp 0.6s ease-out;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Header -->
        <div class="dashboard-header">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center">
                <div class="mb-3 mb-md-0">
                    <h1 class="header-title h3 mb-2">
                        <i class="bi bi-plus-circle me-2"></i>Add Documentation
                    </h1>
                    <p class="header-subtitle mb-0">
                        Create new documentation entry for knowledge sharing
                    </p>
                </div>
                <div>
                    <a href="/documentation<?= $projectId > 0 ? '?project_id=' . View::e((string)$projectId) : '' ?>"
                       class="btn-outline">
                        <i class="bi bi-arrow-left me-2"></i>Cancel
                    </a>
                </div>
            </div>
        </div>

        <!-- Form -->
        <div class="form-card">
            <form action="/documentation/store" method="post" id="docForm" onsubmit="return validateForm()">
                <!-- Project Section -->
                <div class="form-section">
                    <h3 class="section-title">
                        <i class="bi bi-folder"></i>Project Association
                    </h3>
                    
                    <?php if ($projectId > 0): ?>
                        <input type="hidden" name="project_id" value="<?= View::e((string)$projectId) ?>">
                        <div class="project-indicator">
                            <strong>This documentation will be attached to:</strong><br>
                            <span class="text-muted">Project ID <?= View::e((string)$projectId) ?></span>
                        </div>
                    <?php else: ?>
                        <div class="mb-3">
                            <label for="project_id" class="form-label">
                                <i class="bi bi-folder me-2"></i>Project (Optional)
                            </label>
                            <input
                                type="number"
                                name="project_id"
                                id="project_id"
                                class="form-control"
                                placeholder="Enter project ID (leave blank for general documentation)"
                                min="0"
                            >
                            <div class="form-text">
                                <i class="bi bi-info-circle me-1"></i>
                                Set a project ID to link this entry to a specific project.
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Basic Information -->
                <div class="form-section">
                    <h3 class="section-title">
                        <i class="bi bi-info-circle"></i>Basic Information
                    </h3>
                    
                    <div class="mb-4">
                        <label for="title" class="form-label required">
                            <i class="bi bi-card-heading me-2"></i>Title
                        </label>
                        <input
                            type="text"
                            name="title"
                            id="title"
                            class="form-control"
                            required
                            maxlength="200"
                            placeholder="Enter a clear and descriptive title"
                            oninput="updateCharCounter('title', 'titleCounter', 200)"
                        >
                        <div class="char-counter" id="titleCounter">0/200</div>
                    </div>

                    <div class="mb-4">
                        <label for="type" class="form-label">
                            <i class="bi bi-tag me-2"></i>Document Type
                        </label>
                        <input
                            type="text"
                            name="type"
                            id="type"
                            class="form-control"
                            placeholder="e.g. SOP, Architecture, Onboarding, Checklist, API Documentation"
                            maxlength="50"
                            oninput="updateCharCounter('type', 'typeCounter', 50)"
                        >
                        <div class="form-text">
                            <i class="bi bi-lightbulb me-1"></i>
                            Common types: 
                            <div class="type-suggestions">
                                <span class="type-suggestion" onclick="setType('SOP')">SOP</span>
                                <span class="type-suggestion" onclick="setType('Architecture')">Architecture</span>
                                <span class="type-suggestion" onclick="setType('Onboarding')">Onboarding</span>
                                <span class="type-suggestion" onclick="setType('Checklist')">Checklist</span>
                                <span class="type-suggestion" onclick="setType('API')">API Documentation</span>
                                <span class="type-suggestion" onclick="setType('Troubleshooting')">Troubleshooting</span>
                            </div>
                        </div>
                        <div class="char-counter" id="typeCounter">0/50</div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">
                            <i class="bi bi-tags me-2"></i>Tags (Optional)
                        </label>
                        <div class="tags-input-container" id="tagsContainer">
                            <input
                                type="text"
                                id="tagInput"
                                class="tags-input"
                                placeholder="Type a tag and press Enter or comma"
                                onkeydown="handleTagInput(event)"
                            >
                        </div>
                        <input type="hidden" name="tags" id="tagsHidden">
                        <div class="form-text">
                            <i class="bi bi-info-circle me-1"></i>
                            Press Enter or comma to add tags. Click on a tag to remove it.
                        </div>
                    </div>
                </div>

                <!-- Content Section -->
                <div class="form-section">
                    <h3 class="section-title">
                        <i class="bi bi-file-text"></i>Content
                    </h3>
                    
                    <div class="mb-4">
                        <label for="body" class="form-label required">
                            <i class="bi bi-pencil me-2"></i>Content
                        </label>
                        <textarea
                            name="body"
                            id="body"
                            rows="15"
                            class="form-control"
                            required
                            maxlength="10000"
                            placeholder="Write your documentation here. You can use markdown formatting."
                            oninput="updateCharCounter('body', 'bodyCounter', 10000)"
                        ></textarea>
                        <div class="char-counter" id="bodyCounter">0/10000</div>
                    </div>

                    <div class="markdown-helper">
                        <h6>
                            <i class="bi bi-markdown me-2"></i>Markdown Formatting Help
                        </h6>
                        <div class="markdown-examples">
                            <div class="markdown-example">
                                <strong>Headers:</strong><br>
                                <code># H1</code>, <code>## H2</code>, <code>### H3</code>
                            </div>
                            <div class="markdown-example">
                                <strong>Lists:</strong><br>
                                <code>- Item</code>, <code>1. Item</code>
                            </div>
                            <div class="markdown-example">
                                <strong>Code:</strong><br>
                                <code>`inline code`</code>
                            </div>
                            <div class="markdown-example">
                                <strong>Links:</strong><br>
                                <code>[Text](URL)</code>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Form Actions -->
                <div class="d-flex justify-content-between align-items-center pt-3">
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="confirmValid" required>
                        <label class="form-check-label" for="confirmValid">
                            I confirm this information is accurate
                        </label>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn-primary">
                            <i class="bi bi-save me-2"></i>Save Documentation
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    let tags = [];

    function setType(type) {
        document.getElementById('type').value = type;
        updateCharCounter('type', 'typeCounter', 50);
    }

    function updateCharCounter(inputId, counterId, maxLength) {
        const input = document.getElementById(inputId);
        const counter = document.getElementById(counterId);
        const length = input.value.length;
        counter.textContent = `${length}/${maxLength}`;
        
        if (length > maxLength * 0.9) {
            counter.className = 'char-counter warning';
        } else if (length > maxLength) {
            counter.className = 'char-counter danger';
        } else {
            counter.className = 'char-counter';
        }
    }

    function handleTagInput(event) {
        if (event.key === 'Enter' || event.key === ',') {
            event.preventDefault();
            const tagInput = document.getElementById('tagInput');
            const tag = tagInput.value.trim();
            
            if (tag && !tags.includes(tag.toLowerCase())) {
                tags.push(tag);
                renderTags();
                tagInput.value = '';
            }
        }
    }

    function renderTags() {
        const container = document.getElementById('tagsContainer');
        const tagInput = document.getElementById('tagInput');
        const tagsHidden = document.getElementById('tagsHidden');
        
        // Remove all tag items except the input
        const tagItems = container.querySelectorAll('.tag-item');
        tagItems.forEach(item => item.remove());
        
        // Add tags
        tags.forEach((tag, index) => {
            const tagElement = document.createElement('div');
            tagElement.className = 'tag-item';
            tagElement.innerHTML = `
                ${tag}
                <button type="button" class="tag-remove" onclick="removeTag(${index})">
                    <i class="bi bi-x"></i>
                </button>
            `;
            container.insertBefore(tagElement, tagInput);
        });
        
        // Update hidden input
        tagsHidden.value = tags.join(',');
    }

    function removeTag(index) {
        tags.splice(index, 1);
        renderTags();
    }

    function validateForm() {
        const title = document.getElementById('title').value.trim();
        const body = document.getElementById('body').value.trim();
        
        if (!title || !body) {
            alert('Please fill in all required fields');
            return false;
        }
        
        if (title.length > 200) {
            alert('Title must be 200 characters or less');
            return false;
        }
        
        if (body.length > 10000) {
            alert('Content must be 10,000 characters or less');
            return false;
        }
        
        // Show loading state
        const submitBtn = document.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="bi bi-hourglass-split me-2"></i>Saving...';
        submitBtn.disabled = true;
        
        return true;
    }

    // Initialize character counters
    document.addEventListener('DOMContentLoaded', function() {
        updateCharCounter('title', 'titleCounter', 200);
        updateCharCounter('type', 'typeCounter', 50);
        updateCharCounter('body', 'bodyCounter', 10000);
        
        // Auto-focus title field
        document.getElementById('title').focus();
    });
    </script>
</body>
</html>