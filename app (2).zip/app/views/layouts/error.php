<?php
// app/views/layouts/error.php
// Layout for system and HTTP error pages.

$app       = app_config();
$appName   = $app['name'] ?? 'ZukBits Online';

$statusCode  = $statusCode  ?? 500;
$errorTitle  = $errorTitle  ?? 'Unexpected error';
$errorSub    = $errorSub    ?? 'Something went wrong while processing your request.';
$pageTitle   = $pageTitle   ?? ($statusCode . ' – ' . $errorTitle);

$isDebug     = (bool) ($_ENV['APP_DEBUG'] ?? false);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?= htmlspecialchars($appName . ' – ' . $pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#050816">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <style>
        :root {
            /* ===== CORE COLORS ===== */
            --color-bg: #050816;
            --color-surface: #0b1020;
            --color-surface-alt: #111827;
            --color-surface-soft: #0f172a;
            
            /* ===== ACCENT COLORS ===== */
            --color-accent: #ffc857;
            --color-accent-strong: #fbbf24;
            --color-accent-soft: rgba(255, 200, 87, 0.15);
            --color-accent-blue: #38bdf8;
            --color-accent-purple: #a855f7;
            --color-accent-green: #34c759;
            --color-accent-red: #ef4444;
            
            /* ===== TEXT COLORS ===== */
            --color-text: #f7f7ff;
            --color-text-muted: #c3c5d4;
            
            /* ===== BORDER COLORS ===== */
            --color-border: #22263b;
            --color-border-light: rgba(148, 163, 253, 0.35);
            
            /* ===== GRADIENTS ===== */
            --gradient-primary: linear-gradient(135deg, var(--color-accent-blue), var(--color-accent-purple));
            --gradient-error: linear-gradient(135deg, #ef4444, #dc2626);
            --gradient-bg-dark: linear-gradient(90deg, #111827, #020617);
            --gradient-bg-card: radial-gradient(circle at top left, rgba(148, 163, 253, 0.18), rgba(15, 23, 42, 0.96));
            
            /* ===== SHADOWS ===== */
            --shadow-blue: rgba(56, 189, 248, 0.35);
            --shadow-red: rgba(239, 68, 68, 0.35);
            --shadow-dark: rgba(0, 0, 0, 0.45);
        }

        body {
            background: var(--gradient-bg-dark);
            color: var(--color-text);
            min-height: 100vh;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            overflow-x: hidden;
        }

        .error-container {
            min-height: 100vh;
            padding: 2rem 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .error-card {
            background: var(--gradient-bg-card);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            border: 1px solid var(--color-border-light);
            box-shadow: 0 25px 70px var(--shadow-dark),
                        0 0 0 1px rgba(148, 163, 253, 0.1);
            overflow: hidden;
            max-width: 800px;
            width: 100%;
        }

        .error-header {
            padding: 2rem 2rem 1.5rem;
            background: radial-gradient(circle at top left, rgba(239, 68, 68, 0.1), transparent 70%);
            border-bottom: 1px solid var(--color-border);
            position: relative;
        }

        .error-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--gradient-error);
            z-index: 2;
        }

        .error-code-container {
            display: flex;
            align-items: center;
            gap: 1.5rem;
            margin-bottom: 1rem;
        }

        .error-code {
            font-size: 4rem;
            font-weight: 900;
            background: var(--gradient-error);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            line-height: 1;
        }

        .error-status {
            flex: 1;
        }

        .error-status h1 {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0 0 0.25rem;
            color: var(--color-text);
        }

        .error-status p {
            color: var(--color-text-muted);
            margin: 0;
            font-size: 0.95rem;
        }

        .error-brand {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.5rem 1rem;
            background: rgba(11, 16, 32, 0.6);
            border-radius: 10px;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .error-brand-logo {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            background: var(--gradient-error);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 0.9rem;
        }

        .error-body {
            padding: 2rem;
        }

        .error-content h2 {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.75rem;
            color: var(--color-text);
        }

        .error-content p {
            color: var(--color-text-muted);
            margin-bottom: 1.5rem;
            line-height: 1.6;
        }

        .error-actions {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
        }

        .btn-error {
            background: var(--gradient-error);
            border: none;
            color: white;
            font-weight: 600;
            padding: 0.75rem 1.5rem;
            border-radius: 10px;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-error:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px var(--shadow-red);
            color: white;
        }

        .btn-ghost {
            background: rgba(11, 16, 32, 0.6);
            border: 1px solid var(--color-border);
            color: var(--color-text);
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            border-radius: 10px;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-ghost:hover {
            border-color: var(--color-accent-blue);
            color: var(--color-accent-blue);
            background: rgba(56, 189, 248, 0.1);
        }

        .debug-section {
            margin-top: 2rem;
            padding-top: 1.5rem;
            border-top: 1px solid var(--color-border);
        }

        .debug-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1rem;
        }

        .debug-title {
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--color-accent);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .debug-toggle {
            background: none;
            border: 1px solid var(--color-border);
            color: var(--color-text-muted);
            padding: 0.25rem 0.75rem;
            border-radius: 6px;
            font-size: 0.8rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .debug-toggle:hover {
            border-color: var(--color-accent-blue);
            color: var(--color-accent-blue);
        }

        .debug-content {
            background: rgba(11, 16, 32, 0.8);
            border: 1px solid var(--color-border);
            border-radius: 10px;
            padding: 1rem;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 0.85rem;
            max-height: 300px;
            overflow-y: auto;
            display: none;
        }

        .debug-content pre {
            margin: 0;
            color: var(--color-text-muted);
            white-space: pre-wrap;
            word-wrap: break-word;
        }

        .error-footer {
            padding: 1.5rem 2rem;
            border-top: 1px solid var(--color-border);
            background: rgba(5, 8, 22, 0.5);
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: var(--color-text-muted);
            font-size: 0.85rem;
        }

        .error-tagline {
            font-style: italic;
            color: var(--color-accent);
        }

        @media (max-width: 768px) {
            .error-card {
                margin: 1rem;
            }
            
            .error-header,
            .error-body,
            .error-footer {
                padding: 1.5rem;
            }
            
            .error-code-container {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
            }
            
            .error-code {
                font-size: 3rem;
            }
            
            .error-actions {
                flex-direction: column;
            }
            
            .error-footer {
                flex-direction: column;
                gap: 0.5rem;
                text-align: center;
            }
        }

        @media (max-width: 576px) {
            .error-container {
                padding: 1rem;
            }
            
            .error-card {
                border-radius: 15px;
            }
            
            .error-header,
            .error-body {
                padding: 1.25rem;
            }
            
            .error-code {
                font-size: 2.5rem;
            }
        }
    </style>
</head>
<body>
<div class="error-container">
    <div class="error-card">
        <div class="error-header">
            <div class="error-code-container">
                <div class="error-code"><?= htmlspecialchars((string)$statusCode, ENT_QUOTES, 'UTF-8') ?></div>
                <div class="error-status">
                    <h1><?= htmlspecialchars($errorTitle, ENT_QUOTES, 'UTF-8') ?></h1>
                    <p>System Error • ZukBits Online</p>
                </div>
                <div class="error-brand">
                    <div class="error-brand-logo">ZB</div>
                    <div>
                        <div style="font-size: 0.8rem; font-weight: 600;">ZukBits</div>
                        <div style="font-size: 0.7rem; color: var(--color-text-muted);">Error Console</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="error-body">
            <div class="error-content">
                <h2>Oops! Something went wrong</h2>
                <p><?= htmlspecialchars($errorSub, ENT_QUOTES, 'UTF-8') ?></p>
                
                <div class="error-extra">
                    <?= $content ?? '' ?>
                </div>

                <div class="error-actions">
                    <button onclick="history.back()" class="btn-ghost">
                        <i class="bi bi-arrow-left"></i> Go Back
                    </button>
                    <a href="/" class="btn-error">
                        <i class="bi bi-house-door"></i> Return to Dashboard
                    </a>
                </div>

                <?php if ($isDebug && !empty($debugInfo)): ?>
                <div class="debug-section">
                    <div class="debug-header">
                        <div class="debug-title">
                            <i class="bi bi-bug-fill me-1"></i> Debug Information
                        </div>
                        <button class="debug-toggle" onclick="toggleDebug()">
                            <i class="bi bi-chevron-down"></i> Show Details
                        </button>
                    </div>
                    <div class="debug-content" id="debugContent">
                        <pre><?= htmlspecialchars((string)$debugInfo, ENT_QUOTES, 'UTF-8') ?></pre>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="error-footer">
            <span class="error-tagline">Make it happen!</span>
            <span>Need help? Contact support • &copy; <?= date('Y') ?> ZukBits Online</span>
        </div>
    </div>
</div>

<!-- Bootstrap JS Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    function toggleDebug() {
        const debugContent = document.getElementById('debugContent');
        const toggleBtn = document.querySelector('.debug-toggle');
        
        if (debugContent.style.display === 'block') {
            debugContent.style.display = 'none';
            toggleBtn.innerHTML = '<i class="bi bi-chevron-down"></i> Show Details';
        } else {
            debugContent.style.display = 'block';
            toggleBtn.innerHTML = '<i class="bi bi-chevron-up"></i> Hide Details';
        }
    }

    // Auto-hide debug info on page load
    document.addEventListener('DOMContentLoaded', function() {
        const debugContent = document.getElementById('debugContent');
        if (debugContent) {
            debugContent.style.display = 'none';
        }
    });
</script>
</body>
</html>