<?php
// app/views/layouts/main.php
// Primary layout for authenticated pages (dashboard, modules, etc.)

$app     = app_config();
$appName = $app['name'] ?? 'ZukBits Online';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?= htmlspecialchars($appName, ENT_QUOTES, 'UTF-8') ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#050816">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <style>
        :root {
            /* ===== CORE COLORS ===== */
            --color-bg: #050816;
            --color-surface: #0b1020;
            --color-surface-alt: #111827;
            --color-surface-soft: #0f172a;
            
            /* ===== ACCENT COLORS ===== */
            --color-accent: #ffc857;
            --color-accent-strong: #fbbf24;
            --color-accent-soft: rgba(255, 200, 87, 0.15);
            --color-accent-blue: #38bdf8;
            --color-accent-purple: #a855f7;
            --color-accent-green: #34c759;
            
            /* ===== TEXT COLORS ===== */
            --color-text: #f7f7ff;
            --color-text-muted: #c3c5d4;
            
            /* ===== BORDER COLORS ===== */
            --color-border: #22263b;
            --color-border-light: rgba(148, 163, 253, 0.35);
            --color-border-medium: rgba(148, 163, 253, 0.45);
            
            /* ===== GRADIENTS ===== */
            --gradient-primary: linear-gradient(135deg, var(--color-accent-blue), var(--color-accent-purple));
            --gradient-bg-dark: linear-gradient(90deg, #111827, #020617);
            --gradient-bg-card: radial-gradient(circle at top left, rgba(148, 163, 253, 0.18), rgba(15, 23, 42, 0.96));
            --gradient-sidebar: linear-gradient(180deg, #050816 0%, #0b1020 100%);
            
            /* ===== SHADOWS ===== */
            --shadow-blue: rgba(56, 189, 248, 0.35);
            --shadow-dark: rgba(0, 0, 0, 0.45);
            --shadow-navbar: 0 4px 30px rgba(0, 0, 0, 0.5);
        }

        body {
            background: var(--color-bg);
            color: var(--color-text);
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            overflow-x: hidden;
            min-height: 100vh;
        }

        /* Modern Dashboard Layout */
        .dashboard-container {
            min-height: 100vh;
            display: flex;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 260px;
            background: var(--gradient-sidebar);
            border-right: 1px solid var(--color-border);
            display: flex;
            flex-direction: column;
            transition: all 0.3s ease;
            position: fixed;
            height: 100vh;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 1.5rem 1.25rem;
            border-bottom: 1px solid var(--color-border);
            background: rgba(11, 16, 32, 0.8);
        }

        .brand-container {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .brand-logo {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: var(--gradient-primary);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 1rem;
            box-shadow: 0 4px 15px var(--shadow-blue);
        }

        .brand-text h1 {
            font-size: 1.1rem;
            font-weight: 700;
            margin: 0;
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .brand-text p {
            font-size: 0.75rem;
            color: var(--color-text-muted);
            margin: 0;
        }

        .sidebar-body {
            padding: 1.25rem 0;
            flex: 1;
            overflow-y: auto;
        }

        .nav-section {
            margin-bottom: 1.5rem;
        }

        .nav-title {
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--color-text-muted);
            padding: 0 1.25rem;
            margin-bottom: 0.75rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem 1.25rem;
            color: var(--color-text-muted);
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
            position: relative;
        }

        .nav-link:hover,
        .nav-link.active {
            background: rgba(56, 189, 248, 0.1);
            color: var(--color-accent-blue);
            border-left-color: var(--color-accent-blue);
        }

        .nav-link i {
            width: 20px;
            font-size: 1.1rem;
        }

        .nav-badge {
            margin-left: auto;
            background: var(--gradient-primary);
            color: white;
            font-size: 0.7rem;
            padding: 0.15rem 0.5rem;
            border-radius: 10px;
            font-weight: 600;
        }

        .sidebar-footer {
            padding: 1rem 1.25rem;
            border-top: 1px solid var(--color-border);
            background: rgba(11, 16, 32, 0.8);
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .user-avatar {
            width: 36px;
            height: 36px;
            border-radius: 8px;
            background: var(--gradient-primary);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .user-info {
            flex: 1;
        }

        .user-name {
            font-size: 0.85rem;
            font-weight: 600;
            margin: 0;
            color: var(--color-text);
        }

        .user-role {
            font-size: 0.75rem;
            color: var(--color-text-muted);
            margin: 0;
        }

        /* Main Content Area */
        .main-content {
            flex: 1;
            margin-left: 260px;
            transition: all 0.3s ease;
            min-height: 100vh;
        }

        /* Top Navigation Bar */
        .top-navbar {
            background: var(--color-surface);
            border-bottom: 1px solid var(--color-border);
            padding: 0.75rem 1.5rem;
            box-shadow: var(--shadow-navbar);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .nav-search {
            position: relative;
            max-width: 400px;
        }

        .search-input {
            background: rgba(11, 16, 32, 0.6);
            border: 1px solid var(--color-border);
            color: var(--color-text);
            border-radius: 8px;
            padding: 0.5rem 1rem 0.5rem 2.5rem;
            width: 100%;
            transition: all 0.3s ease;
        }

        .search-input:focus {
            background: rgba(11, 16, 32, 0.8);
            border-color: var(--color-accent-blue);
            box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.15);
            outline: none;
        }

        .search-icon {
            position: absolute;
            left: 0.75rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--color-text-muted);
        }

        .nav-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .nav-action-btn {
            background: none;
            border: none;
            color: var(--color-text-muted);
            font-size: 1.25rem;
            padding: 0.5rem;
            border-radius: 8px;
            transition: all 0.3s ease;
            position: relative;
        }

        .nav-action-btn:hover {
            color: var(--color-accent-blue);
            background: rgba(56, 189, 248, 0.1);
        }

        .notification-badge {
            position: absolute;
            top: 0;
            right: 0;
            background: var(--color-accent);
            color: var(--color-bg);
            font-size: 0.65rem;
            font-weight: 700;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Content Area */
        .content-wrapper {
            padding: 1.5rem;
            background: radial-gradient(circle at top right, rgba(148, 163, 253, 0.05), transparent 50%);
            min-height: calc(100vh - 70px);
        }

        .page-header {
            margin-bottom: 1.5rem;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0 0 0.25rem;
            color: var(--color-text);
        }

        .page-subtitle {
            color: var(--color-text-muted);
            font-size: 0.9rem;
            margin: 0;
        }

        .page-actions {
            display: flex;
            gap: 0.75rem;
        }

        /* Cards */
        .dashboard-card {
            background: var(--gradient-bg-card);
            border: 1px solid var(--color-border-light);
            border-radius: 12px;
            padding: 1.25rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
            height: 100%;
        }

        .dashboard-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.4);
        }

        .card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1rem;
        }

        .card-title {
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--color-text-muted);
            margin: 0;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .card-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
        }

        .card-icon.primary {
            background: rgba(56, 189, 248, 0.15);
            color: var(--color-accent-blue);
        }

        .card-icon.success {
            background: rgba(52, 199, 89, 0.15);
            color: var(--color-accent-green);
        }

        .card-icon.warning {
            background: rgba(251, 191, 36, 0.15);
            color: var(--color-accent);
        }

        .card-icon.purple {
            background: rgba(168, 85, 247, 0.15);
            color: var(--color-accent-purple);
        }

        .card-value {
            font-size: 1.75rem;
            font-weight: 700;
            margin: 0.5rem 0;
            color: var(--color-text);
        }

        .card-change {
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 0.25rem;
        }

        .card-change.positive {
            color: var(--color-accent-green);
        }

        .card-change.negative {
            color: var(--color-accent);
        }

        /* Buttons */
        .btn-primary {
            background: var(--gradient-primary);
            border: none;
            color: white;
            font-weight: 600;
            padding: 0.5rem 1.25rem;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px var(--shadow-blue);
            color: white;
        }

        .btn-outline {
            background: transparent;
            border: 1px solid var(--color-border);
            color: var(--color-text);
            font-weight: 500;
            padding: 0.5rem 1.25rem;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .btn-outline:hover {
            border-color: var(--color-accent-blue);
            color: var(--color-accent-blue);
            background: rgba(56, 189, 248, 0.1);
        }

        /* Flash Messages */
        .flash-container {
            margin-bottom: 1.5rem;
        }

        .alert {
            border-radius: 10px;
            border: 1px solid;
            background: rgba(11, 16, 32, 0.9);
            backdrop-filter: blur(10px);
        }

        .alert-success {
            border-color: rgba(52, 199, 89, 0.3);
            color: var(--color-accent-green);
        }

        .alert-info {
            border-color: rgba(56, 189, 248, 0.3);
            color: var(--color-accent-blue);
        }

        .alert-warning {
            border-color: rgba(251, 191, 36, 0.3);
            color: var(--color-accent);
        }

        /* Mobile Sidebar Toggle */
        .sidebar-toggle {
            display: none;
            background: none;
            border: none;
            color: var(--color-text);
            font-size: 1.5rem;
            padding: 0.5rem;
        }

        /* Responsive Design */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
                z-index: 1001;
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .sidebar-toggle {
                display: block;
            }
            
            .overlay {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.5);
                z-index: 999;
            }
            
            .overlay.active {
                display: block;
            }
        }

        @media (max-width: 768px) {
            .content-wrapper {
                padding: 1rem;
            }
            
            .top-navbar {
                padding: 0.75rem 1rem;
            }
            
            .nav-search {
                max-width: 100%;
                margin-top: 0.5rem;
                order: 3;
                flex: 0 0 100%;
            }
            
            .nav-actions {
                margin-left: auto;
            }
            
            .page-header {
                flex-direction: column;
                gap: 1rem;
            }
            
            .page-actions {
                width: 100%;
                justify-content: flex-end;
            }
        }

        @media (max-width: 576px) {
            .sidebar {
                width: 100%;
            }
            
            .content-wrapper {
                padding: 0.75rem;
            }
            
            .page-title {
                font-size: 1.25rem;
            }
            
            .card-value {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
<div class="dashboard-container">
    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="brand-container">
                <div class="brand-logo">ZB</div>
                <div class="brand-text">
                    <h1>ZukBits</h1>
                    <p>Professional Dashboard</p>
                </div>
            </div>
        </div>
        
        <div class="sidebar-body">
            <!-- Navigation will be inserted from sidebar.php -->
            <?php require __DIR__ . '/../partials/sidebar.php'; ?>
        </div>
        
        <div class="sidebar-footer">
            <div class="user-profile">
                <div class="user-avatar">
                    <?= strtoupper(substr($_SESSION['user_name'] ?? 'U', 0, 1)) ?>
                </div>
                <div class="user-info">
                    <div class="user-name"><?= htmlspecialchars($_SESSION['user_name'] ?? 'User', ENT_QUOTES, 'UTF-8') ?></div>
                    <div class="user-role"><?= htmlspecialchars($_SESSION['user_role'] ?? 'Administrator', ENT_QUOTES, 'UTF-8') ?></div>
                </div>
                <button class="nav-action-btn" id="userMenuToggle">
                    <i class="bi bi-chevron-down"></i>
                </button>
            </div>
        </div>
    </aside>

    <!-- Overlay for mobile -->
    <div class="overlay" id="overlay" onclick="toggleSidebar()"></div>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Top Navigation Bar -->
        <nav class="top-navbar navbar navbar-expand-lg">
            <div class="container-fluid">
                <button class="sidebar-toggle" onclick="toggleSidebar()">
                    <i class="bi bi-list"></i>
                </button>
                
                <div class="nav-search">
                    <i class="bi bi-search search-icon"></i>
                    <input type="search" class="search-input" placeholder="Search dashboard...">
                </div>
                
                <div class="nav-actions">
                    <button class="nav-action-btn" title="Notifications">
                        <i class="bi bi-bell"></i>
                        <span class="notification-badge">3</span>
                    </button>
                    
                    <button class="nav-action-btn" title="Messages">
                        <i class="bi bi-envelope"></i>
                        <span class="notification-badge">5</span>
                    </button>
                    
                    <div class="dropdown">
                        <button class="nav-action-btn dropdown-toggle" type="button" data-bs-toggle="dropdown">
                            <i class="bi bi-gear"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="#"><i class="bi bi-person me-2"></i>Profile</a></li>
                            <li><a class="dropdown-item" href="#"><i class="bi bi-sliders me-2"></i>Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="/logout"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Content Area -->
        <div class="content-wrapper">
            <!-- Flash Messages -->
            <div class="flash-container">
                <?php require __DIR__ . '/../partials/flash.php'; ?>
            </div>
            
            <!-- Page Content -->
            <?= $content ?>
        </div>
    </main>
</div>

<!-- Bootstrap JS Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Sidebar toggle functionality
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('overlay');
        sidebar.classList.toggle('active');
        overlay.classList.toggle('active');
    }

    // Close sidebar when clicking on overlay
    document.getElementById('overlay').addEventListener('click', toggleSidebar);

    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(event) {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('overlay');
        const toggleBtn = document.querySelector('.sidebar-toggle');
        
        if (window.innerWidth <= 992) {
            if (!sidebar.contains(event.target) && 
                !toggleBtn.contains(event.target) && 
                sidebar.classList.contains('active')) {
                toggleSidebar();
            }
        }
    });

    // Active nav link highlighting
    document.addEventListener('DOMContentLoaded', function() {
        const currentPath = window.location.pathname;
        const navLinks = document.querySelectorAll('.nav-link');
        
        navLinks.forEach(link => {
            if (link.getAttribute('href') === currentPath) {
                link.classList.add('active');
            }
        });
    });

    // Search functionality
    const searchInput = document.querySelector('.search-input');
    searchInput.addEventListener('input', function(e) {
        // Implement search logic here
        console.log('Searching for:', e.target.value);
    });

    // Theme toggle functionality (dark/light)
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            const currentTheme = document.body.getAttribute('data-theme') || 'dark';
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            document.body.setAttribute('data-theme', newTheme);
            localStorage.setItem('zb-theme', newTheme);
            this.querySelector('i').className = newTheme === 'dark' ? 'bi bi-moon' : 'bi bi-sun';
        });
    }

    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Resize observer for responsive behavior
    const resizeObserver = new ResizeObserver(entries => {
        for (let entry of entries) {
            if (entry.contentRect.width > 992) {
                const sidebar = document.getElementById('sidebar');
                const overlay = document.getElementById('overlay');
                sidebar.classList.remove('active');
                overlay.classList.remove('active');
            }
        }
    });

    resizeObserver.observe(document.body);
</script>
</body>
</html>