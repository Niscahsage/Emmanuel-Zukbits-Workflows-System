<?php
// app/views/layouts/auth.php
// Layout for authentication pages (login, reset password, etc.)

$app       = app_config();
$appName   = $app['name'] ?? 'ZukBits Online';
$pageTitle = $pageTitle ?? 'Login';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?= htmlspecialchars($appName . ' – ' . $pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#050816">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <style>
        :root {
            /* ===== CORE COLORS ===== */
            --color-bg: #050816;
            --color-surface: #0b1020;
            --color-surface-alt: #111827;
            --color-surface-soft: #0f172a;
            
            /* ===== ACCENT COLORS ===== */
            --color-accent: #ffc857;
            --color-accent-strong: #fbbf24;
            --color-accent-soft: rgba(255, 200, 87, 0.15);
            --color-accent-blue: #38bdf8;
            --color-accent-purple: #a855f7;
            --color-accent-green: #34c759;
            
            /* ===== TEXT COLORS ===== */
            --color-text: #f7f7ff;
            --color-text-muted: #c3c5d4;
            
            /* ===== BORDER COLORS ===== */
            --color-border: #22263b;
            --color-border-light: rgba(148, 163, 253, 0.35);
            --color-border-medium: rgba(148, 163, 253, 0.45);
            
            /* ===== GRADIENTS ===== */
            --gradient-primary: linear-gradient(135deg, var(--color-accent-blue), var(--color-accent-purple));
            --gradient-bg-dark: linear-gradient(90deg, #111827, #020617);
            --gradient-bg-hero: radial-gradient(circle at top left, rgba(148, 163, 253, 0.14), transparent 60%);
            --gradient-bg-card: radial-gradient(circle at top left, rgba(148, 163, 253, 0.18), rgba(15, 23, 42, 0.96));
            
            /* ===== SHADOWS ===== */
            --shadow-blue: rgba(56, 189, 248, 0.35);
            --shadow-dark: rgba(0, 0, 0, 0.45);
        }

        body {
            background: var(--gradient-bg-dark);
            color: var(--color-text);
            min-height: 100vh;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            overflow-x: hidden;
        }

        .auth-wrapper {
            min-height: 100vh;
            padding: 2rem 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .auth-wrapper::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 40%;
            background: var(--gradient-primary);
            opacity: 0.05;
            border-radius: 0 0 50% 50%;
            z-index: 0;
        }

        .auth-card {
            background: var(--gradient-bg-card);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            border: 1px solid var(--color-border-light);
            box-shadow: 0 20px 60px var(--shadow-dark),
                        0 0 0 1px rgba(148, 163, 253, 0.1);
            overflow: hidden;
            z-index: 1;
            position: relative;
        }

        .auth-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--gradient-primary);
            z-index: 2;
        }

        .auth-header {
            padding: 2rem 2rem 1.5rem;
            background: radial-gradient(circle at top left, rgba(56, 189, 248, 0.1), transparent 70%);
            border-bottom: 1px solid var(--color-border);
        }

        .auth-brand {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .brand-logo {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            background: var(--gradient-primary);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 1.2rem;
            box-shadow: 0 8px 20px var(--shadow-blue);
        }

        .brand-text h1 {
            font-size: 1.4rem;
            font-weight: 700;
            margin: 0;
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .brand-text p {
            color: var(--color-text-muted);
            margin: 0;
            font-size: 0.9rem;
        }

        .auth-title {
            font-size: 1.1rem;
            font-weight: 600;
            margin: 0 0 0.5rem;
            color: var(--color-text);
        }

        .auth-subtitle {
            color: var(--color-text-muted);
            font-size: 0.9rem;
            margin: 0;
        }

        .auth-body {
            padding: 1.5rem 2rem 2rem;
        }

        .auth-footer {
            padding: 1rem 2rem;
            border-top: 1px solid var(--color-border);
            color: var(--color-text-muted);
            font-size: 0.85rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: rgba(5, 8, 22, 0.5);
        }

        .form-control {
            background: rgba(11, 16, 32, 0.6);
            border: 1px solid var(--color-border);
            color: var(--color-text);
            border-radius: 10px;
            padding: 0.75rem 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            background: rgba(11, 16, 32, 0.8);
            border-color: var(--color-accent-blue);
            box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.15);
            color: var(--color-text);
        }

        .form-control::placeholder {
            color: var(--color-text-muted);
            opacity: 0.6;
        }

        .form-label {
            color: var(--color-text);
            font-weight: 500;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }

        .btn-accent {
            background: var(--gradient-primary);
            border: none;
            color: white;
            font-weight: 600;
            padding: 0.75rem 1.5rem;
            border-radius: 10px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .btn-accent:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px var(--shadow-blue);
            color: white;
        }

        .btn-accent::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(rgba(255,255,255,0.1), transparent);
            border-radius: 10px;
        }

        .flash-auth {
            background: rgba(56, 189, 248, 0.1);
            border: 1px solid rgba(56, 189, 248, 0.3);
            color: var(--color-accent-blue);
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1.5rem;
        }

        .auth-tagline {
            font-style: italic;
            color: var(--color-accent);
            font-weight: 500;
        }

        .security-badge {
            background: rgba(34, 197, 94, 0.1);
            border: 1px solid rgba(34, 197, 94, 0.3);
            color: var(--color-accent-green);
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        @media (max-width: 768px) {
            .auth-card {
                margin: 1rem;
            }
            
            .auth-header,
            .auth-body,
            .auth-footer {
                padding: 1.5rem;
            }
            
            .auth-footer {
                flex-direction: column;
                gap: 0.5rem;
                text-align: center;
            }
        }

        @media (max-width: 576px) {
            .auth-wrapper {
                padding: 1rem;
            }
            
            .auth-card {
                border-radius: 15px;
            }
            
            .auth-header,
            .auth-body {
                padding: 1.25rem;
            }
            
            .brand-logo {
                width: 42px;
                height: 42px;
            }
        }
    </style>
</head>
<body>
<div class="auth-wrapper">
    <div class="auth-card col-12 col-md-8 col-lg-5 col-xl-4">
        <div class="auth-header">
            <div class="auth-brand">
                <div class="brand-logo">
                    ZB
                </div>
                <div class="brand-text">
                    <h1>ZukBits Online</h1>
                    <p>Professional Dashboard</p>
                </div>
            </div>
            
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2 class="auth-title"><?= htmlspecialchars($pageTitle === 'Login' ? 'Welcome Back' : $pageTitle, ENT_QUOTES, 'UTF-8') ?></h2>
                    <p class="auth-subtitle"><?= htmlspecialchars($pageTitle === 'Login' ? 'Sign in to continue to your dashboard' : 'Complete your account setup', ENT_QUOTES, 'UTF-8') ?></p>
                </div>
                <span class="security-badge">
                    <i class="bi bi-shield-check me-1"></i> Secure
                </span>
            </div>
        </div>

        <div class="auth-body">
            <?php if (!empty($_SESSION['flash'])): ?>
                <div class="flash-auth d-flex align-items-center">
                    <i class="bi bi-info-circle-fill me-2"></i>
                    <?= htmlspecialchars($_SESSION['flash'], ENT_QUOTES, 'UTF-8') ?>
                </div>
                <?php unset($_SESSION['flash']); ?>
            <?php endif; ?>

            <!-- Page content (forms) -->
            <?= $content ?>
        </div>

        <div class="auth-footer">
            <span class="auth-tagline">Make it happen!</span>
            <span>&copy; <?= date('Y') ?> ZukBits Online. All rights reserved.</span>
        </div>
    </div>
</div>

<!-- Bootstrap JS Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Form interaction enhancements
    document.addEventListener('DOMContentLoaded', function() {
        // Add floating labels effect
        const formInputs = document.querySelectorAll('.form-control');
        formInputs.forEach(input => {
            // Add focus effect
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('focused');
            });
            
            input.addEventListener('blur', function() {
                if (!this.value) {
                    this.parentElement.classList.remove('focused');
                }
            });
        });

        // Password visibility toggle
        const passwordToggles = document.querySelectorAll('.password-toggle');
        passwordToggles.forEach(toggle => {
            toggle.addEventListener('click', function() {
                const input = this.previousElementSibling;
                const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
                input.setAttribute('type', type);
                this.classList.toggle('bi-eye');
                this.classList.toggle('bi-eye-slash');
            });
        });
    });
</script>
</body>
</html>