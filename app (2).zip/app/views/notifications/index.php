<?php
// app/views/notifications/index.php
// index.php lists notifications for the currently logged-in user.

/** @var array $notifications */

use App\core\View;
use App\core\Auth;

$user = Auth::user();

// Add CSS variables and styles inline for this page
?>
<style>
    :root {
        /* ===== CORE COLORS ===== */
        --color-bg: #050816;
        --color-surface: #0b1020;
        --color-surface-alt: #111827;
        --color-surface-soft: #0f172a;
        
        /* ===== ACCENT COLORS ===== */
        --color-accent: #ffc857;
        --color-accent-strong: #fbbf24;
        --color-accent-soft: rgba(255, 200, 87, 0.15);
        --color-accent-blue: #38bdf8;
        --color-accent-purple: #a855f7;
        --color-accent-green: #34c759;
        --color-accent-red: #ef4444;
        --color-accent-indigo: #6366f1;
        
        /* ===== TEXT COLORS ===== */
        --color-text: #f7f7ff;
        --color-text-muted: #c3c5d4;
        
        /* ===== BORDER COLORS ===== */
        --color-border: #22263b;
        --color-border-light: rgba(148, 163, 253, 0.35);
        
        /* ===== GRADIENTS ===== */
        --gradient-primary: linear-gradient(135deg, var(--color-accent-blue), var(--color-accent-purple));
        --gradient-bg-card: radial-gradient(circle at top left, rgba(148, 163, 253, 0.18), rgba(15, 23, 42, 0.96));
        
        /* ===== SHADOWS ===== */
        --shadow-blue: rgba(56, 189, 248, 0.35);
        --shadow-dark: rgba(0, 0, 0, 0.45);
    }

    .notifications-container {
        max-width: 1200px;
        margin: 0 auto;
    }

    .page-header {
        margin-bottom: 2rem;
    }

    .page-title {
        font-size: 1.75rem;
        font-weight: 700;
        margin: 0 0 0.5rem;
        color: var(--color-text);
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .page-title i {
        background: var(--gradient-primary);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        font-size: 1.5rem;
    }

    .page-subtitle {
        color: var(--color-text-muted);
        font-size: 0.95rem;
        margin: 0;
    }

    .header-actions {
        display: flex;
        gap: 0.75rem;
        align-items: center;
    }

    .btn-mark-all {
        background: var(--gradient-primary);
        border: none;
        color: white;
        font-weight: 600;
        padding: 0.5rem 1.25rem;
        border-radius: 8px;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .btn-mark-all:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px var(--shadow-blue);
    }

    .notifications-empty-state {
        background: var(--gradient-bg-card);
        border: 1px solid var(--color-border-light);
        border-radius: 16px;
        padding: 3rem 2rem;
        text-align: center;
        margin: 2rem 0;
    }

    .empty-icon {
        width: 80px;
        height: 80px;
        background: rgba(56, 189, 248, 0.1);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 1.5rem;
        color: var(--color-accent-blue);
        font-size: 2rem;
    }

    .empty-title {
        font-size: 1.25rem;
        font-weight: 600;
        color: var(--color-text);
        margin-bottom: 0.5rem;
    }

    .empty-description {
        color: var(--color-text-muted);
        margin-bottom: 1.5rem;
    }

    /* Filter Tabs */
    .filter-tabs {
        display: flex;
        gap: 0.5rem;
        margin-bottom: 1.5rem;
        overflow-x: auto;
        padding-bottom: 0.5rem;
    }

    .filter-tab {
        background: rgba(11, 16, 32, 0.6);
        border: 1px solid var(--color-border);
        color: var(--color-text-muted);
        padding: 0.5rem 1.25rem;
        border-radius: 8px;
        font-weight: 500;
        transition: all 0.3s ease;
        white-space: nowrap;
    }

    .filter-tab:hover,
    .filter-tab.active {
        background: var(--gradient-primary);
        color: white;
        border-color: transparent;
    }

    .filter-tab-badge {
        background: rgba(255, 255, 255, 0.15);
        color: white;
        font-size: 0.75rem;
        padding: 0.15rem 0.5rem;
        border-radius: 10px;
        margin-left: 0.5rem;
    }

    /* Notification Cards */
    .notification-list {
        display: flex;
        flex-direction: column;
        gap: 0.75rem;
    }

    .notification-card {
        background: var(--gradient-bg-card);
        border: 1px solid var(--color-border-light);
        border-radius: 12px;
        padding: 1.25rem;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
    }

    .notification-card.unread {
        border-left: 4px solid var(--color-accent-blue);
        background: radial-gradient(circle at top left, rgba(56, 189, 248, 0.15), rgba(15, 23, 42, 0.96));
    }

    .notification-card.unread::before {
        content: '';
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        width: 4px;
        background: var(--color-accent-blue);
    }

    .notification-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.3);
        border-color: rgba(148, 163, 253, 0.5);
    }

    .notification-header {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        margin-bottom: 0.75rem;
    }

    .notification-icon {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        margin-right: 0.75rem;
        flex-shrink: 0;
    }

    .icon-info {
        background: rgba(56, 189, 248, 0.15);
        color: var(--color-accent-blue);
    }

    .icon-success {
        background: rgba(52, 199, 89, 0.15);
        color: var(--color-accent-green);
    }

    .icon-warning {
        background: rgba(251, 191, 36, 0.15);
        color: var(--color-accent);
    }

    .icon-error {
        background: rgba(239, 68, 68, 0.15);
        color: var(--color-accent-red);
    }

    .icon-system {
        background: rgba(168, 85, 247, 0.15);
        color: var(--color-accent-purple);
    }

    .notification-content {
        flex: 1;
    }

    .notification-title {
        font-size: 1rem;
        font-weight: 600;
        color: var(--color-text);
        margin: 0 0 0.25rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .notification-title .badge {
        font-size: 0.7rem;
        padding: 0.15rem 0.5rem;
        border-radius: 6px;
        font-weight: 600;
    }

    .badge-project {
        background: rgba(56, 189, 248, 0.15);
        color: var(--color-accent-blue);
        border: 1px solid rgba(56, 189, 248, 0.3);
    }

    .badge-system {
        background: rgba(168, 85, 247, 0.15);
        color: var(--color-accent-purple);
        border: 1px solid rgba(168, 85, 247, 0.3);
    }

    .badge-alert {
        background: rgba(239, 68, 68, 0.15);
        color: var(--color-accent-red);
        border: 1px solid rgba(239, 68, 68, 0.3);
    }

    .notification-body {
        color: var(--color-text-muted);
        font-size: 0.9rem;
        line-height: 1.5;
        margin-bottom: 0.75rem;
    }

    .notification-meta {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top: 0.75rem;
        padding-top: 0.75rem;
        border-top: 1px solid rgba(148, 163, 253, 0.1);
    }

    .notification-time {
        font-size: 0.8rem;
        color: var(--color-text-muted);
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .notification-time i {
        color: var(--color-accent-blue);
    }

    .notification-actions {
        display: flex;
        gap: 0.5rem;
    }

    .btn-notification {
        padding: 0.25rem 0.75rem;
        border-radius: 6px;
        font-size: 0.8rem;
        font-weight: 500;
        transition: all 0.3s ease;
        border: none;
        display: flex;
        align-items: center;
        gap: 0.25rem;
    }

    .btn-mark-read {
        background: rgba(56, 189, 248, 0.1);
        color: var(--color-accent-blue);
        border: 1px solid rgba(56, 189, 248, 0.3);
    }

    .btn-mark-read:hover {
        background: rgba(56, 189, 248, 0.2);
        border-color: var(--color-accent-blue);
    }

    .btn-view {
        background: rgba(52, 199, 89, 0.1);
        color: var(--color-accent-green);
        border: 1px solid rgba(52, 199, 89, 0.3);
    }

    .btn-view:hover {
        background: rgba(52, 199, 89, 0.2);
        border-color: var(--color-accent-green);
    }

    .btn-dismiss {
        background: rgba(239, 68, 68, 0.1);
        color: var(--color-accent-red);
        border: 1px solid rgba(239, 68, 68, 0.3);
    }

    .btn-dismiss:hover {
        background: rgba(239, 68, 68, 0.2);
        border-color: var(--color-accent-red);
    }

    .notification-link {
        color: var(--color-accent-blue);
        text-decoration: none;
        font-size: 0.85rem;
        display: flex;
        align-items: center;
        gap: 0.25rem;
        transition: all 0.3s ease;
    }

    .notification-link:hover {
        color: var(--color-accent);
        text-decoration: underline;
    }

    /* Stats Cards */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 1rem;
        margin-bottom: 2rem;
    }

    .stat-card {
        background: var(--gradient-bg-card);
        border: 1px solid var(--color-border-light);
        border-radius: 12px;
        padding: 1.25rem;
        transition: all 0.3s ease;
    }

    .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
    }

    .stat-value {
        font-size: 2rem;
        font-weight: 700;
        color: var(--color-text);
        margin-bottom: 0.25rem;
    }

    .stat-label {
        font-size: 0.85rem;
        color: var(--color-text-muted);
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .stat-trend {
        font-size: 0.8rem;
        display: flex;
        align-items: center;
        gap: 0.25rem;
        margin-top: 0.5rem;
    }

    .trend-up {
        color: var(--color-accent-green);
    }

    .trend-down {
        color: var(--color-accent-red);
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .page-header {
            flex-direction: column;
            gap: 1rem;
            align-items: flex-start;
        }
        
        .header-actions {
            width: 100%;
            justify-content: flex-end;
        }
        
        .notification-header {
            flex-direction: column;
            gap: 0.75rem;
        }
        
        .notification-meta {
            flex-direction: column;
            gap: 0.75rem;
            align-items: flex-start;
        }
        
        .notification-actions {
            width: 100%;
            justify-content: flex-end;
        }
        
        .stats-grid {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    @media (max-width: 576px) {
        .stats-grid {
            grid-template-columns: 1fr;
        }
        
        .filter-tabs {
            flex-wrap: wrap;
        }
        
        .notification-card {
            padding: 1rem;
        }
    }
</style>

<div class="notifications-container">
    <!-- Page Header -->
    <div class="page-header d-flex justify-content-between align-items-center">
        <div>
            <h1 class="page-title">
                <i class="bi bi-bell-fill"></i>
                Notifications
            </h1>
            <p class="page-subtitle">
                Stay updated with messages and alerts related to your projects, approvals, and schedules.
            </p>
        </div>
        
        <div class="header-actions">
            <?php if (!empty($notifications)): ?>
                <form method="post" action="/notifications/mark-all-read" class="m-0">
                    <button type="submit" class="btn-mark-all">
                        <i class="bi bi-check-all"></i>
                        Mark All as Read
                    </button>
                </form>
                <button class="btn btn-outline" onclick="clearAllNotifications()">
                    <i class="bi bi-trash"></i>
                    Clear All
                </button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Stats Overview -->
    <?php
    $unreadCount = 0;
    $todayCount = 0;
    $weekCount = 0;
    $totalCount = count($notifications);
    
    if (!empty($notifications)) {
        $now = time();
        $oneDayAgo = strtotime('-1 day');
        $oneWeekAgo = strtotime('-7 days');
        
        foreach ($notifications as $n) {
            $isRead = !empty($n['is_read']);
            $createdAt = strtotime($n['created_at'] ?? '');
            
            if (!$isRead) {
                $unreadCount++;
            }
            
            if ($createdAt >= $oneDayAgo) {
                $todayCount++;
            }
            
            if ($createdAt >= $oneWeekAgo) {
                $weekCount++;
            }
        }
    }
    ?>
    
    <?php if (!empty($notifications)): ?>
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-value"><?= $totalCount ?></div>
            <div class="stat-label">Total Notifications</div>
            <div class="stat-trend">
                <span class="trend-up">+<?= $weekCount ?> this week</span>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-value"><?= $unreadCount ?></div>
            <div class="stat-label">Unread</div>
            <div class="stat-trend">
                <?php if ($unreadCount > 0): ?>
                    <span class="trend-up">Requires attention</span>
                <?php else: ?>
                    <span class="trend-down">All caught up!</span>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-value"><?= $todayCount ?></div>
            <div class="stat-label">Today</div>
            <div class="stat-trend">
                <?php if ($todayCount > 0): ?>
                    <span class="trend-up">Active today</span>
                <?php else: ?>
                    <span class="trend-down">No new today</span>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-value"><?= $weekCount ?></div>
            <div class="stat-label">This Week</div>
            <div class="stat-trend">
                <span class="trend-up">Last 7 days</span>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Filter Tabs -->
    <?php if (!empty($notifications)): ?>
    <div class="filter-tabs">
        <button class="filter-tab active" onclick="filterNotifications('all')">
            All Notifications
            <span class="filter-tab-badge"><?= $totalCount ?></span>
        </button>
        <button class="filter-tab" onclick="filterNotifications('unread')">
            Unread
            <span class="filter-tab-badge"><?= $unreadCount ?></span>
        </button>
        <button class="filter-tab" onclick="filterNotifications('today')">
            Today
            <span class="filter-tab-badge"><?= $todayCount ?></span>
        </button>
        <button class="filter-tab" onclick="filterNotifications('system')">
            System
        </button>
        <button class="filter-tab" onclick="filterNotifications('alerts')">
            Alerts
        </button>
    </div>
    <?php endif; ?>

    <!-- Notifications List -->
    <?php if (empty($notifications)): ?>
        <div class="notifications-empty-state">
            <div class="empty-icon">
                <i class="bi bi-bell-slash"></i>
            </div>
            <h3 class="empty-title">No notifications yet</h3>
            <p class="empty-description">
                You're all caught up! New notifications will appear here when available.
            </p>
            <a href="/dashboard" class="btn btn-primary">
                <i class="bi bi-arrow-left"></i>
                Return to Dashboard
            </a>
        </div>
    <?php else: ?>
        <div class="notification-list" id="notificationList">
            <?php foreach ($notifications as $n): ?>
                <?php
                $id = (int) ($n['id'] ?? 0);
                $title = $n['title'] ?? ($n['subject'] ?? 'Notification');
                $body = $n['body'] ?? '';
                $linkUrl = $n['link_url'] ?? ($n['url'] ?? '');
                $createdAt = $n['created_at'] ?? '';
                $isRead = !empty($n['is_read']);
                $type = $n['type'] ?? 'info';
                
                // Determine icon and badge based on type
                $iconClass = 'icon-info';
                $badgeClass = 'badge-project';
                $icon = 'bi-info-circle';
                
                switch ($type) {
                    case 'success':
                    case 'completed':
                        $iconClass = 'icon-success';
                        $badgeClass = 'badge-success';
                        $icon = 'bi-check-circle';
                        break;
                    case 'warning':
                    case 'alert':
                        $iconClass = 'icon-warning';
                        $badgeClass = 'badge-alert';
                        $icon = 'bi-exclamation-triangle';
                        break;
                    case 'error':
                    case 'failed':
                        $iconClass = 'icon-error';
                        $badgeClass = 'badge-alert';
                        $icon = 'bi-x-circle';
                        break;
                    case 'system':
                        $iconClass = 'icon-system';
                        $badgeClass = 'badge-system';
                        $icon = 'bi-gear';
                        break;
                }
                
                // Format time
                $timeAgo = '';
                if ($createdAt) {
                    $time = strtotime($createdAt);
                    $diff = time() - $time;
                    
                    if ($diff < 60) {
                        $timeAgo = 'Just now';
                    } elseif ($diff < 3600) {
                        $minutes = floor($diff / 60);
                        $timeAgo = $minutes . ' min ago';
                    } elseif ($diff < 86400) {
                        $hours = floor($diff / 3600);
                        $timeAgo = $hours . ' hour' . ($hours != 1 ? 's' : '') . ' ago';
                    } else {
                        $days = floor($diff / 86400);
                        if ($days == 1) {
                            $timeAgo = 'Yesterday';
                        } else {
                            $timeAgo = $days . ' days ago';
                        }
                    }
                }
                ?>
                
                <div class="notification-card <?= $isRead ? '' : 'unread' ?>" 
                     data-type="<?= $type ?>"
                     data-read="<?= $isRead ? 'true' : 'false' ?>"
                     data-date="<?= $createdAt ?>">
                    
                    <div class="notification-header">
                        <div class="d-flex align-items-start w-100">
                            <div class="notification-icon <?= $iconClass ?>">
                                <i class="bi <?= $icon ?>"></i>
                            </div>
                            
                            <div class="notification-content">
                                <h3 class="notification-title">
                                    <?= View::e($title) ?>
                                    <?php if ($type == 'alert'): ?>
                                        <span class="badge badge-alert">Alert</span>
                                    <?php elseif ($type == 'system'): ?>
                                        <span class="badge badge-system">System</span>
                                    <?php endif; ?>
                                </h3>
                                
                                <?php if ($body !== ''): ?>
                                    <p class="notification-body">
                                        <?= nl2br(View::e($body)) ?>
                                    </p>
                                <?php endif; ?>
                                
                                <?php if ($linkUrl): ?>
                                    <a href="<?= View::e($linkUrl) ?>" class="notification-link">
                                        <i class="bi bi-arrow-up-right"></i>
                                        View related item
                                    </a>
                                <?php endif; ?>
                                
                                <div class="notification-meta">
                                    <div class="notification-time">
                                        <i class="bi bi-clock"></i>
                                        <?php if ($createdAt): ?>
                                            <span><?= $timeAgo ?></span>
                                            <span class="text-muted ms-2">• <?= View::e(date('M j, Y g:i A', strtotime($createdAt))) ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">–</span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="notification-actions">
                                        <?php if (!$isRead): ?>
                                            <form method="post" action="/notifications/mark-read" class="d-inline">
                                                <input type="hidden" name="id" value="<?= View::e((string)$id) ?>">
                                                <button type="submit" class="btn-notification btn-mark-read">
                                                    <i class="bi bi-check"></i>
                                                    Mark Read
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        
                                        <?php if ($linkUrl): ?>
                                            <a href="<?= View::e($linkUrl) ?>" class="btn-notification btn-view">
                                                <i class="bi bi-eye"></i>
                                                View
                                            </a>
                                        <?php endif; ?>
                                        
                                        <button class="btn-notification btn-dismiss" onclick="dismissNotification(<?= $id ?>)">
                                            <i class="bi bi-x"></i>
                                            Dismiss
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Pagination or Load More -->
        <div class="d-flex justify-content-center mt-4">
            <button class="btn btn-outline" onclick="loadMoreNotifications()">
                <i class="bi bi-arrow-clockwise me-2"></i>
                Load Older Notifications
            </button>
        </div>
    <?php endif; ?>
</div>

<script>
    // Filter notifications
    function filterNotifications(filter) {
        const cards = document.querySelectorAll('.notification-card');
        const tabs = document.querySelectorAll('.filter-tab');
        
        // Update active tab
        tabs.forEach(tab => tab.classList.remove('active'));
        event.target.classList.add('active');
        
        // Filter cards
        cards.forEach(card => {
            const type = card.getAttribute('data-type');
            const isRead = card.getAttribute('data-read') === 'true';
            const date = new Date(card.getAttribute('data-date'));
            const now = new Date();
            const oneDayAgo = new Date(now - 24 * 60 * 60 * 1000);
            
            let show = false;
            
            switch(filter) {
                case 'all':
                    show = true;
                    break;
                case 'unread':
                    show = !isRead;
                    break;
                case 'today':
                    show = date >= oneDayAgo;
                    break;
                case 'system':
                    show = type === 'system';
                    break;
                case 'alerts':
                    show = type === 'alert' || type === 'warning' || type === 'error';
                    break;
            }
            
            if (show) {
                card.style.display = 'block';
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 10);
            } else {
                card.style.opacity = '0';
                card.style.transform = 'translateY(-10px)';
                setTimeout(() => {
                    card.style.display = 'none';
                }, 300);
            }
        });
    }
    
    // Dismiss notification
    function dismissNotification(id) {
        if (confirm('Are you sure you want to dismiss this notification?')) {
            // In a real implementation, you'd make an AJAX call here
            console.log('Dismissing notification:', id);
            
            // Simulate dismissal
            const card = event.target.closest('.notification-card');
            card.style.opacity = '0';
            card.style.transform = 'translateX(100px)';
            
            setTimeout(() => {
                card.remove();
                updateNotificationCounts();
            }, 300);
        }
    }
    
    // Clear all notifications
    function clearAllNotifications() {
        if (confirm('Are you sure you want to clear all notifications? This cannot be undone.')) {
            // In a real implementation, you'd make an AJAX call here
            console.log('Clearing all notifications');
            
            const cards = document.querySelectorAll('.notification-card');
            cards.forEach((card, index) => {
                setTimeout(() => {
                    card.style.opacity = '0';
                    card.style.transform = 'translateX(100px)';
                    
                    setTimeout(() => {
                        card.remove();
                        if (index === cards.length - 1) {
                            showEmptyState();
                        }
                    }, 300);
                }, index * 100);
            });
        }
    }
    
    // Load more notifications
    function loadMoreNotifications() {
        // In a real implementation, you'd make an AJAX call here
        console.log('Loading more notifications...');
        event.target.innerHTML = '<i class="bi bi-hourglass-split me-2"></i> Loading...';
        event.target.disabled = true;
        
        setTimeout(() => {
            event.target.innerHTML = '<i class="bi bi-arrow-clockwise me-2"></i> No more notifications';
            event.target.disabled = true;
        }, 1500);
    }
    
    // Update notification counts after actions
    function updateNotificationCounts() {
        const unreadCards = document.querySelectorAll('.notification-card[data-read="false"]');
        const today = new Date();
        const oneDayAgo = new Date(today - 24 * 60 * 60 * 1000);
        
        let todayCount = 0;
        document.querySelectorAll('.notification-card').forEach(card => {
            const date = new Date(card.getAttribute('data-date'));
            if (date >= oneDayAgo) todayCount++;
        });
        
        // Update badge counts
        const unreadBadge = document.querySelector('.filter-tab:nth-child(2) .filter-tab-badge');
        const todayBadge = document.querySelector('.filter-tab:nth-child(3) .filter-tab-badge');
        
        if (unreadBadge) unreadBadge.textContent = unreadCards.length;
        if (todayBadge) todayBadge.textContent = todayCount;
        
        // Update stats
        const totalStat = document.querySelector('.stat-card:nth-child(1) .stat-value');
        const unreadStat = document.querySelector('.stat-card:nth-child(2) .stat-value');
        const todayStat = document.querySelector('.stat-card:nth-child(3) .stat-value');
        
        if (totalStat) totalStat.textContent = document.querySelectorAll('.notification-card').length;
        if (unreadStat) unreadStat.textContent = unreadCards.length;
        if (todayStat) todayStat.textContent = todayCount;
    }
    
    // Show empty state when all notifications are cleared
    function showEmptyState() {
        const notificationList = document.getElementById('notificationList');
        const filterTabs = document.querySelector('.filter-tabs');
        const statsGrid = document.querySelector('.stats-grid');
        
        if (notificationList && notificationList.children.length === 0) {
            notificationList.innerHTML = `
                <div class="notifications-empty-state">
                    <div class="empty-icon">
                        <i class="bi bi-bell-slash"></i>
                    </div>
                    <h3 class="empty-title">No notifications</h3>
                    <p class="empty-description">
                        All notifications have been cleared. New notifications will appear here when available.
                    </p>
                </div>
            `;
            
            if (filterTabs) filterTabs.style.display = 'none';
            if (statsGrid) statsGrid.style.display = 'none';
        }
    }
    
    // Mark all as read functionality with animation
    document.addEventListener('DOMContentLoaded', function() {
        const markAllForm = document.querySelector('form[action="/notifications/mark-all-read"]');
        if (markAllForm) {
            markAllForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Show loading state
                const button = this.querySelector('button[type="submit"]');
                const originalText = button.innerHTML;
                button.innerHTML = '<i class="bi bi-hourglass-split me-2"></i> Marking...';
                button.disabled = true;
                
                // Simulate API call
                setTimeout(() => {
                    // Mark all cards as read with animation
                    const cards = document.querySelectorAll('.notification-card.unread');
                    cards.forEach((card, index) => {
                        setTimeout(() => {
                            card.classList.remove('unread');
                            card.setAttribute('data-read', 'true');
                            
                            // Remove mark read buttons
                            const markReadBtn = card.querySelector('.btn-mark-read');
                            if (markReadBtn) {
                                markReadBtn.style.opacity = '0';
                                setTimeout(() => markReadBtn.remove(), 300);
                            }
                        }, index * 100);
                    });
                    
                    // Reset button
                    setTimeout(() => {
                        button.innerHTML = originalText;
                        button.disabled = false;
                        updateNotificationCounts();
                    }, 500);
                }, 800);
            });
        }
    });
</script>