<?php
// Super Admin dashboard: system-wide overview.

use App\core\View;

/** @var array $user */
/** @var array $stats */
/** @var int   $unread_count */

// Project totals from management stats
$name          = $user['name'] ?? 'Super Admin';
$totalProjects = (int) ($stats['projects_total']     ?? 0);
$ongoing       = (int) ($stats['projects_ongoing']   ?? 0);
$completed     = (int) ($stats['projects_completed'] ?? max(0, $totalProjects - $ongoing));

// Optional extra stats if needed later (approvals, overdue, etc.)
// $overdue        = (int) ($stats['projects_overdue']    ?? 0);
// $pendingApprovals = (int) ($stats['approvals_pending'] ?? 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Dashboard - ZukBits</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --color-bg: #050816;
            --color-surface: #0b1020;
            --color-surface-alt: #111827;
            --color-surface-soft: #0f172a;
            --color-accent: #ffc857;
            --color-accent-strong: #fbbf24;
            --color-accent-blue: #38bdf8;
            --color-accent-purple: #a855f7;
            --color-accent-green: #34c759;
            --color-accent-red: #ef4444;
            --color-text: #f7f7ff;
            --color-text-muted: #c3c5d4;
            --color-border: #22263b;
            --gradient-primary: linear-gradient(135deg, var(--color-accent-blue), var(--color-accent-purple));
            --gradient-bg-card: radial-gradient(circle at top left, rgba(148, 163, 253, 0.18), rgba(15, 23, 42, 0.96));
        }

        body {
            background: var(--color-bg);
            color: var(--color-text);
            min-height: 100vh;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }

        .dashboard-container {
            padding: 1.5rem;
            max-width: 1400px;
            margin: 0 auto;
        }

        /* Header Styles */
        .dashboard-header {
            background: var(--gradient-bg-card);
            border: 1px solid var(--color-border);
            border-radius: 20px;
            padding: 1.5rem 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            position: relative;
            overflow: hidden;
            border-top: 4px solid var(--color-accent-red);
        }

        .header-title {
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: 700;
            margin: 0;
        }

        .header-subtitle {
            color: var(--color-text-muted);
            font-size: 1rem;
        }

        .notification-btn {
            background: var(--color-surface-alt);
            border: 1px solid var(--color-border);
            border-radius: 12px;
            padding: 0.5rem 1rem;
            color: var(--color-text);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            transition: all 0.3s ease;
        }

        .notification-btn:hover {
            background: var(--color-surface);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        }

        .notification-badge {
            background: var(--gradient-primary);
            color: white;
            font-size: 0.75rem;
            min-width: 24px;
            height: 24px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-left: 0.5rem;
        }

        /* System Metrics */
        .system-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .system-card {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: 16px;
            padding: 1.5rem;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .system-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--gradient-primary);
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .system-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.4);
        }

        .system-card:hover::before {
            opacity: 1;
        }

        .system-label {
            color: var(--color-text-muted);
            font-size: 0.875rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.75rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .system-value {
            font-size: 2.5rem;
            font-weight: 700;
            line-height: 1;
            margin-bottom: 0.5rem;
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .system-description {
            color: var(--color-text-muted);
            font-size: 0.875rem;
            margin-bottom: 1rem;
            line-height: 1.5;
        }

        .system-link {
            color: var(--color-accent-blue);
            text-decoration: none;
            font-size: 0.875rem;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: color 0.2s ease;
        }

        .system-link:hover {
            color: var(--color-accent);
        }

        /* Control Cards */
        .control-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 1.5rem;
        }

        .control-card {
            background: var(--gradient-bg-card);
            border: 1px solid var(--color-border);
            border-radius: 16px;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .control-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.4);
        }

        .control-header {
            background: var(--color-surface-alt);
            padding: 1.25rem 1.5rem;
            border-bottom: 1px solid var(--color-border);
        }

        .control-title {
            font-weight: 600;
            font-size: 1.1rem;
            color: var(--color-text);
            margin: 0;
        }

        .control-body {
            padding: 1.5rem;
        }

        .control-description {
            color: var(--color-text-muted);
            font-size: 0.95rem;
            margin-bottom: 1.5rem;
            line-height: 1.6;
        }

        .control-list {
            margin: 0 0 1.5rem 0;
            padding-left: 1.5rem;
        }

        .control-list li {
            color: var(--color-text-muted);
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }

        .super-admin-warning {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.2);
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-left: 4px solid var(--color-accent-red);
        }

        .super-admin-warning p {
            color: var(--color-accent-red);
            margin: 0;
            font-weight: 500;
        }

        .btn-primary {
            background: var(--gradient-primary);
            border: none;
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(56, 189, 248, 0.25);
        }

        .btn-outline {
            background: transparent;
            border: 1px solid var(--color-border);
            color: var(--color-text);
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 500;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
        }

        .btn-outline:hover {
            background: var(--color-surface-alt);
            border-color: var(--color-border-light);
        }

        @media (max-width: 768px) {
            .dashboard-container {
                padding: 1rem;
            }
            
            .dashboard-header {
                padding: 1.25rem;
            }
            
            .system-grid,
            .control-grid {
                grid-template-columns: 1fr;
                gap: 1rem;
            }
            
            .system-card {
                padding: 1.25rem;
            }
            
            .control-body {
                padding: 1.25rem;
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .dashboard-header,
        .system-card,
        .control-card {
            animation: fadeInUp 0.6s ease-out;
        }

        .system-card:nth-child(2) { animation-delay: 0.1s; }
        .system-card:nth-child(3) { animation-delay: 0.2s; }
        .control-card:nth-child(2) { animation-delay: 0.3s; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Header -->
        <div class="dashboard-header">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center">
                <div class="mb-3 mb-md-0">
                    <h1 class="header-title h3 mb-2">
                        <i class="bi bi-shield-fill-plus me-2"></i>Super Admin Dashboard
                    </h1>
                    <p class="header-subtitle mb-0">
                        System-wide overview of users, projects, and alerts
                    </p>
                </div>
                <div>
                    <a href="/notifications" class="notification-btn">
                        <i class="bi bi-bell"></i>
                        <?php if ($unread_count > 0): ?>
                            <span class="notification-badge"><?= View::e((string)$unread_count) ?></span>
                        <?php endif; ?>
                    </a>
                </div>
            </div>
        </div>

        <!-- System Metrics -->
        <div class="system-grid">
            <div class="system-card">
                <div class="system-label">
                    <i class="bi bi-folder"></i>Projects
                </div>
                <div class="system-value"><?= View::e((string)$totalProjects) ?></div>
                <p class="system-description">Total projects across all teams</p>
                <a href="/projects" class="system-link">
                    Manage projects <i class="bi bi-arrow-right"></i>
                </a>
            </div>

            <div class="system-card">
                <div class="system-label">
                    <i class="bi bi-clock"></i>Ongoing
                </div>
                <div class="system-value"><?= View::e((string)$ongoing) ?></div>
                <p class="system-description">Active work in progress</p>
                <a href="/projects" class="system-link">
                    Check status <i class="bi bi-arrow-right"></i>
                </a>
            </div>

            <div class="system-card">
                <div class="system-label">
                    <i class="bi bi-check-circle"></i>Completed
                </div>
                <div class="system-value"><?= View::e((string)$completed) ?></div>
                <p class="system-description">Projects that reached completion</p>
                <a href="/projects" class="system-link">
                    Review output <i class="bi bi-arrow-right"></i>
                </a>
            </div>
        </div>

        <!-- Control Cards -->
        <div class="control-grid">
            <div class="control-card">
                <div class="control-header">
                    <h3 class="control-title">User Management</h3>
                </div>
                <div class="control-body">
                    <div class="super-admin-warning">
                        <p>
                            <i class="bi bi-shield-exclamation me-2"></i>
                            Exclusive Super Admin Access
                        </p>
                    </div>
                    <p class="control-description">
                        As Super Admin, you are the only account that can create and manage user accounts
                        system-wide.
                    </p>
                    <ul class="control-list">
                        <li>Create and deactivate user accounts</li>
                        <li>Assign roles (developer, marketer, system admin, director)</li>
                        <li>Reset passwords and manage access permissions</li>
                    </ul>
                    <a href="/users" class="btn-primary">
                        <i class="bi bi-people"></i>Manage Users
                    </a>
                </div>
            </div>

            <div class="control-card">
                <div class="control-header">
                    <h3 class="control-title">System Oversight</h3>
                </div>
                <div class="control-body">
                    <p class="control-description">
                        Monitor approvals, reports and configurations at a high level.
                    </p>
                    <ul class="control-list">
                        <li>Check the approvals inbox for critical sign-offs</li>
                        <li>Review weekly reporting activity across teams</li>
                        <li>Monitor system health and performance metrics</li>
                    </ul>
                    <div class="feature-actions">
                        <a href="/approvals" class="btn-outline">
                            <i class="bi bi-check-circle"></i>View Approvals
                        </a>
                        <a href="/reports" class="btn-primary">
                            <i class="bi bi-file-text"></i>Weekly Reports
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>