<?php
// edit.php displays a form to update an existing credential.
// Controller must pass: $credential

use App\core\View;

/** @var array $credential */

$id          = $credential['id'];
$projectId   = $credential['project_id'];
$label       = $credential['label'] ?? '';
$description = $credential['description'] ?? '';
$allowed     = $credential['allowed_roles'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Credential - ZukBits</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --color-bg: #050816;
            --color-surface: #0b1020;
            --color-surface-alt: #111827;
            --color-surface-soft: #0f172a;
            --color-accent: #ffc857;
            --color-accent-strong: #fbbf24;
            --color-accent-blue: #38bdf8;
            --color-accent-purple: #a855f7;
            --color-accent-green: #34c759;
            --color-text: #f7f7ff;
            --color-text-muted: #c3c5d4;
            --color-border: #22263b;
            --color-border-light: rgba(148, 163, 253, 0.35);
            --gradient-primary: linear-gradient(135deg, var(--color-accent-blue), var(--color-accent-purple));
            --gradient-bg-card: radial-gradient(circle at top left, rgba(148, 163, 253, 0.18), rgba(15, 23, 42, 0.96));
        }

        body {
            background: var(--color-bg);
            color: var(--color-text);
            min-height: 100vh;
        }

        .container-fluid {
            padding: 1.5rem;
            max-width: 1200px;
            margin: 0 auto;
        }

        .dashboard-header {
            background: var(--gradient-bg-card);
            border: 1px solid var(--color-border);
            border-radius: 16px;
            padding: 1.5rem 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .header-title {
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: 700;
            margin: 0;
        }

        .form-card {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: 16px;
            padding: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .form-label {
            color: var(--color-text);
            font-weight: 500;
            margin-bottom: 0.5rem;
            font-size: 0.95rem;
        }

        .form-control, .form-select {
            background: var(--color-surface-alt);
            border: 1px solid var(--color-border);
            color: var(--color-text);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            transition: all 0.2s ease;
        }

        .form-control:focus, .form-select:focus {
            background: var(--color-surface-soft);
            border-color: var(--color-accent-blue);
            color: var(--color-text);
            box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.15);
        }

        .form-control:read-only {
            background: var(--color-surface);
            border-color: var(--color-border);
            color: var(--color-text-muted);
            cursor: not-allowed;
        }

        .form-text {
            color: var(--color-text-muted);
            font-size: 0.85rem;
            margin-top: 0.5rem;
        }

        .form-text i {
            color: var(--color-accent-blue);
        }

        .btn-primary {
            background: var(--gradient-primary);
            border: none;
            color: white;
            font-weight: 500;
            padding: 0.75rem 2rem;
            border-radius: 10px;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(56, 189, 248, 0.25);
        }

        .btn-outline-secondary {
            color: var(--color-text-muted);
            border-color: var(--color-border);
            background: transparent;
            border-radius: 10px;
            padding: 0.75rem 2rem;
        }

        .btn-outline-secondary:hover {
            background: var(--color-border);
            border-color: var(--color-border);
            color: var(--color-text);
        }

        .alert-info {
            background: rgba(56, 189, 248, 0.1);
            border: 1px solid rgba(56, 189, 248, 0.2);
            color: var(--color-accent-blue);
            border-radius: 12px;
            border-left: 4px solid var(--color-accent-blue);
        }

        .form-section {
            margin-bottom: 2rem;
            padding-bottom: 2rem;
            border-bottom: 1px solid var(--color-border);
        }

        .form-section:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .section-title {
            color: var(--color-accent);
            font-size: 1.1rem;
            margin-bottom: 1.5rem;
            padding-bottom: 0.75rem;
            border-bottom: 2px solid var(--color-border);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .credential-id {
            background: var(--color-surface-alt);
            border: 1px solid var(--color-border);
            border-radius: 12px;
            padding: 1rem 1.25rem;
            color: var(--color-text-muted);
            font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
            font-size: 0.9rem;
        }

        .credential-id strong {
            color: var(--color-accent);
        }

        .warning-note {
            background: rgba(251, 191, 36, 0.1);
            border: 1px solid rgba(251, 191, 36, 0.2);
            border-radius: 12px;
            padding: 1.25rem;
            color: var(--color-accent-strong);
            border-left: 4px solid var(--color-accent-strong);
        }

        .warning-note h5 {
            color: var(--color-accent-strong);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        @media (max-width: 768px) {
            .container-fluid {
                padding: 1rem;
            }
            
            .dashboard-header,
            .form-card {
                padding: 1.25rem;
            }
            
            .form-section {
                margin-bottom: 1.5rem;
                padding-bottom: 1.5rem;
            }
        }

        /* Read-only styling */
        .read-only-group {
            position: relative;
        }

        .read-only-badge {
            position: absolute;
            top: -8px;
            right: 12px;
            background: var(--color-surface);
            color: var(--color-text-muted);
            font-size: 0.7rem;
            padding: 2px 8px;
            border-radius: 4px;
            border: 1px solid var(--color-border);
        }

        /* Animation */
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(56, 189, 248, 0.4); }
            70% { box-shadow: 0 0 0 10px rgba(56, 189, 248, 0); }
            100% { box-shadow: 0 0 0 0 rgba(56, 189, 248, 0); }
        }

        .submitting {
            animation: pulse 2s infinite;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="dashboard-header">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center">
                <div class="mb-3 mb-md-0">
                    <h1 class="header-title h3 mb-2">
                        <i class="bi bi-pencil-square me-2"></i>Edit Credential
                    </h1>
                    <p class="text-muted mb-0">Update credential details and permissions</p>
                </div>
                <div>
                    <a href="/credentials/show?id=<?= View::e((string) $id) ?>" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left me-2"></i>Cancel
                    </a>
                </div>
            </div>
        </div>

        <div class="form-card">
            <form action="/credentials/update" method="post" id="editForm" onsubmit="return handleSubmit()">
                <input type="hidden" name="id" value="<?= View::e((string) $id) ?>">
                
                <!-- Credential ID Display -->
                <div class="form-section">
                    <div class="credential-id">
                        <strong>Credential ID:</strong> #<?= View::e((string) $id) ?>
                    </div>
                </div>

                <!-- Basic Information Section -->
                <div class="form-section">
                    <h3 class="section-title">
                        <i class="bi bi-info-circle"></i>Basic Information
                    </h3>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3 read-only-group">
                            <span class="read-only-badge">Read Only</span>
                            <label class="form-label">
                                <i class="bi bi-hash me-2"></i>Project ID
                            </label>
                            <input
                                type="number"
                                name="project_id"
                                class="form-control"
                                value="<?= View::e((string) $projectId) ?>"
                                required
                                readonly
                            >
                            <div class="form-text">
                                <i class="bi bi-lock me-1"></i>
                                Project ID cannot be changed
                            </div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label required">
                                <i class="bi bi-tag me-2"></i>Label
                            </label>
                            <input
                                type="text"
                                name="label"
                                class="form-control"
                                value="<?= View::e($label) ?>"
                                required
                                maxlength="100"
                                placeholder="Enter label"
                            >
                            <div class="form-text">
                                <i class="bi bi-info-circle me-1"></i>
                                A descriptive name for this credential
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-card-text me-2"></i>Description
                        </label>
                        <textarea 
                            name="description" 
                            rows="3" 
                            class="form-control"
                            placeholder="Optional description"
                            maxlength="500"
                        ><?= View::e($description) ?></textarea>
                        <div class="form-text">
                            <i class="bi bi-info-circle me-1"></i>
                            Maximum 500 characters
                        </div>
                    </div>
                </div>

                <!-- Permissions Section -->
                <div class="form-section">
                    <h3 class="section-title">
                        <i class="bi bi-shield-check"></i>Access Permissions
                    </h3>
                    
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-people me-2"></i>Allowed Roles
                        </label>
                        <input
                            type="text"
                            name="allowed_roles"
                            class="form-control"
                            value="<?= View::e($allowed) ?>"
                            placeholder="developer,system_admin,director"
                            oninput="validateRoles(this)"
                        >
                        <div class="form-text">
                            <i class="bi bi-info-circle me-1"></i>
                            Comma-separated list of role keys. Leave empty for project-assignees only.
                        </div>
                        <div class="invalid-feedback">
                            Please use valid role names (letters, numbers, underscores, hyphens)
                        </div>
                    </div>

                    <div class="alert alert-info">
                        <div class="d-flex align-items-start">
                            <i class="bi bi-info-circle-fill me-3 mt-1"></i>
                            <div>
                                <strong>Note:</strong> Changing roles will immediately affect who can access this credential.
                                Make sure to notify affected users of permission changes.
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Security Warning -->
                <div class="form-section">
                    <div class="warning-note">
                        <h5>
                            <i class="bi bi-exclamation-triangle"></i>Security Information
                        </h5>
                        <p class="mb-0">
                            Credential secrets cannot be edited. For security reasons, you must delete and recreate 
                            the credential if the secret value needs to be changed.
                        </p>
                        <div class="mt-2">
                            <a href="/credentials/delete?id=<?= View::e((string) $id) ?>" 
                               class="btn btn-sm btn-outline-danger mt-2"
                               onclick="return confirm('Are you sure you want to delete this credential? This cannot be undone.')">
                                <i class="bi bi-trash me-1"></i>Delete Credential
                            </a>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-3">
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="confirmChanges" required>
                        <label class="form-check-label" for="confirmChanges">
                            I confirm these changes are correct
                        </label>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary" id="submitBtn">
                            <i class="bi bi-save me-2"></i>Save Changes
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function validateRoles(input) {
        const value = input.value.trim();
        if (value === '') {
            input.classList.remove('is-invalid');
            return true;
        }
        
        // Check for valid role pattern
        const roles = value.split(',').map(r => r.trim());
        const invalid = roles.filter(r => !/^[a-zA-Z0-9_-]+$/.test(r));
        
        if (invalid.length > 0) {
            input.classList.add('is-invalid');
            return false;
        } else {
            input.classList.remove('is-invalid');
            return true;
        }
    }

    function handleSubmit() {
        const form = document.getElementById('editForm');
        const submitBtn = document.getElementById('submitBtn');
        const rolesInput = form.querySelector('[name="allowed_roles"]');
        
        // Validate roles
        if (!validateRoles(rolesInput)) {
            return false;
        }
        
        // Show loading state
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="bi bi-hourglass-split me-2"></i>Saving...';
        submitBtn.disabled = true;
        submitBtn.classList.add('submitting');
        
        // Form will submit normally
        return true;
    }

    document.addEventListener('DOMContentLoaded', function() {
        // Auto-focus first editable input
        const firstInput = document.querySelector('input:not([readonly])');
        if (firstInput) {
            firstInput.focus();
        }
        
        // Add confirmation for delete button
        const deleteBtn = document.querySelector('a.btn-outline-danger');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', function(e) {
                if (!confirm('⚠️ WARNING: This will permanently delete the credential.\n\nAre you sure?')) {
                    e.preventDefault();
                }
            });
        }
        
        // Add form validation on load
        const rolesInput = document.querySelector('[name="allowed_roles"]');
        if (rolesInput) {
            validateRoles(rolesInput);
        }
    });
    </script>
</body>
</html>