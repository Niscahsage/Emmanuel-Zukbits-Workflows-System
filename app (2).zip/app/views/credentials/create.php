<?php
// create.php displays a form to add a new credential for a project.

use App\core\View;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Credential - ZukBits</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --color-bg: #050816;
            --color-surface: #0b1020;
            --color-surface-alt: #111827;
            --color-surface-soft: #0f172a;
            --color-accent: #ffc857;
            --color-accent-strong: #fbbf24;
            --color-accent-blue: #38bdf8;
            --color-accent-purple: #a855f7;
            --color-accent-green: #34c759;
            --color-text: #f7f7ff;
            --color-text-muted: #c3c5d4;
            --color-border: #22263b;
            --color-border-light: rgba(148, 163, 253, 0.35);
            --gradient-primary: linear-gradient(135deg, var(--color-accent-blue), var(--color-accent-purple));
            --gradient-bg-card: radial-gradient(circle at top left, rgba(148, 163, 253, 0.18), rgba(15, 23, 42, 0.96));
        }

        body {
            background: var(--color-bg);
            color: var(--color-text);
            min-height: 100vh;
        }

        .container-fluid {
            padding: 1.5rem;
            max-width: 1200px;
            margin: 0 auto;
        }

        .dashboard-header {
            background: var(--gradient-bg-card);
            border: 1px solid var(--color-border);
            border-radius: 16px;
            padding: 1.5rem 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .header-title {
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: 700;
            margin: 0;
        }

        .form-card {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: 16px;
            padding: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .form-label {
            color: var(--color-text);
            font-weight: 500;
            margin-bottom: 0.5rem;
            font-size: 0.95rem;
        }

        .form-control, .form-select {
            background: var(--color-surface-alt);
            border: 1px solid var(--color-border);
            color: var(--color-text);
            border-radius: 12px;
            padding: 0.75rem 1rem;
            transition: all 0.2s ease;
        }

        .form-control:focus, .form-select:focus {
            background: var(--color-surface-soft);
            border-color: var(--color-accent-blue);
            color: var(--color-text);
            box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.15);
        }

        .form-control::placeholder {
            color: var(--color-text-muted);
            opacity: 0.6;
        }

        .form-text {
            color: var(--color-text-muted);
            font-size: 0.85rem;
            margin-top: 0.5rem;
        }

        .form-text i {
            color: var(--color-accent-blue);
        }

        .btn-primary {
            background: var(--gradient-primary);
            border: none;
            color: white;
            font-weight: 500;
            padding: 0.75rem 2rem;
            border-radius: 10px;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(56, 189, 248, 0.25);
        }

        .btn-outline-secondary {
            color: var(--color-text-muted);
            border-color: var(--color-border);
            background: transparent;
            border-radius: 10px;
            padding: 0.75rem 2rem;
        }

        .btn-outline-secondary:hover {
            background: var(--color-border);
            border-color: var(--color-border);
            color: var(--color-text);
        }

        .input-group-text {
            background: var(--color-surface-alt);
            border: 1px solid var(--color-border);
            color: var(--color-text-muted);
            border-radius: 12px 0 0 12px;
        }

        .form-section {
            margin-bottom: 2rem;
            padding-bottom: 2rem;
            border-bottom: 1px solid var(--color-border);
        }

        .form-section:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .section-title {
            color: var(--color-accent);
            font-size: 1.1rem;
            margin-bottom: 1.5rem;
            padding-bottom: 0.75rem;
            border-bottom: 2px solid var(--color-border);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .password-toggle {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            background: transparent;
            border: none;
            color: var(--color-text-muted);
            cursor: pointer;
            padding: 0.25rem;
        }

        .password-toggle:hover {
            color: var(--color-accent);
        }

        .required::after {
            content: ' *';
            color: #ef4444;
        }

        .form-help {
            background: var(--color-surface-alt);
            border: 1px solid var(--color-border);
            border-radius: 12px;
            padding: 1rem 1.25rem;
            margin-top: 1rem;
            color: var(--color-text-muted);
            font-size: 0.9rem;
        }

        .form-help-title {
            color: var(--color-accent);
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        @media (max-width: 768px) {
            .container-fluid {
                padding: 1rem;
            }
            
            .dashboard-header,
            .form-card {
                padding: 1.25rem;
            }
            
            .form-section {
                margin-bottom: 1.5rem;
                padding-bottom: 1.5rem;
            }
        }

        /* Custom focus styles */
        .form-control:focus-within {
            border-color: var(--color-accent-blue);
        }

        /* Animation for form submission */
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(56, 189, 248, 0.4); }
            70% { box-shadow: 0 0 0 10px rgba(56, 189, 248, 0); }
            100% { box-shadow: 0 0 0 0 rgba(56, 189, 248, 0); }
        }

        .submitting {
            animation: pulse 2s infinite;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="dashboard-header">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center">
                <div class="mb-3 mb-md-0">
                    <h1 class="header-title h3 mb-2">
                        <i class="bi bi-plus-circle me-2"></i>Add Credential
                    </h1>
                    <p class="text-muted mb-0">Create a new encrypted credential for your project</p>
                </div>
                <div>
                    <a href="/credentials" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left me-2"></i>Cancel
                    </a>
                </div>
            </div>
        </div>

        <div class="form-card">
            <form action="/credentials/store" method="post" id="credentialForm" onsubmit="return handleSubmit()">
                <!-- Basic Information Section -->
                <div class="form-section">
                    <h3 class="section-title">
                        <i class="bi bi-info-circle"></i>Basic Information
                    </h3>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label required">
                                <i class="bi bi-hash me-2"></i>Project ID
                            </label>
                            <input 
                                type="number" 
                                name="project_id" 
                                class="form-control" 
                                required
                                min="1"
                                placeholder="Enter project ID"
                                oninput="validateProjectId(this)"
                            >
                            <div class="form-text">
                                <i class="bi bi-info-circle me-1"></i>
                                Enter the project ID this credential belongs to.
                            </div>
                            <div class="invalid-feedback" id="projectIdFeedback">
                                Please enter a valid project ID
                            </div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label required">
                                <i class="bi bi-tag me-2"></i>Label
                            </label>
                            <input 
                                type="text" 
                                name="label" 
                                class="form-control" 
                                required
                                maxlength="100"
                                placeholder="e.g., Database Password, API Key"
                            >
                            <div class="form-text">
                                <i class="bi bi-info-circle me-1"></i>
                                A descriptive name for this credential
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-card-text me-2"></i>Description
                        </label>
                        <textarea 
                            name="description" 
                            rows="3" 
                            class="form-control"
                            placeholder="Optional description about this credential"
                            maxlength="500"
                        ></textarea>
                        <div class="form-text">
                            <i class="bi bi-info-circle me-1"></i>
                            Maximum 500 characters
                        </div>
                    </div>
                </div>

                <!-- Security Section -->
                <div class="form-section">
                    <h3 class="section-title">
                        <i class="bi bi-shield-lock"></i>Security Settings
                    </h3>
                    
                    <div class="mb-3">
                        <label class="form-label required">
                            <i class="bi bi-key me-2"></i>Secret Value
                        </label>
                        <div class="position-relative">
                            <input 
                                type="password" 
                                name="value" 
                                id="secretValue"
                                class="form-control" 
                                required
                                placeholder="Enter the secret value"
                                oninput="updateStrength(this.value)"
                            >
                            <button type="button" class="password-toggle" onclick="togglePassword()">
                                <i class="bi bi-eye"></i>
                            </button>
                        </div>
                        <div class="form-text">
                            <i class="bi bi-lock me-1"></i>
                            This value will be encrypted before storage. Never stored in plain text.
                        </div>
                        
                        <!-- Strength indicator -->
                        <div class="mt-2">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <small class="text-muted">Password strength:</small>
                                <small class="text-muted" id="strengthText">Weak</small>
                            </div>
                            <div class="progress" style="height: 4px; background: var(--color-border); border-radius: 2px;">
                                <div class="progress-bar" id="strengthBar" style="width: 0%; border-radius: 2px;"></div>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-people me-2"></i>Allowed Roles
                        </label>
                        <input
                            type="text"
                            name="allowed_roles"
                            class="form-control"
                            placeholder="e.g., developer, system_admin, director"
                            oninput="validateRoles(this)"
                        >
                        <div class="form-text">
                            <i class="bi bi-info-circle me-1"></i>
                            Comma-separated list of role keys. Leave empty for project-assignees only.
                        </div>
                        <div class="form-help">
                            <div class="form-help-title">
                                <i class="bi bi-lightbulb"></i>Role Examples
                            </div>
                            <div class="row">
                                <div class="col-6">
                                    <small>• developer</small><br>
                                    <small>• system_admin</small>
                                </div>
                                <div class="col-6">
                                    <small>• director</small><br>
                                    <small>• super_admin</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Help Section -->
                <div class="form-section">
                    <div class="form-help">
                        <div class="form-help-title">
                            <i class="bi bi-shield-check"></i>Security Best Practices
                        </div>
                        <small>
                            1. Use strong, unique passwords for each credential<br>
                            2. Regularly rotate credentials when possible<br>
                            3. Only share with authorized team members<br>
                            4. Never store unencrypted credentials<br>
                            5. Monitor access logs regularly
                        </small>
                    </div>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-3">
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="confirmEncryption" required>
                        <label class="form-check-label" for="confirmEncryption">
                            I confirm this value will be encrypted
                        </label>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary" id="submitBtn">
                            <i class="bi bi-save me-2"></i>Save Credential
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function validateProjectId(input) {
        const feedback = document.getElementById('projectIdFeedback');
        if (input.value < 1) {
            input.classList.add('is-invalid');
            feedback.textContent = 'Project ID must be greater than 0';
            return false;
        } else {
            input.classList.remove('is-invalid');
            return true;
        }
    }

    function togglePassword() {
        const input = document.getElementById('secretValue');
        const toggle = document.querySelector('.password-toggle i');
        
        if (input.type === 'password') {
            input.type = 'text';
            toggle.classList.remove('bi-eye');
            toggle.classList.add('bi-eye-slash');
        } else {
            input.type = 'password';
            toggle.classList.remove('bi-eye-slash');
            toggle.classList.add('bi-eye');
        }
    }

    function updateStrength(password) {
        const bar = document.getElementById('strengthBar');
        const text = document.getElementById('strengthText');
        
        let strength = 0;
        let color = '#ef4444'; // Red
        let label = 'Weak';
        
        // Length check
        if (password.length >= 8) strength += 25;
        if (password.length >= 12) strength += 15;
        
        // Complexity checks
        if (/[A-Z]/.test(password)) strength += 20;
        if (/[a-z]/.test(password)) strength += 20;
        if (/\d/.test(password)) strength += 20;
        if (/[^A-Za-z0-9]/.test(password)) strength += 20;
        
        // Cap at 100
        strength = Math.min(strength, 100);
        
        // Update UI based on strength
        if (strength >= 80) {
            color = '#34c759'; // Green
            label = 'Very Strong';
        } else if (strength >= 60) {
            color = '#22c55e'; // Green
            label = 'Strong';
        } else if (strength >= 40) {
            color = '#fbbf24'; // Yellow
            label = 'Good';
        } else if (strength >= 20) {
            color = '#f97316'; // Orange
            label = 'Weak';
        }
        
        bar.style.width = strength + '%';
        bar.style.backgroundColor = color;
        text.textContent = label;
        text.style.color = color;
    }

    function validateRoles(input) {
        const value = input.value.trim();
        if (value === '') return true;
        
        // Check for valid role pattern (letters, numbers, underscores, hyphens)
        const roles = value.split(',').map(r => r.trim());
        const invalid = roles.filter(r => !/^[a-zA-Z0-9_-]+$/.test(r));
        
        if (invalid.length > 0) {
            input.classList.add('is-invalid');
            return false;
        } else {
            input.classList.remove('is-invalid');
            return true;
        }
    }

    function handleSubmit() {
        const form = document.getElementById('credentialForm');
        const submitBtn = document.getElementById('submitBtn');
        const projectId = form.querySelector('[name="project_id"]');
        
        // Validate project ID
        if (!validateProjectId(projectId)) {
            return false;
        }
        
        // Validate roles
        const rolesInput = form.querySelector('[name="allowed_roles"]');
        if (!validateRoles(rolesInput)) {
            return false;
        }
        
        // Show loading state
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="bi bi-hourglass-split me-2"></i>Saving...';
        submitBtn.disabled = true;
        submitBtn.classList.add('submitting');
        
        // Form will submit normally
        return true;
    }

    // Initialize strength indicator
    document.addEventListener('DOMContentLoaded', function() {
        const secretInput = document.getElementById('secretValue');
        if (secretInput.value) {
            updateStrength(secretInput.value);
        }
        
        // Auto-focus first input
        const firstInput = document.querySelector('input[required]');
        if (firstInput) {
            firstInput.focus();
        }
    });
    </script>
</body>
</html>