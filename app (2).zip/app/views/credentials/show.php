<?php
// show.php displays details for a single credential, with reveal logic handled in backend.

/** @var array $credential */

use App\core\View;

$id          = (int) $credential['id'];
$label       = $credential['label'] ?? '';
$project     = $credential['project_name'] ?? '';
$description = $credential['description'] ?? '';
$allowed     = $credential['allowed_roles'] ?? '';
$createdBy   = $credential['created_by'] ?? '';
$createdAt   = $credential['created_at'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Credential: <?= View::e($label) ?> - ZukBits</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --color-bg: #050816;
            --color-surface: #0b1020;
            --color-surface-alt: #111827;
            --color-surface-soft: #0f172a;
            --color-accent: #ffc857;
            --color-accent-strong: #fbbf24;
            --color-accent-blue: #38bdf8;
            --color-accent-purple: #a855f7;
            --color-accent-green: #34c759;
            --color-text: #f7f7ff;
            --color-text-muted: #c3c5d4;
            --color-border: #22263b;
            --color-border-light: rgba(148, 163, 253, 0.35);
            --gradient-primary: linear-gradient(135deg, var(--color-accent-blue), var(--color-accent-purple));
            --gradient-bg-card: radial-gradient(circle at top left, rgba(148, 163, 253, 0.18), rgba(15, 23, 42, 0.96));
        }

        body {
            background: var(--color-bg);
            color: var(--color-text);
            min-height: 100vh;
        }

        .container-fluid {
            padding: 1.5rem;
        }

        .dashboard-header {
            background: var(--gradient-bg-card);
            border: 1px solid var(--color-border);
            border-radius: 16px;
            padding: 1.5rem 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .header-title {
            font-weight: 700;
            margin: 0;
        }

        .text-gradient {
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .btn-primary {
            background: var(--gradient-primary);
            border: none;
            color: white;
            font-weight: 500;
            padding: 0.5rem 1.5rem;
            border-radius: 10px;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(56, 189, 248, 0.25);
        }

        .btn-outline-secondary {
            color: var(--color-text-muted);
            border-color: var(--color-border);
            background: transparent;
            border-radius: 10px;
        }

        .btn-outline-secondary:hover {
            background: var(--color-border);
            border-color: var(--color-border);
            color: var(--color-text);
        }

        .detail-card {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: 16px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .detail-section {
            margin-bottom: 1.5rem;
        }

        .detail-label {
            color: var(--color-text-muted);
            font-size: 0.875rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.5rem;
        }

        .detail-value {
            color: var(--color-text);
            font-size: 1.1rem;
            line-height: 1.5;
        }

        .detail-value.empty {
            color: var(--color-text-muted);
            font-style: italic;
        }

        .secret-card {
            background: var(--gradient-bg-card);
            border: 1px solid var(--color-border);
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            border-top: 4px solid var(--color-accent-blue);
        }

        .secret-header {
            background: var(--color-surface-alt);
            padding: 1.5rem 2rem;
            border-bottom: 1px solid var(--color-border);
        }

        .secret-header h3 {
            color: var(--color-accent-blue);
            margin: 0;
            font-size: 1.25rem;
        }

        .secret-body {
            padding: 2rem;
        }

        .secret-description {
            color: var(--color-text-muted);
            margin-bottom: 1.5rem;
            line-height: 1.6;
        }

        .secret-box {
            background: var(--color-bg);
            border: 1px solid var(--color-border);
            border-radius: 12px;
            padding: 1.5rem;
            margin-top: 1.5rem;
            font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
            font-size: 0.95rem;
            line-height: 1.6;
            word-break: break-all;
            display: none;
            animation: fadeIn 0.3s ease;
        }

        .secret-box.visible {
            display: block;
        }

        .secret-placeholder {
            background: repeating-linear-gradient(
                45deg,
                var(--color-surface),
                var(--color-surface) 10px,
                var(--color-surface-alt) 10px,
                var(--color-surface-alt) 20px
            );
            color: var(--color-text-muted);
            padding: 1.5rem;
            border-radius: 12px;
            text-align: center;
            font-style: italic;
            border: 1px solid var(--color-border);
        }

        .loading {
            position: relative;
            color: transparent;
        }

        .loading::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 20px;
            height: 20px;
            margin: -10px 0 0 -10px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-top-color: white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        .badge {
            padding: 0.35rem 0.75rem;
            font-weight: 500;
            border-radius: 6px;
            font-size: 0.75rem;
        }

        .role-badge {
            background: rgba(56, 189, 248, 0.1);
            color: var(--color-accent-blue);
            border: 1px solid rgba(56, 189, 248, 0.2);
        }

        .text-muted {
            color: var(--color-text-muted) !important;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        @media (max-width: 768px) {
            .container-fluid {
                padding: 1rem;
            }
            
            .dashboard-header,
            .detail-card,
            .secret-card {
                padding: 1.25rem;
            }
            
            .secret-body {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="dashboard-header">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center">
                <div class="mb-3 mb-md-0">
                    <h1 class="header-title h4 mb-2">
                        <span class="text-gradient">
                            <i class="bi bi-key me-2"></i><?= View::e($label) ?>
                        </span>
                    </h1>
                    <p class="text-muted mb-0">Credential details and secret access</p>
                </div>
                <div class="d-flex gap-2">
                    <a href="/credentials" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left me-2"></i>Back to List
                    </a>
                </div>
            </div>
        </div>

        <!-- Credential Details -->
        <div class="detail-card">
            <div class="row">
                <div class="col-md-6">
                    <div class="detail-section">
                        <div class="detail-label">
                            <i class="bi bi-tag me-2"></i>Label
                        </div>
                        <div class="detail-value">
                            <?= View::e($label) ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="detail-section">
                        <div class="detail-label">
                            <i class="bi bi-folder me-2"></i>Project
                        </div>
                        <div class="detail-value">
                            <?= View::e($project) ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="detail-section">
                        <div class="detail-label">
                            <i class="bi bi-card-text me-2"></i>Description
                        </div>
                        <div class="detail-value <?= $description === '' ? 'empty' : '' ?>">
                            <?= $description !== '' ? nl2br(View::e($description)) : 'No description provided' ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="detail-section">
                        <div class="detail-label">
                            <i class="bi bi-people me-2"></i>Allowed Roles
                        </div>
                        <div class="detail-value <?= $allowed === '' ? 'empty' : '' ?>">
                            <?php if ($allowed !== ''): ?>
                                <?php
                                $roles = explode(',', $allowed);
                                foreach ($roles as $role):
                                ?>
                                    <span class="badge role-badge me-1"><?= View::e(trim($role)) ?></span>
                                <?php endforeach; ?>
                            <?php else: ?>
                                Project assignees only
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="detail-section">
                        <div class="detail-label">
                            <i class="bi bi-person-plus me-2"></i>Created By
                        </div>
                        <div class="detail-value">
                            <?= View::e((string) $createdBy) ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="detail-section">
                        <div class="detail-label">
                            <i class="bi bi-calendar-check me-2"></i>Created At
                        </div>
                        <div class="detail-value">
                            <small><?= View::e($createdAt) ?></small>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="detail-section">
                        <div class="detail-label">
                            <i class="bi bi-shield-check me-2"></i>Security Status
                        </div>
                        <div class="detail-value">
                            <span class="badge" style="background: rgba(52, 199, 89, 0.1); color: var(--color-accent-green); border: 1px solid rgba(52, 199, 89, 0.2);">
                                <i class="bi bi-lock-fill me-1"></i>Encrypted
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Secret Reveal Section -->
        <div class="secret-card">
            <div class="secret-header">
                <h3><i class="bi bi-shield-lock me-2"></i>Secret Value</h3>
            </div>
            <div class="secret-body">
                <div class="secret-description">
                    <p class="mb-2">
                        <i class="bi bi-info-circle me-2"></i>
                        This credential value is securely encrypted. Click the button below to reveal it if you are authorized.
                        The value will be visible for 60 seconds before being hidden again.
                    </p>
                    <small class="text-muted">
                        <i class="bi bi-clock-history me-1"></i>
                        Access is logged and monitored for security purposes.
                    </small>
                </div>

                <button
                    class="btn btn-primary mb-3"
                    onclick="revealCredential()"
                    id="revealBtn"
                >
                    <i class="bi bi-eye me-2"></i>Reveal Secret Value
                </button>

                <div class="secret-placeholder" id="secretPlaceholder">
                    <i class="bi bi-lock" style="font-size: 2rem; margin-bottom: 1rem;"></i>
                    <div>Secret value is hidden</div>
                    <small class="text-muted">Click "Reveal" to show the value</small>
                </div>

                <pre id="secretBox" class="secret-box"></pre>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    async function revealCredential() {
        const btn = document.getElementById('revealBtn');
        const box = document.getElementById('secretBox');
        const placeholder = document.getElementById('secretPlaceholder');
        
        // Save original button text
        const originalText = btn.innerHTML;
        
        // Show loading state
        btn.disabled = true;
        btn.classList.add('loading');
        
        try {
            const response = await fetch('/credentials/reveal?id=<?= $id ?>');
            
            // Hide placeholder
            placeholder.style.display = 'none';
            
            if (!response.ok) {
                box.textContent = 'Error: You are not authorized to view this credential.';
                box.className = 'secret-box visible';
                box.style.color = '#ef4444';
                box.style.borderColor = 'rgba(239, 68, 68, 0.3)';
                box.style.background = 'rgba(239, 68, 68, 0.1)';
            } else {
                const text = await response.text();
                box.className = 'secret-box visible';
                box.style.color = 'var(--color-accent-green)';
                box.style.borderColor = 'rgba(52, 199, 89, 0.3)';
                box.style.background = 'rgba(52, 199, 89, 0.1)';
                box.textContent = text.trim() !== '' ? text : '(empty secret)';
                
                // Auto-hide after 60 seconds
                setTimeout(() => {
                    box.className = 'secret-box';
                    placeholder.style.display = 'block';
                    btn.disabled = false;
                    btn.classList.remove('loading');
                    btn.innerHTML = originalText;
                }, 60000);
            }
        } catch (e) {
            box.textContent = 'Error: Unable to fetch credential. Please try again.';
            box.className = 'secret-box visible';
            box.style.color = '#ef4444';
            box.style.borderColor = 'rgba(239, 68, 68, 0.3)';
            box.style.background = 'rgba(239, 68, 68, 0.1)';
        }
        
        // Reset button if there was an error (success case handled in timeout)
        if (box.style.color === '#ef4444') {
            btn.disabled = false;
            btn.classList.remove('loading');
            btn.innerHTML = originalText;
        }
    }

    // Add click protection
    document.addEventListener('DOMContentLoaded', function() {
        const secretBox = document.getElementById('secretBox');
        const revealBtn = document.getElementById('revealBtn');
        
        // Prevent text selection in secret box
        secretBox.addEventListener('mousedown', function(e) {
            if (window.getSelection().toString()) {
                e.preventDefault();
            }
        });
        
        // Add keyboard shortcut (Ctrl+Shift+R)
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && e.shiftKey && e.key === 'R') {
                e.preventDefault();
                if (!revealBtn.disabled) {
                    revealCredential();
                }
            }
        });
        
        // Add tooltip for keyboard shortcut
        revealBtn.title = 'Click or press Ctrl+Shift+R to reveal';
    });
    </script>
</body>
</html>