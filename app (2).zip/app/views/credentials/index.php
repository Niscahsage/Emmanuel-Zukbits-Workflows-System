<?php
// index.php lists credentials for projects that the current user is allowed to access.

/** @var array $credentials */

use App\core\View;
use App\core\Auth;

$user = Auth::user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Credentials - ZukBits</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --color-bg: #050816;
            --color-surface: #0b1020;
            --color-surface-alt: #111827;
            --color-surface-soft: #0f172a;
            --color-accent: #ffc857;
            --color-accent-strong: #fbbf24;
            --color-accent-blue: #38bdf8;
            --color-accent-purple: #a855f7;
            --color-accent-green: #34c759;
            --color-text: #f7f7ff;
            --color-text-muted: #c3c5d4;
            --color-border: #22263b;
            --gradient-primary: linear-gradient(135deg, var(--color-accent-blue), var(--color-accent-purple));
            --gradient-bg-card: radial-gradient(circle at top left, rgba(148, 163, 253, 0.18), rgba(15, 23, 42, 0.96));
        }

        body {
            background: var(--color-bg);
            color: var(--color-text);
            min-height: 100vh;
        }

        .container-fluid {
            padding: 1.5rem;
        }

        .dashboard-header {
            background: var(--gradient-bg-card);
            border: 1px solid var(--color-border);
            border-radius: 16px;
            padding: 1.5rem 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .header-title {
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: 700;
            margin: 0;
        }

        .btn-primary {
            background: var(--gradient-primary);
            border: none;
            color: white;
            font-weight: 500;
            padding: 0.5rem 1.5rem;
            border-radius: 10px;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(56, 189, 248, 0.25);
        }

        .btn-outline-secondary {
            color: var(--color-text-muted);
            border-color: var(--color-border);
            background: transparent;
            border-radius: 10px;
        }

        .btn-outline-secondary:hover {
            background: var(--color-border);
            border-color: var(--color-border);
            color: var(--color-text);
        }

        .stats-card {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            transition: transform 0.3s ease;
        }

        .stats-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.4);
        }

        .stats-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
            font-size: 1.25rem;
        }

        .stats-icon.primary {
            background: rgba(56, 189, 248, 0.15);
            color: var(--color-accent-blue);
        }

        .stats-icon.success {
            background: rgba(52, 199, 89, 0.15);
            color: var(--color-accent-green);
        }

        .stats-icon.warning {
            background: rgba(251, 191, 36, 0.15);
            color: var(--color-accent-strong);
        }

        .stats-count {
            font-size: 2rem;
            font-weight: 700;
            line-height: 1;
            margin-bottom: 0.25rem;
        }

        .stats-label {
            color: var(--color-text-muted);
            font-size: 0.875rem;
        }

        .table-container {
            background: var(--color-surface);
            border: 1px solid var(--color-border);
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .table {
            color: var(--color-text);
            margin: 0;
        }

        .table > :not(caption) > * > * {
            background-color: transparent;
            border-bottom-color: var(--color-border);
            padding: 1rem 1.5rem;
        }

        .table thead th {
            background: var(--color-surface-alt);
            color: var(--color-accent);
            font-weight: 600;
            border-bottom: 2px solid var(--color-border);
        }

        .table tbody tr {
            transition: background-color 0.2s ease;
        }

        .table tbody tr:hover {
            background-color: var(--color-surface-soft);
        }

        .badge {
            padding: 0.35rem 0.75rem;
            font-weight: 500;
            border-radius: 6px;
            font-size: 0.75rem;
        }

        .badge.role-badge {
            background: rgba(56, 189, 248, 0.1);
            color: var(--color-accent-blue);
            border: 1px solid rgba(56, 189, 248, 0.2);
        }

        .alert-info {
            background: rgba(56, 189, 248, 0.1);
            border: 1px solid rgba(56, 189, 248, 0.2);
            color: var(--color-accent-blue);
            border-radius: 12px;
            border-left: 4px solid var(--color-accent-blue);
        }

        .text-muted {
            color: var(--color-text-muted) !important;
        }

        .action-btn {
            padding: 0.375rem 0.75rem;
            font-size: 0.875rem;
        }

        @media (max-width: 768px) {
            .container-fluid {
                padding: 1rem;
            }
            
            .dashboard-header {
                padding: 1.25rem;
            }
            
            .table-responsive {
                border-radius: 12px;
                border: 1px solid var(--color-border);
            }
        }

        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        ::-webkit-scrollbar-track {
            background: var(--color-surface);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--color-border);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--color-text-muted);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="dashboard-header">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center">
                <div class="mb-3 mb-md-0">
                    <h1 class="header-title h3 mb-2">
                        <i class="bi bi-key me-2"></i>Credentials
                    </h1>
                    <p class="text-muted mb-0">Manage and access project credentials securely</p>
                </div>
                <div>
                    <a href="/credentials/create" class="btn btn-primary">
                        <i class="bi bi-plus-circle me-2"></i>Add Credential
                    </a>
                </div>
            </div>
        </div>

        <!-- Stats Overview -->
        <?php if (!empty($credentials)): ?>
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-icon primary">
                            <i class="bi bi-key"></i>
                        </div>
                        <div class="stats-count"><?= count($credentials) ?></div>
                        <div class="stats-label">Total Credentials</div>
                    </div>
                </div>
                <?php
                // Count unique projects
                $uniqueProjects = array_unique(array_column($credentials, 'project_name'));
                ?>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-icon success">
                            <i class="bi bi-folder"></i>
                        </div>
                        <div class="stats-count"><?= count($uniqueProjects) ?></div>
                        <div class="stats-label">Projects</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-icon warning">
                            <i class="bi bi-person"></i>
                        </div>
                        <div class="stats-count"><?= count(array_unique(array_column($credentials, 'created_by'))) ?></div>
                        <div class="stats-label">Creators</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-icon primary">
                            <i class="bi bi-shield-check"></i>
                        </div>
                        <div class="stats-count">100%</div>
                        <div class="stats-label">Encrypted</div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if (empty($credentials)): ?>
            <div class="alert alert-info d-flex align-items-center">
                <i class="bi bi-info-circle-fill me-3" style="font-size: 1.5rem;"></i>
                <div>
                    <h5 class="alert-heading mb-1">No credentials available</h5>
                    <p class="mb-0">You don't have access to any credentials for your projects yet.</p>
                </div>
            </div>
        <?php else: ?>
            <div class="table-container">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th class="ps-4">ID</th>
                                <th>Label</th>
                                <th>Project</th>
                                <th>Created By</th>
                                <th>Created At</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($credentials as $cred): ?>
                                <?php
                                $id        = (int) $cred['id'];
                                $label     = $cred['label'] ?? '';
                                $project   = $cred['project_name'] ?? '';
                                $createdBy = $cred['created_by'] ?? '';
                                $createdAt = $cred['created_at'] ?? '';
                                ?>
                                <tr>
                                    <td class="ps-4 fw-semibold">#<?= View::e((string) $id) ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <i class="bi bi-key me-2 text-muted"></i>
                                            <?= View::e($label) ?>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge role-badge">
                                            <?= View::e($project) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <i class="bi bi-person-circle me-2 text-muted"></i>
                                            <?= View::e((string) $createdBy) ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <i class="bi bi-calendar3 me-2 text-muted"></i>
                                            <small><?= View::e($createdAt) ?></small>
                                        </div>
                                    </td>
                                    <td class="text-end pe-4">
                                        <a href="/credentials/show?id=<?= View::e((string) $id) ?>"
                                           class="btn btn-outline-secondary action-btn">
                                            <i class="bi bi-eye me-1"></i>View
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>