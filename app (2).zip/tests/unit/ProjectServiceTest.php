// ProjectServiceTest contains unit tests for project-related business logic.
