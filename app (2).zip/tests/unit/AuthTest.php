// AuthTest contains unit tests for authentication and session logic.
