// ReportServiceTest contains unit tests for weekly report business logic.
