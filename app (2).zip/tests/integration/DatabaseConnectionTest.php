// DatabaseConnectionTest verifies that the application can connect to the configured database.
