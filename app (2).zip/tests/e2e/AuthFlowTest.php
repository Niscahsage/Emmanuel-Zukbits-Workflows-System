// AuthFlowTest performs end-to-end tests of the login and logout flows.
