// ProjectLifecycleTest performs end-to-end tests of a full project lifecycle.
